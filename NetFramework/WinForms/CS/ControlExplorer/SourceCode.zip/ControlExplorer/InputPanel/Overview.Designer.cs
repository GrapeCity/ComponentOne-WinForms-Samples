﻿namespace ControlExplorer.InputPanel
{
    partial class Overview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Overview));
            this.c1InputPanel1 = new C1.Win.C1InputPanel.C1InputPanel();
            this.inputGroupHeader1 = new C1.Win.C1InputPanel.InputGroupHeader();
            this.inputLabel2 = new C1.Win.C1InputPanel.InputLabel();
            this.inputTextBox1 = new C1.Win.C1InputPanel.InputTextBox();
            this.inputLabel3 = new C1.Win.C1InputPanel.InputLabel();
            this.inputNumericBox1 = new C1.Win.C1InputPanel.InputNumericBox();
            this.inputLabel4 = new C1.Win.C1InputPanel.InputLabel();
            this.inputMaskedTextBox1 = new C1.Win.C1InputPanel.InputMaskedTextBox();
            this.inputLabel5 = new C1.Win.C1InputPanel.InputLabel();
            this.inputDatePicker1 = new C1.Win.C1InputPanel.InputDatePicker();
            this.inputLabel6 = new C1.Win.C1InputPanel.InputLabel();
            this.inputTimePicker1 = new C1.Win.C1InputPanel.InputTimePicker();
            this.inputLabel7 = new C1.Win.C1InputPanel.InputLabel();
            this.inputComboBox2 = new C1.Win.C1InputPanel.InputComboBox();
            this.inputOption5 = new C1.Win.C1InputPanel.InputOption();
            this.inputOption6 = new C1.Win.C1InputPanel.InputOption();
            this.inputOption7 = new C1.Win.C1InputPanel.InputOption();
            this.inputLabel19 = new C1.Win.C1InputPanel.InputLabel();
            this.inputComboBox3 = new C1.Win.C1InputPanel.InputComboBox();
            this.inputOption8 = new C1.Win.C1InputPanel.InputOption();
            this.inputOption9 = new C1.Win.C1InputPanel.InputOption();
            this.inputOption10 = new C1.Win.C1InputPanel.InputOption();
            this.inputLabel8 = new C1.Win.C1InputPanel.InputLabel();
            this.inputRadioButton1 = new C1.Win.C1InputPanel.InputRadioButton();
            this.inputRadioButton2 = new C1.Win.C1InputPanel.InputRadioButton();
            this.inputLabel9 = new C1.Win.C1InputPanel.InputLabel();
            this.inputCheckBox1 = new C1.Win.C1InputPanel.InputCheckBox();
            this.inputLabel11 = new C1.Win.C1InputPanel.InputLabel();
            this.inputHtmlLabel1 = new C1.Win.C1InputPanel.InputHtmlLabel();
            this.inputLabel12 = new C1.Win.C1InputPanel.InputLabel();
            this.inputImage1 = new C1.Win.C1InputPanel.InputImage();
            this.inputSeparator1 = new C1.Win.C1InputPanel.InputSeparator();
            this.inputLabel10 = new C1.Win.C1InputPanel.InputLabel();
            this.inputButton1 = new C1.Win.C1InputPanel.InputButton();
            this.inputLabel14 = new C1.Win.C1InputPanel.InputLabel();
            this.inputSplitButton2 = new C1.Win.C1InputPanel.InputSplitButton();
            this.inputButton4 = new C1.Win.C1InputPanel.InputButton();
            this.inputButton5 = new C1.Win.C1InputPanel.InputButton();
            this.inputLabel13 = new C1.Win.C1InputPanel.InputLabel();
            this.inputMenu1 = new C1.Win.C1InputPanel.InputMenu();
            this.inputGroupHeader2 = new C1.Win.C1InputPanel.InputGroupHeader();
            this.inputButton2 = new C1.Win.C1InputPanel.InputButton();
            this.inputButton3 = new C1.Win.C1InputPanel.InputButton();
            this.inputSeparator2 = new C1.Win.C1InputPanel.InputSeparator();
            this.inputSplitButton1 = new C1.Win.C1InputPanel.InputSplitButton();
            this.inputButton6 = new C1.Win.C1InputPanel.InputButton();
            this.inputButton7 = new C1.Win.C1InputPanel.InputButton();
            this.inputLabel15 = new C1.Win.C1InputPanel.InputLabel();
            this.inputTrackBar1 = new C1.Win.C1InputPanel.InputTrackBar();
            this.inputLabel18 = new C1.Win.C1InputPanel.InputLabel();
            this.inputProgressBar1 = new C1.Win.C1InputPanel.InputProgressBar();
            this.inputGroupHeader3 = new C1.Win.C1InputPanel.InputGroupHeader();
            this.inputLabel16 = new C1.Win.C1InputPanel.InputLabel();
            this.inputDataNavigator1 = new C1.Win.C1InputPanel.InputDataNavigator();
            this.inputLabel1 = new C1.Win.C1InputPanel.InputLabel();
            ((System.ComponentModel.ISupportInitialize)(this.c1InputPanel1)).BeginInit();
            this.SuspendLayout();
            // 
            // c1InputPanel1
            // 
            this.c1InputPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1InputPanel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.c1InputPanel1.Items.Add(this.inputLabel1);
            this.c1InputPanel1.Items.Add(this.inputGroupHeader1);
            this.c1InputPanel1.Items.Add(this.inputLabel2);
            this.c1InputPanel1.Items.Add(this.inputTextBox1);
            this.c1InputPanel1.Items.Add(this.inputLabel3);
            this.c1InputPanel1.Items.Add(this.inputNumericBox1);
            this.c1InputPanel1.Items.Add(this.inputLabel4);
            this.c1InputPanel1.Items.Add(this.inputMaskedTextBox1);
            this.c1InputPanel1.Items.Add(this.inputLabel5);
            this.c1InputPanel1.Items.Add(this.inputDatePicker1);
            this.c1InputPanel1.Items.Add(this.inputLabel6);
            this.c1InputPanel1.Items.Add(this.inputTimePicker1);
            this.c1InputPanel1.Items.Add(this.inputLabel7);
            this.c1InputPanel1.Items.Add(this.inputComboBox2);
            this.c1InputPanel1.Items.Add(this.inputLabel19);
            this.c1InputPanel1.Items.Add(this.inputComboBox3);
            this.c1InputPanel1.Items.Add(this.inputLabel8);
            this.c1InputPanel1.Items.Add(this.inputRadioButton1);
            this.c1InputPanel1.Items.Add(this.inputRadioButton2);
            this.c1InputPanel1.Items.Add(this.inputLabel9);
            this.c1InputPanel1.Items.Add(this.inputCheckBox1);
            this.c1InputPanel1.Items.Add(this.inputLabel11);
            this.c1InputPanel1.Items.Add(this.inputHtmlLabel1);
            this.c1InputPanel1.Items.Add(this.inputLabel12);
            this.c1InputPanel1.Items.Add(this.inputImage1);
            this.c1InputPanel1.Items.Add(this.inputSeparator1);
            this.c1InputPanel1.Items.Add(this.inputLabel10);
            this.c1InputPanel1.Items.Add(this.inputButton1);
            this.c1InputPanel1.Items.Add(this.inputLabel14);
            this.c1InputPanel1.Items.Add(this.inputSplitButton2);
            this.c1InputPanel1.Items.Add(this.inputLabel13);
            this.c1InputPanel1.Items.Add(this.inputMenu1);
            this.c1InputPanel1.Items.Add(this.inputLabel15);
            this.c1InputPanel1.Items.Add(this.inputTrackBar1);
            this.c1InputPanel1.Items.Add(this.inputLabel18);
            this.c1InputPanel1.Items.Add(this.inputProgressBar1);
            this.c1InputPanel1.Items.Add(this.inputGroupHeader3);
            this.c1InputPanel1.Items.Add(this.inputLabel16);
            this.c1InputPanel1.Items.Add(this.inputDataNavigator1);
            this.c1InputPanel1.Location = new System.Drawing.Point(0, 0);
            this.c1InputPanel1.Name = "c1InputPanel1";
            this.c1InputPanel1.Size = new System.Drawing.Size(703, 446);
            this.c1InputPanel1.TabIndex = 0;
            // 
            // inputGroupHeader1
            // 
            this.inputGroupHeader1.Name = "inputGroupHeader1";
            this.inputGroupHeader1.Text = "Group Header";
            this.inputGroupHeader1.ToolTipText = "This is a GroupHeader";
            // 
            // inputLabel2
            // 
            this.inputLabel2.Name = "inputLabel2";
            this.inputLabel2.Text = "&TextBox";
            this.inputLabel2.Width = 100;
            // 
            // inputTextBox1
            // 
            this.inputTextBox1.Name = "inputTextBox1";
            this.inputTextBox1.Text = "Some Text";
            // 
            // inputLabel3
            // 
            this.inputLabel3.Name = "inputLabel3";
            this.inputLabel3.Text = "&NumericBox";
            this.inputLabel3.Width = 100;
            // 
            // inputNumericBox1
            // 
            this.inputNumericBox1.Name = "inputNumericBox1";
            this.inputNumericBox1.Value = new decimal(new int[] {
            45,
            0,
            0,
            0});
            // 
            // inputLabel4
            // 
            this.inputLabel4.Name = "inputLabel4";
            this.inputLabel4.Text = "&MaskedTextBox";
            this.inputLabel4.Width = 100;
            // 
            // inputMaskedTextBox1
            // 
            this.inputMaskedTextBox1.Mask = "(999) 000-0000";
            this.inputMaskedTextBox1.Name = "inputMaskedTextBox1";
            this.inputMaskedTextBox1.Text = "(123) 456-7890";
            // 
            // inputLabel5
            // 
            this.inputLabel5.Name = "inputLabel5";
            this.inputLabel5.Text = "&DatePicker";
            this.inputLabel5.Width = 100;
            // 
            // inputDatePicker1
            // 
            this.inputDatePicker1.Name = "inputDatePicker1";
            this.inputDatePicker1.Value = new System.DateTime(2009, 9, 1, 0, 0, 0, 0);
            // 
            // inputLabel6
            // 
            this.inputLabel6.Name = "inputLabel6";
            this.inputLabel6.Text = "TimePic&ker";
            this.inputLabel6.Width = 100;
            // 
            // inputTimePicker1
            // 
            this.inputTimePicker1.Name = "inputTimePicker1";
            this.inputTimePicker1.Value = System.TimeSpan.Parse("09:00:00");
            // 
            // inputLabel7
            // 
            this.inputLabel7.Name = "inputLabel7";
            this.inputLabel7.Text = "&ComboBox";
            this.inputLabel7.Width = 100;
            // 
            // inputComboBox2
            // 
            this.inputComboBox2.Items.Add(this.inputOption5);
            this.inputComboBox2.Items.Add(this.inputOption6);
            this.inputComboBox2.Items.Add(this.inputOption7);
            this.inputComboBox2.Name = "inputComboBox2";
            // 
            // inputOption5
            // 
            this.inputOption5.Name = "inputOption5";
            this.inputOption5.Text = "Option 1";
            // 
            // inputOption6
            // 
            this.inputOption6.Name = "inputOption6";
            this.inputOption6.Text = "Option 2";
            // 
            // inputOption7
            // 
            this.inputOption7.Name = "inputOption7";
            this.inputOption7.Text = "Option 3";
            // 
            // inputLabel19
            // 
            this.inputLabel19.Name = "inputLabel19";
            this.inputLabel19.Text = "DropDown&List";
            this.inputLabel19.Width = 100;
            // 
            // inputComboBox3
            // 
            this.inputComboBox3.DropDownStyle = C1.Win.C1InputPanel.InputComboBoxStyle.DropDownList;
            this.inputComboBox3.Items.Add(this.inputOption8);
            this.inputComboBox3.Items.Add(this.inputOption9);
            this.inputComboBox3.Items.Add(this.inputOption10);
            this.inputComboBox3.Name = "inputComboBox3";
            // 
            // inputOption8
            // 
            this.inputOption8.Name = "inputOption8";
            this.inputOption8.Text = "Option 1";
            // 
            // inputOption9
            // 
            this.inputOption9.Name = "inputOption9";
            this.inputOption9.Text = "Option 2";
            // 
            // inputOption10
            // 
            this.inputOption10.Name = "inputOption10";
            this.inputOption10.Text = "Option 3";
            // 
            // inputLabel8
            // 
            this.inputLabel8.Name = "inputLabel8";
            this.inputLabel8.Text = "&RadioButton";
            this.inputLabel8.Width = 100;
            // 
            // inputRadioButton1
            // 
            this.inputRadioButton1.Break = C1.Win.C1InputPanel.BreakType.None;
            this.inputRadioButton1.Name = "inputRadioButton1";
            this.inputRadioButton1.Text = "Option 1";
            // 
            // inputRadioButton2
            // 
            this.inputRadioButton2.Checked = true;
            this.inputRadioButton2.Name = "inputRadioButton2";
            this.inputRadioButton2.Text = "Option 2";
            this.inputRadioButton2.Width = 100;
            // 
            // inputLabel9
            // 
            this.inputLabel9.Name = "inputLabel9";
            this.inputLabel9.Text = "Ch&eckBox";
            this.inputLabel9.Width = 100;
            // 
            // inputCheckBox1
            // 
            this.inputCheckBox1.Break = C1.Win.C1InputPanel.BreakType.Column;
            this.inputCheckBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.inputCheckBox1.Name = "inputCheckBox1";
            // 
            // inputLabel11
            // 
            this.inputLabel11.Name = "inputLabel11";
            this.inputLabel11.Text = "&HtmlLabel";
            this.inputLabel11.Width = 100;
            // 
            // inputHtmlLabel1
            // 
            this.inputHtmlLabel1.Break = C1.Win.C1InputPanel.BreakType.Row;
            this.inputHtmlLabel1.Name = "inputHtmlLabel1";
            this.inputHtmlLabel1.Text = "For <strong><u>RICH</u></strong> <font color=\"red\">text</font>";
            // 
            // inputLabel12
            // 
            this.inputLabel12.Name = "inputLabel12";
            this.inputLabel12.Text = "&Image";
            this.inputLabel12.Width = 100;
            // 
            // inputImage1
            // 
            this.inputImage1.Image = ((System.Drawing.Image)(resources.GetObject("inputImage1.Image")));
            this.inputImage1.Name = "inputImage1";
            // 
            // inputSeparator1
            // 
            this.inputSeparator1.Name = "inputSeparator1";
            // 
            // inputLabel10
            // 
            this.inputLabel10.Name = "inputLabel10";
            this.inputLabel10.Text = "&Button";
            this.inputLabel10.Width = 100;
            // 
            // inputButton1
            // 
            this.inputButton1.Image = ((System.Drawing.Image)(resources.GetObject("inputButton1.Image")));
            this.inputButton1.ImageAlign = C1.Win.C1InputPanel.InputImageAlignment.MiddleRight;
            this.inputButton1.Name = "inputButton1";
            this.inputButton1.Text = "Submit";
            // 
            // inputLabel14
            // 
            this.inputLabel14.Name = "inputLabel14";
            this.inputLabel14.Text = "&SplitButton";
            this.inputLabel14.Width = 100;
            // 
            // inputSplitButton2
            // 
            this.inputSplitButton2.Image = ((System.Drawing.Image)(resources.GetObject("inputSplitButton2.Image")));
            this.inputSplitButton2.Items.Add(this.inputButton4);
            this.inputSplitButton2.Items.Add(this.inputButton5);
            this.inputSplitButton2.Name = "inputSplitButton2";
            this.inputSplitButton2.Text = "Save...";
            // 
            // inputButton4
            // 
            this.inputButton4.Image = ((System.Drawing.Image)(resources.GetObject("inputButton4.Image")));
            this.inputButton4.Name = "inputButton4";
            this.inputButton4.Text = "Save As";
            // 
            // inputButton5
            // 
            this.inputButton5.Image = ((System.Drawing.Image)(resources.GetObject("inputButton5.Image")));
            this.inputButton5.Name = "inputButton5";
            this.inputButton5.Text = "Save Workspace";
            // 
            // inputLabel13
            // 
            this.inputLabel13.Name = "inputLabel13";
            this.inputLabel13.Text = "Men&u";
            this.inputLabel13.Width = 100;
            // 
            // inputMenu1
            // 
            this.inputMenu1.Items.Add(this.inputGroupHeader2);
            this.inputMenu1.Items.Add(this.inputButton2);
            this.inputMenu1.Items.Add(this.inputButton3);
            this.inputMenu1.Items.Add(this.inputSeparator2);
            this.inputMenu1.Items.Add(this.inputSplitButton1);
            this.inputMenu1.Name = "inputMenu1";
            this.inputMenu1.Text = "Options";
            this.inputMenu1.Width = 100;
            // 
            // inputGroupHeader2
            // 
            this.inputGroupHeader2.Name = "inputGroupHeader2";
            this.inputGroupHeader2.Text = "Proofing";
            // 
            // inputButton2
            // 
            this.inputButton2.Image = ((System.Drawing.Image)(resources.GetObject("inputButton2.Image")));
            this.inputButton2.Name = "inputButton2";
            this.inputButton2.Text = "Spell-Check";
            // 
            // inputButton3
            // 
            this.inputButton3.Image = ((System.Drawing.Image)(resources.GetObject("inputButton3.Image")));
            this.inputButton3.Name = "inputButton3";
            this.inputButton3.Text = "Clear Fields";
            // 
            // inputSeparator2
            // 
            this.inputSeparator2.Name = "inputSeparator2";
            // 
            // inputSplitButton1
            // 
            this.inputSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("inputSplitButton1.Image")));
            this.inputSplitButton1.Items.Add(this.inputButton6);
            this.inputSplitButton1.Items.Add(this.inputButton7);
            this.inputSplitButton1.Name = "inputSplitButton1";
            this.inputSplitButton1.Text = "Save...";
            // 
            // inputButton6
            // 
            this.inputButton6.Image = ((System.Drawing.Image)(resources.GetObject("inputButton6.Image")));
            this.inputButton6.Name = "inputButton6";
            this.inputButton6.Text = "Save As";
            // 
            // inputButton7
            // 
            this.inputButton7.Image = ((System.Drawing.Image)(resources.GetObject("inputButton7.Image")));
            this.inputButton7.Name = "inputButton7";
            this.inputButton7.Text = "Save Workspace";
            // 
            // inputLabel15
            // 
            this.inputLabel15.Name = "inputLabel15";
            this.inputLabel15.Text = "Tr&ackBar";
            this.inputLabel15.Width = 100;
            // 
            // inputTrackBar1
            // 
            this.inputTrackBar1.Name = "inputTrackBar1";
            // 
            // inputLabel18
            // 
            this.inputLabel18.Name = "inputLabel18";
            this.inputLabel18.Text = "ProgressBar";
            this.inputLabel18.Width = 100;
            // 
            // inputProgressBar1
            // 
            this.inputProgressBar1.Name = "inputProgressBar1";
            this.inputProgressBar1.Value = 75;
            // 
            // inputGroupHeader3
            // 
            this.inputGroupHeader3.Collapsible = true;
            this.inputGroupHeader3.Name = "inputGroupHeader3";
            this.inputGroupHeader3.Text = "Collapsible Header";
            // 
            // inputLabel16
            // 
            this.inputLabel16.Name = "inputLabel16";
            this.inputLabel16.Text = "DataNavigator";
            this.inputLabel16.Width = 100;
            // 
            // inputDataNavigator1
            // 
            this.inputDataNavigator1.AddNewImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.AddNewImage")));
            this.inputDataNavigator1.AddNewToolTip = "Add New";
            this.inputDataNavigator1.ApplyImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.ApplyImage")));
            this.inputDataNavigator1.ApplyToolTip = "Apply Changes";
            this.inputDataNavigator1.CancelImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.CancelImage")));
            this.inputDataNavigator1.CancelToolTip = "Cancel Changes";
            this.inputDataNavigator1.DeleteImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.DeleteImage")));
            this.inputDataNavigator1.DeleteToolTip = "Delete";
            this.inputDataNavigator1.MoveFirstImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.MoveFirstImage")));
            this.inputDataNavigator1.MoveFirstToolTip = "Move First";
            this.inputDataNavigator1.MoveLastImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.MoveLastImage")));
            this.inputDataNavigator1.MoveLastToolTip = "Move Last";
            this.inputDataNavigator1.MoveNextImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.MoveNextImage")));
            this.inputDataNavigator1.MoveNextToolTip = "Move Next";
            this.inputDataNavigator1.MovePreviousImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.MovePreviousImage")));
            this.inputDataNavigator1.MovePreviousToolTip = "Move Previous";
            this.inputDataNavigator1.Name = "inputDataNavigator1";
            this.inputDataNavigator1.ReloadImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.ReloadImage")));
            this.inputDataNavigator1.ReloadToolTip = "Reload Data";
            this.inputDataNavigator1.SaveImage = ((System.Drawing.Image)(resources.GetObject("inputDataNavigator1.SaveImage")));
            this.inputDataNavigator1.SaveToolTip = "Save Data";
            // 
            // inputLabel1
            // 
            this.inputLabel1.Name = "inputLabel1";
            this.inputLabel1.Text = "These are all of the built-in editor types found in C1InputPanel.";
            // 
            // Overview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 446);
            this.Controls.Add(this.c1InputPanel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Overview";
            this.Text = "Overview";
            ((System.ComponentModel.ISupportInitialize)(this.c1InputPanel1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1InputPanel.C1InputPanel c1InputPanel1;
        private C1.Win.C1InputPanel.InputGroupHeader inputGroupHeader1;
        private C1.Win.C1InputPanel.InputLabel inputLabel2;
        private C1.Win.C1InputPanel.InputTextBox inputTextBox1;
        private C1.Win.C1InputPanel.InputLabel inputLabel3;
        private C1.Win.C1InputPanel.InputNumericBox inputNumericBox1;
        private C1.Win.C1InputPanel.InputLabel inputLabel4;
        private C1.Win.C1InputPanel.InputMaskedTextBox inputMaskedTextBox1;
        private C1.Win.C1InputPanel.InputLabel inputLabel5;
        private C1.Win.C1InputPanel.InputDatePicker inputDatePicker1;
        private C1.Win.C1InputPanel.InputLabel inputLabel6;
        private C1.Win.C1InputPanel.InputTimePicker inputTimePicker1;
        private C1.Win.C1InputPanel.InputLabel inputLabel7;
        private C1.Win.C1InputPanel.InputComboBox inputComboBox2;
        private C1.Win.C1InputPanel.InputSeparator inputSeparator1;
        private C1.Win.C1InputPanel.InputOption inputOption5;
        private C1.Win.C1InputPanel.InputOption inputOption6;
        private C1.Win.C1InputPanel.InputOption inputOption7;
        private C1.Win.C1InputPanel.InputLabel inputLabel8;
        private C1.Win.C1InputPanel.InputRadioButton inputRadioButton1;
        private C1.Win.C1InputPanel.InputRadioButton inputRadioButton2;
        private C1.Win.C1InputPanel.InputLabel inputLabel9;
        private C1.Win.C1InputPanel.InputCheckBox inputCheckBox1;
        private C1.Win.C1InputPanel.InputLabel inputLabel10;
        private C1.Win.C1InputPanel.InputButton inputButton1;
        private C1.Win.C1InputPanel.InputLabel inputLabel11;
        private C1.Win.C1InputPanel.InputHtmlLabel inputHtmlLabel1;
        private C1.Win.C1InputPanel.InputLabel inputLabel12;
        private C1.Win.C1InputPanel.InputImage inputImage1;
        private C1.Win.C1InputPanel.InputLabel inputLabel13;
        private C1.Win.C1InputPanel.InputMenu inputMenu1;
        private C1.Win.C1InputPanel.InputLabel inputLabel14;
        private C1.Win.C1InputPanel.InputSplitButton inputSplitButton2;
        private C1.Win.C1InputPanel.InputGroupHeader inputGroupHeader2;
        private C1.Win.C1InputPanel.InputButton inputButton2;
        private C1.Win.C1InputPanel.InputButton inputButton3;
        private C1.Win.C1InputPanel.InputSeparator inputSeparator2;
        private C1.Win.C1InputPanel.InputSplitButton inputSplitButton1;
        private C1.Win.C1InputPanel.InputLabel inputLabel15;
        private C1.Win.C1InputPanel.InputTrackBar inputTrackBar1;
        private C1.Win.C1InputPanel.InputLabel inputLabel16;
        private C1.Win.C1InputPanel.InputDataNavigator inputDataNavigator1;
        private C1.Win.C1InputPanel.InputProgressBar inputProgressBar1;
        private C1.Win.C1InputPanel.InputLabel inputLabel18;
        private C1.Win.C1InputPanel.InputButton inputButton4;
        private C1.Win.C1InputPanel.InputButton inputButton5;
        private C1.Win.C1InputPanel.InputButton inputButton6;
        private C1.Win.C1InputPanel.InputButton inputButton7;
        private C1.Win.C1InputPanel.InputLabel inputLabel19;
        private C1.Win.C1InputPanel.InputComboBox inputComboBox3;
        private C1.Win.C1InputPanel.InputOption inputOption8;
        private C1.Win.C1InputPanel.InputOption inputOption9;
        private C1.Win.C1InputPanel.InputOption inputOption10;
        private C1.Win.C1InputPanel.InputGroupHeader inputGroupHeader3;
        private C1.Win.C1InputPanel.InputLabel inputLabel1;
    }
}