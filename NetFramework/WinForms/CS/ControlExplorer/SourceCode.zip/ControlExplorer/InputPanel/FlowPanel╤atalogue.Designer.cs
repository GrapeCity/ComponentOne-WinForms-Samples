﻿
namespace ControlExplorer.InputPanel
{
    partial class FlowPanelСatalogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.c1InputPanel1 = new C1.Win.C1InputPanel.C1InputPanel();
            this.inputFlowPanel1 = new C1.Win.C1InputPanel.InputFlowPanel();
            ((System.ComponentModel.ISupportInitialize)(this.c1InputPanel1)).BeginInit();
            this.SuspendLayout();
            // 
            // c1InputPanel1
            // 
            //this.c1InputPanel1.AutoSizeElement = C1.Framework.AutoSizeElement.Both;
            this.c1InputPanel1.Font = new System.Drawing.Font("Segoe UI", 9F);
           // this.c1InputPanel1.Items.Add(this.inputFlowPanel1);
            this.c1InputPanel1.Location = new System.Drawing.Point(0, 0);
            this.c1InputPanel1.Name = "c1InputPanel1";
            //this.c1InputPanel1.Size = new System.Drawing.Size(890, 500);
            this.c1InputPanel1.TabIndex = 4;
            // 
            // inputFlowPanel1
            // 
            this.inputFlowPanel1.ChildSpacing = new System.Drawing.Size(15, 15);
            this.inputFlowPanel1.Height = -1;
            this.inputFlowPanel1.Name = "inputFlowPanel1";
            // 
            // FlowPanelСatalogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            //this.ClientSize = new System.Drawing.Size(1302, 331);
            //this.Controls.Add(this.c1InputPanel1);
            //this.Name = "FlowPanelСatalogue";
            this.Text = "Catalogue";
            this.Load += new System.EventHandler(this.FlowPanelСatalogue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1InputPanel1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1InputPanel.C1InputPanel c1InputPanel1;
        private C1.Win.C1InputPanel.InputFlowPanel inputFlowPanel1;

    }
}
