namespace ControlExplorer.Sizer
{
    partial class SizerNewFeatures
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Drawing.Drawing2D.Blend blend5 = new System.Drawing.Drawing2D.Blend();
            System.Drawing.Drawing2D.Blend blend1 = new System.Drawing.Drawing2D.Blend();
            System.Drawing.Drawing2D.Blend blend2 = new System.Drawing.Drawing2D.Blend();
            System.Drawing.Drawing2D.Blend blend3 = new System.Drawing.Drawing2D.Blend();
            System.Drawing.Drawing2D.Blend blend4 = new System.Drawing.Drawing2D.Blend();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SizerNewFeatures));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.c1Sizer1 = new C1.Win.C1Sizer.C1Sizer();
            this.c1Sizer9 = new C1.Win.C1Sizer.C1Sizer();
            this.c1Sizer4 = new C1.Win.C1Sizer.C1Sizer();
            this.button13 = new C1.Win.C1Input.C1Button();
            this.button12 = new C1.Win.C1Input.C1Button();
            this.button11 = new C1.Win.C1Input.C1Button();
            this.button10 = new C1.Win.C1Input.C1Button();
            this.button9 = new C1.Win.C1Input.C1Button();
            this.button8 = new C1.Win.C1Input.C1Button();
            this.c1Sizer6 = new C1.Win.C1Sizer.C1Sizer();
            this.button7 = new C1.Win.C1Input.C1Button();
            this.button6 = new C1.Win.C1Input.C1Button();
            this.button5 = new C1.Win.C1Input.C1Button();
            this.button4 = new C1.Win.C1Input.C1Button();
            this.c1Sizer2 = new C1.Win.C1Sizer.C1Sizer();
            this.c1Sizer3 = new C1.Win.C1Sizer.C1Sizer();
            this.button25 = new C1.Win.C1Input.C1Button();
            this.button24 = new C1.Win.C1Input.C1Button();
            this.button23 = new C1.Win.C1Input.C1Button();
            this.button22 = new C1.Win.C1Input.C1Button();
            this.button3 = new C1.Win.C1Input.C1Button();
            this.button2 = new C1.Win.C1Input.C1Button();
            this.c1Sizer5 = new C1.Win.C1Sizer.C1Sizer();
            this.button21 = new C1.Win.C1Input.C1Button();
            this.button20 = new C1.Win.C1Input.C1Button();
            this.button19 = new C1.Win.C1Input.C1Button();
            this.button18 = new C1.Win.C1Input.C1Button();
            this.button17 = new C1.Win.C1Input.C1Button();
            this.button16 = new C1.Win.C1Input.C1Button();
            this.button15 = new C1.Win.C1Input.C1Button();
            this.button14 = new C1.Win.C1Input.C1Button();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer1)).BeginInit();
            this.c1Sizer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer9)).BeginInit();
            this.c1Sizer9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer4)).BeginInit();
            this.c1Sizer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer6)).BeginInit();
            this.c1Sizer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer2)).BeginInit();
            this.c1Sizer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer3)).BeginInit();
            this.c1Sizer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer5)).BeginInit();
            this.c1Sizer5.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // c1Sizer1
            // 
            this.c1Sizer1.Controls.Add(this.c1Sizer9);
            this.c1Sizer1.Controls.Add(this.c1Sizer2);
            this.c1Sizer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Sizer1.Gradient.BackColor2 = System.Drawing.Color.Yellow;
            blend5.Factors = new float[] {
        0F,
        1F};
            blend5.Positions = new float[] {
        0F,
        1F};
            this.c1Sizer1.Gradient.Blend = blend5;
            this.c1Sizer1.GridDefinition = "60.0896860986547:True:False;39.0134529147982:False:False;\t100:False:False;";
            this.c1Sizer1.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer1.Name = "c1Sizer1";
            this.c1Sizer1.Padding = new System.Windows.Forms.Padding(0);
            this.c1Sizer1.Size = new System.Drawing.Size(592, 446);
            this.c1Sizer1.TabIndex = 2;
            this.c1Sizer1.Text = "c1Sizer1";
            this.c1Sizer1.SplitterMoved += new C1.Win.C1Sizer.C1SizerEventHandler(this.c1Sizer1_SplitterMoved);
            // 
            // c1Sizer9
            // 
            this.c1Sizer9.Controls.Add(this.c1Sizer4);
            this.c1Sizer9.Controls.Add(this.c1Sizer6);
            this.c1Sizer9.GridDefinition = "100:False:False;\t64.0202702702703:True:False;35.3040540540541:False:False;";
            this.c1Sizer9.Location = new System.Drawing.Point(0, 272);
            this.c1Sizer9.Name = "c1Sizer9";
            this.c1Sizer9.Padding = new System.Windows.Forms.Padding(0);
            this.c1Sizer9.Size = new System.Drawing.Size(592, 174);
            this.c1Sizer9.TabIndex = 6;
            this.c1Sizer9.Text = "c1Sizer9";
            this.c1Sizer9.SplitterMoved += new C1.Win.C1Sizer.C1SizerEventHandler(this.c1Sizer9_SplitterMoved);
            // 
            // c1Sizer4
            // 
            this.c1Sizer4.BackColor = System.Drawing.Color.Black;
            this.c1Sizer4.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer4.Border.Corners = new C1.Win.C1Sizer.Corners(20, 20, 0, 0);
            this.c1Sizer4.Border.Thickness = new System.Windows.Forms.Padding(5);
            this.c1Sizer4.Controls.Add(this.button13);
            this.c1Sizer4.Controls.Add(this.button12);
            this.c1Sizer4.Controls.Add(this.button11);
            this.c1Sizer4.Controls.Add(this.button10);
            this.c1Sizer4.Controls.Add(this.button9);
            this.c1Sizer4.Controls.Add(this.button8);
            this.c1Sizer4.Gradient.BackColor2 = System.Drawing.Color.LimeGreen;
            blend1.Factors = new float[] {
        0F,
        1F};
            blend1.Positions = new float[] {
        0F,
        1F};
            this.c1Sizer4.Gradient.Blend = blend1;
            this.c1Sizer4.Gradient.Mode = C1.Win.C1Sizer.GradientMode.Radial;
            this.c1Sizer4.GridDefinition = "13.7931034482759:False:False;35.0574712643678:False:False;13.7931034482759:False:" +
                "True;15.5172413793103:False:True;\t28.4960422163588:False:True;19.5250659630607:F" +
                "alse:False;43.0079155672823:False:True;";
            this.c1Sizer4.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer4.Name = "c1Sizer4";
            this.c1Sizer4.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer4.Size = new System.Drawing.Size(379, 174);
            this.c1Sizer4.TabIndex = 2;
            this.c1Sizer4.Text = "c1Sizer4";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(13, 13);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(108, 24);
            this.button13.TabIndex = 5;
            this.button13.Text = "Fixed Width";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(13, 41);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(353, 61);
            this.button12.TabIndex = 4;
            this.button12.Text = "Free";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(13, 106);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(186, 55);
            this.button11.TabIndex = 3;
            this.button11.Text = "Fixed Height";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(125, 13);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(241, 24);
            this.button10.TabIndex = 2;
            this.button10.Text = "Free";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(203, 106);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(163, 24);
            this.button9.TabIndex = 1;
            this.button9.Text = "Fixed Width && Height";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(203, 134);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(163, 27);
            this.button8.TabIndex = 0;
            this.button8.Text = "Fixed Width && Height";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // c1Sizer6
            // 
            this.c1Sizer6.BackColor = System.Drawing.Color.LavenderBlush;
            this.c1Sizer6.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer6.Border.Corners = new C1.Win.C1Sizer.Corners(20, 20, 0, 0);
            this.c1Sizer6.Border.Thickness = new System.Windows.Forms.Padding(5);
            this.c1Sizer6.Controls.Add(this.button7);
            this.c1Sizer6.Controls.Add(this.button6);
            this.c1Sizer6.Controls.Add(this.button5);
            this.c1Sizer6.Controls.Add(this.button4);
            this.c1Sizer6.Gradient.BackColor2 = System.Drawing.Color.Orchid;
            blend2.Factors = new float[] {
        1F,
        0.4345982F,
        0.1888756F,
        0.082085F,
        0.03567399F,
        0.01550385F,
        0.006737947F};
            blend2.Positions = new float[] {
        0F,
        0.1666667F,
        0.3333333F,
        0.5F,
        0.6666667F,
        0.8333333F,
        1F};
            this.c1Sizer6.Gradient.Blend = blend2;
            this.c1Sizer6.Gradient.Center = new System.Drawing.Point(51, 55);
            this.c1Sizer6.Gradient.Mode = C1.Win.C1Sizer.GradientMode.Radial;
            this.c1Sizer6.GridDefinition = "12.0689655172414:False:True;46.551724137931:False:False;21.8390804597701:False:Tr" +
                "ue;\t49.7607655502392:False:True;35.8851674641148:False:False;";
            this.c1Sizer6.Location = new System.Drawing.Point(383, 0);
            this.c1Sizer6.Name = "c1Sizer6";
            this.c1Sizer6.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer6.Size = new System.Drawing.Size(209, 174);
            this.c1Sizer6.TabIndex = 4;
            this.c1Sizer6.Text = "c1Sizer6";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(13, 13);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(183, 21);
            this.button7.TabIndex = 3;
            this.button7.Text = "Fixed Height";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(121, 38);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 81);
            this.button6.TabIndex = 2;
            this.button6.Text = "Free";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(13, 123);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(183, 38);
            this.button5.TabIndex = 1;
            this.button5.Text = "Fixed Height";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(13, 38);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 81);
            this.button4.TabIndex = 0;
            this.button4.Text = "Fixed Width";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // c1Sizer2
            // 
            this.c1Sizer2.Controls.Add(this.c1Sizer3);
            this.c1Sizer2.Controls.Add(this.c1Sizer5);
            this.c1Sizer2.GridDefinition = "100:False:False;\t28.8851351351351:True:False;70.4391891891892:False:False;";
            this.c1Sizer2.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer2.Name = "c1Sizer2";
            this.c1Sizer2.Padding = new System.Windows.Forms.Padding(0);
            this.c1Sizer2.Size = new System.Drawing.Size(592, 268);
            this.c1Sizer2.TabIndex = 5;
            this.c1Sizer2.Text = "c1Sizer2";
            this.c1Sizer2.SplitterMoved += new C1.Win.C1Sizer.C1SizerEventHandler(this.c1Sizer2_SplitterMoved);
            // 
            // c1Sizer3
            // 
            this.c1Sizer3.BackColor = System.Drawing.Color.OrangeRed;
            this.c1Sizer3.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer3.Border.Corners = new C1.Win.C1Sizer.Corners(10, 10, 10, 10);
            this.c1Sizer3.Border.Thickness = new System.Windows.Forms.Padding(5);
            this.c1Sizer3.Controls.Add(this.button25);
            this.c1Sizer3.Controls.Add(this.button24);
            this.c1Sizer3.Controls.Add(this.button23);
            this.c1Sizer3.Controls.Add(this.button22);
            this.c1Sizer3.Controls.Add(this.button3);
            this.c1Sizer3.Controls.Add(this.button2);
            this.c1Sizer3.Gradient.BackColor2 = System.Drawing.Color.Yellow;
            blend3.Factors = new float[] {
        0F,
        1F};
            blend3.Positions = new float[] {
        0F,
        1F};
            this.c1Sizer3.Gradient.Blend = blend3;
            this.c1Sizer3.Gradient.Mode = C1.Win.C1Sizer.GradientMode.DiagonalUp;
            this.c1Sizer3.GridDefinition = "39.5522388059701:False:True;6.71641791044776:False:False;8.2089552238806:False:Tr" +
                "ue;13.4328358208955:False:True;16.4179104477612:False:False;\t35.672514619883:Fal" +
                "se:False;46.7836257309942:False:True;";
            this.c1Sizer3.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer3.Name = "c1Sizer3";
            this.c1Sizer3.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer3.Size = new System.Drawing.Size(171, 268);
            this.c1Sizer3.TabIndex = 1;
            this.c1Sizer3.Text = "c1Sizer3";
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(13, 171);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(61, 36);
            this.button25.TabIndex = 10;
            this.button25.Text = "Fixed Height";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(78, 145);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(80, 62);
            this.button24.TabIndex = 9;
            this.button24.Text = "Fixed Width && Height";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(13, 211);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(145, 44);
            this.button23.TabIndex = 8;
            this.button23.Text = "Free";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(13, 123);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(61, 44);
            this.button22.TabIndex = 7;
            this.button22.Text = "Free";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(78, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 128);
            this.button3.TabIndex = 6;
            this.button3.Text = "Fixed Width";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(13, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(61, 106);
            this.button2.TabIndex = 5;
            this.button2.Text = "Fixed Height";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // c1Sizer5
            // 
            this.c1Sizer5.BackColor = System.Drawing.Color.LightCyan;
            this.c1Sizer5.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer5.Border.Corners = new C1.Win.C1Sizer.Corners(0, 30, 30, 0);
            this.c1Sizer5.Border.Thickness = new System.Windows.Forms.Padding(6);
            this.c1Sizer5.Controls.Add(this.button21);
            this.c1Sizer5.Controls.Add(this.button20);
            this.c1Sizer5.Controls.Add(this.button19);
            this.c1Sizer5.Controls.Add(this.button18);
            this.c1Sizer5.Controls.Add(this.button17);
            this.c1Sizer5.Controls.Add(this.button16);
            this.c1Sizer5.Controls.Add(this.button15);
            this.c1Sizer5.Controls.Add(this.button14);
            this.c1Sizer5.Gradient.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            blend4.Factors = new float[] {
        0F,
        0.75F,
        0.25F,
        0F,
        0.59F,
        1F};
            blend4.Positions = new float[] {
        0F,
        0.25F,
        0.49F,
        0.51F,
        0.75F,
        1F};
            this.c1Sizer5.Gradient.Blend = blend4;
            this.c1Sizer5.Gradient.Mode = C1.Win.C1Sizer.GradientMode.DiagonalDown;
            this.c1Sizer5.GridDefinition = resources.GetString("c1Sizer5.GridDefinition");
            this.c1Sizer5.Location = new System.Drawing.Point(175, 0);
            this.c1Sizer5.Name = "c1Sizer5";
            this.c1Sizer5.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer5.Size = new System.Drawing.Size(417, 268);
            this.c1Sizer5.TabIndex = 3;
            this.c1Sizer5.Text = "c1Sizer5";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(330, 214);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(73, 40);
            this.button21.TabIndex = 7;
            this.button21.Text = "Fixed Width && Height";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(241, 214);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(85, 40);
            this.button20.TabIndex = 6;
            this.button20.Text = "Fixed Width && Height";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(96, 214);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(141, 40);
            this.button19.TabIndex = 5;
            this.button19.Text = "Fixed Height";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(96, 184);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(307, 26);
            this.button18.TabIndex = 4;
            this.button18.Text = "Fixed Height";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(96, 45);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(307, 135);
            this.button17.TabIndex = 3;
            this.button17.Text = "Free";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(14, 184);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(78, 70);
            this.button16.TabIndex = 2;
            this.button16.Text = "Fixed Width && Height";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(14, 45);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(78, 135);
            this.button15.TabIndex = 1;
            this.button15.Text = "Fixed Width";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(14, 14);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(389, 27);
            this.button14.TabIndex = 0;
            this.button14.Text = "Fixed Height";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // SizerNewFeatures
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(592, 446);
            this.Controls.Add(this.c1Sizer1);
            this.Name = "SizerNewFeatures";
            this.Load += new System.EventHandler(this.SizerNewFeatures_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer1)).EndInit();
            this.c1Sizer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer9)).EndInit();
            this.c1Sizer9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer4)).EndInit();
            this.c1Sizer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer6)).EndInit();
            this.c1Sizer6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer2)).EndInit();
            this.c1Sizer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer3)).EndInit();
            this.c1Sizer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer5)).EndInit();
            this.c1Sizer5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private C1.Win.C1Sizer.C1Sizer c1Sizer1;
        private C1.Win.C1Sizer.C1Sizer c1Sizer9;
        private C1.Win.C1Sizer.C1Sizer c1Sizer4;
        private C1.Win.C1Input.C1Button button13;
        private C1.Win.C1Input.C1Button button12;
        private C1.Win.C1Input.C1Button button11;
        private C1.Win.C1Input.C1Button button10;
        private C1.Win.C1Input.C1Button button9;
        private C1.Win.C1Input.C1Button button8;
        private C1.Win.C1Sizer.C1Sizer c1Sizer6;
        private C1.Win.C1Input.C1Button button7;
        private C1.Win.C1Input.C1Button button6;
        private C1.Win.C1Input.C1Button button5;
        private C1.Win.C1Input.C1Button button4;
        private C1.Win.C1Sizer.C1Sizer c1Sizer2;
        private C1.Win.C1Sizer.C1Sizer c1Sizer3;
        private C1.Win.C1Input.C1Button button25;
        private C1.Win.C1Input.C1Button button24;
        private C1.Win.C1Input.C1Button button23;
        private C1.Win.C1Input.C1Button button22;
        private C1.Win.C1Input.C1Button button3;
        private C1.Win.C1Input.C1Button button2;
        private C1.Win.C1Sizer.C1Sizer c1Sizer5;
        private C1.Win.C1Input.C1Button button21;
        private C1.Win.C1Input.C1Button button20;
        private C1.Win.C1Input.C1Button button19;
        private C1.Win.C1Input.C1Button button18;
        private C1.Win.C1Input.C1Button button17;
        private C1.Win.C1Input.C1Button button16;
        private C1.Win.C1Input.C1Button button15;
        private C1.Win.C1Input.C1Button button14;
    }
}
