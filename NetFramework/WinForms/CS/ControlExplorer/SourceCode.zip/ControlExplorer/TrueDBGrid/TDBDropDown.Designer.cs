﻿namespace ControlExplorer.TrueDBGrid
{
    partial class TDBDropDown
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C1.Win.C1TrueDBGrid.Style style1 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style2 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style3 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style4 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style5 = new C1.Win.C1TrueDBGrid.Style();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TDBDropDown));
            C1.Win.C1TrueDBGrid.Style style6 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style7 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style8 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style9 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style10 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style11 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style12 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style13 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style14 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style15 = new C1.Win.C1TrueDBGrid.Style();
            C1.Win.C1TrueDBGrid.Style style16 = new C1.Win.C1TrueDBGrid.Style();
            this.c1TrueDBDropdown2 = new C1.Win.C1TrueDBGrid.C1TrueDBDropdown();
            this.c1TrueDBDropdown1 = new C1.Win.C1TrueDBGrid.C1TrueDBDropdown();
            this.c1TrueDBGrid1 = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBDropdown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBDropdown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // c1TrueDBDropdown2
            // 
            this.c1TrueDBDropdown2.AllowColMove = true;
            this.c1TrueDBDropdown2.AllowColSelect = true;
            this.c1TrueDBDropdown2.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows;
            this.c1TrueDBDropdown2.AlternatingRows = false;
            this.c1TrueDBDropdown2.CaptionStyle = style1;
            this.c1TrueDBDropdown2.ColumnCaptionHeight = 23;
            this.c1TrueDBDropdown2.ColumnFooterHeight = 17;
            this.c1TrueDBDropdown2.DisplayMember = "LastName";
            this.c1TrueDBDropdown2.EvenRowStyle = style2;
            this.c1TrueDBDropdown2.FetchRowStyles = false;
            this.c1TrueDBDropdown2.FooterStyle = style3;
            this.c1TrueDBDropdown2.HeadingStyle = style4;
            this.c1TrueDBDropdown2.HighLightRowStyle = style5;
            this.c1TrueDBDropdown2.Images.Add(((System.Drawing.Image)(resources.GetObject("c1TrueDBDropdown2.Images"))));
            this.c1TrueDBDropdown2.Location = new System.Drawing.Point(108, 270);
            this.c1TrueDBDropdown2.Name = "c1TrueDBDropdown2";
            this.c1TrueDBDropdown2.OddRowStyle = style6;
            this.c1TrueDBDropdown2.PropBag = resources.GetString("c1TrueDBDropdown2.PropBag");
            this.c1TrueDBDropdown2.RecordSelectorStyle = style7;
            this.c1TrueDBDropdown2.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.c1TrueDBDropdown2.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.Single;
            this.c1TrueDBDropdown2.RowHeight = 22;
            this.c1TrueDBDropdown2.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.c1TrueDBDropdown2.ScrollTips = false;
            this.c1TrueDBDropdown2.Size = new System.Drawing.Size(420, 150);
            this.c1TrueDBDropdown2.Style = style8;
            this.c1TrueDBDropdown2.TabIndex = 2;
            this.c1TrueDBDropdown2.TabStop = false;
            this.c1TrueDBDropdown2.Text = "c1TrueDBDropdown2";
            this.c1TrueDBDropdown2.ValueMember = "EmployeeID";
            this.c1TrueDBDropdown2.ValueTranslate = true;
            this.c1TrueDBDropdown2.Visible = false;
            // 
            // c1TrueDBDropdown1
            // 
            this.c1TrueDBDropdown1.AllowColMove = true;
            this.c1TrueDBDropdown1.AllowColSelect = true;
            this.c1TrueDBDropdown1.AllowRowSizing = C1.Win.C1TrueDBGrid.RowSizingEnum.AllRows;
            this.c1TrueDBDropdown1.AlternatingRows = false;
            this.c1TrueDBDropdown1.CaptionStyle = style9;
            this.c1TrueDBDropdown1.ColumnCaptionHeight = 23;
            this.c1TrueDBDropdown1.ColumnFooterHeight = 17;
            this.c1TrueDBDropdown1.DisplayMember = "CompanyName";
            this.c1TrueDBDropdown1.EvenRowStyle = style10;
            this.c1TrueDBDropdown1.FetchRowStyles = false;
            this.c1TrueDBDropdown1.FooterStyle = style11;
            this.c1TrueDBDropdown1.HeadingStyle = style12;
            this.c1TrueDBDropdown1.HighLightRowStyle = style13;
            this.c1TrueDBDropdown1.Images.Add(((System.Drawing.Image)(resources.GetObject("c1TrueDBDropdown1.Images"))));
            this.c1TrueDBDropdown1.Location = new System.Drawing.Point(28, 240);
            this.c1TrueDBDropdown1.Name = "c1TrueDBDropdown1";
            this.c1TrueDBDropdown1.OddRowStyle = style14;
            this.c1TrueDBDropdown1.PropBag = resources.GetString("c1TrueDBDropdown1.PropBag");
            this.c1TrueDBDropdown1.RecordSelectorStyle = style15;
            this.c1TrueDBDropdown1.RowDivider.Color = System.Drawing.Color.DarkGray;
            this.c1TrueDBDropdown1.RowDivider.Style = C1.Win.C1TrueDBGrid.LineStyleEnum.Single;
            this.c1TrueDBDropdown1.RowHeight = 22;
            this.c1TrueDBDropdown1.RowSubDividerColor = System.Drawing.Color.DarkGray;
            this.c1TrueDBDropdown1.ScrollTips = false;
            this.c1TrueDBDropdown1.Size = new System.Drawing.Size(420, 150);
            this.c1TrueDBDropdown1.Style = style16;
            this.c1TrueDBDropdown1.TabIndex = 1;
            this.c1TrueDBDropdown1.TabStop = false;
            this.c1TrueDBDropdown1.Text = "c1TrueDBDropdown1";
            this.c1TrueDBDropdown1.ValueMember = "CustomerID";
            this.c1TrueDBDropdown1.ValueTranslate = true;
            this.c1TrueDBDropdown1.Visible = false;
            // 
            // c1TrueDBGrid1
            // 
            this.c1TrueDBGrid1.Caption = "Using C1TrueDBDropDown";
            this.c1TrueDBGrid1.CaptionHeight = 17;
            this.c1TrueDBGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1TrueDBGrid1.Images.Add(((System.Drawing.Image)(resources.GetObject("c1TrueDBGrid1.Images"))));
            this.c1TrueDBGrid1.Location = new System.Drawing.Point(0, 0);
            this.c1TrueDBGrid1.Name = "c1TrueDBGrid1";
            this.c1TrueDBGrid1.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.c1TrueDBGrid1.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.c1TrueDBGrid1.PreviewInfo.ZoomFactor = 75D;
            this.c1TrueDBGrid1.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("c1TrueDBGrid1.PrintInfo.PageSettings")));
            this.c1TrueDBGrid1.PropBag = resources.GetString("c1TrueDBGrid1.PropBag");
            this.c1TrueDBGrid1.RecordSelectorWidth = 20;
            this.c1TrueDBGrid1.RowHeight = 20;
            this.c1TrueDBGrid1.Size = new System.Drawing.Size(592, 446);
            this.c1TrueDBGrid1.TabIndex = 0;
            this.c1TrueDBGrid1.Text = "c1TrueDBGrid1";
            // 
            // TDBDropDown
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 446);
            this.Controls.Add(this.c1TrueDBDropdown2);
            this.Controls.Add(this.c1TrueDBDropdown1);
            this.Controls.Add(this.c1TrueDBGrid1);
            this.Name = "TDBDropDown";
            this.Text = "TDBDropDown";
            this.Load += new System.EventHandler(this.TDBDropDown_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBDropdown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBDropdown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1TrueDBGrid.C1TrueDBGrid c1TrueDBGrid1;
        private C1.Win.C1TrueDBGrid.C1TrueDBDropdown c1TrueDBDropdown1;
        private C1.Win.C1TrueDBGrid.C1TrueDBDropdown c1TrueDBDropdown2;

    }
}