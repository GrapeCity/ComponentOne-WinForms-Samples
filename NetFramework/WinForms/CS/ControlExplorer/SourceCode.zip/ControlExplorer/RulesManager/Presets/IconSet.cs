﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlExplorer.RulesManager.Presets
{
    public enum IconSet
    {
        ThreeArrows,
        ThreeTriangles,
        FourArrows,
        FiveArrows,
        ThreeTrafficLightsUnrimmed,
        ThreeTrafficLightsRimmed,
        ThreeSigns,
        ThreeSymbolsCircled,
        ThreeSymbolsUncircled,
        ThreeFlags,
        ThreeStars,
        FiveQuarters,
        FiveRatings,
        FiveBoxes
    }
}
