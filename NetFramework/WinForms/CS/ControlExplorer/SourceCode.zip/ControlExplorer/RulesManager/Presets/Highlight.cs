﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlExplorer.RulesManager.Presets
{
    public enum Highlight
    {
        LightRedFillWithDarkRedText,
        YellowFillWithDarkYellowText,
        GreenFillWithDarkGreenText,
        LightRedFill,
        RedText,
        RedBorder
    }
}
