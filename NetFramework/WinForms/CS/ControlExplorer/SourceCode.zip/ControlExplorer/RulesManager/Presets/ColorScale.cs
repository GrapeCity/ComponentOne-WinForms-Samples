﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlExplorer.RulesManager.Presets
{
    public enum ColorScale
    {
        GreenYellowRed,
        RedYellowGreen,
        GreenWhiteRed,
        RedWhiteGreen,
        BlueWhiteRed,
        RedWhiteBlue,
        WhiteRed,
        RedWhite,
        GreenWhite,
        WhiteGreen,
        GreenYellow,
        YellowGreen
    }
}
