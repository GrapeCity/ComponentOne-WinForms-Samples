﻿namespace ControlExplorer.GanttView
{
    partial class GanttViewDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn1 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn2 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn3 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn4 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn5 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn6 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn7 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn8 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn9 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn10 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn11 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn12 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn13 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn14 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.Task task1 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task2 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task3 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task4 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task5 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task6 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task7 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task8 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task9 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task10 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task11 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task12 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task13 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task14 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task15 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task16 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task17 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task18 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task19 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task20 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task21 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task22 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task23 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task24 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task25 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task26 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task27 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task28 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task29 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task30 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task31 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task32 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task33 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task34 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task35 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task36 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task37 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task38 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task39 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task40 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task41 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task42 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task43 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task44 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task45 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task46 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task47 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task48 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task49 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task50 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task51 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task52 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task53 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task54 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task55 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task56 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task57 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task58 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task59 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task60 = new C1.Win.C1GanttView.Task();
            this.c1GanttView1 = new C1.Win.C1GanttView.C1GanttView();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1)).BeginInit();
            this.SuspendLayout();
            // 
            // c1GanttView1
            // 
            this.c1GanttView1.BackColor = System.Drawing.SystemColors.Window;
            taskPropertyColumn1.Caption = "Task Mode";
            taskPropertyColumn1.ID = 138363861;
            taskPropertyColumn1.Property = C1.Win.C1GanttView.TaskProperty.Mode;
            taskPropertyColumn2.Caption = "Task Name";
            taskPropertyColumn2.ID = 1610966694;
            taskPropertyColumn2.Property = C1.Win.C1GanttView.TaskProperty.Name;
            taskPropertyColumn3.Caption = "Duration";
            taskPropertyColumn3.ID = 596860248;
            taskPropertyColumn3.Property = C1.Win.C1GanttView.TaskProperty.Duration;
            taskPropertyColumn3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            taskPropertyColumn3.Visible = false;
            taskPropertyColumn4.Caption = "Duration Units";
            taskPropertyColumn4.ID = 1322201439;
            taskPropertyColumn4.Property = C1.Win.C1GanttView.TaskProperty.DurationUnits;
            taskPropertyColumn4.Visible = false;
            taskPropertyColumn5.Caption = "Start";
            taskPropertyColumn5.ID = 557656400;
            taskPropertyColumn5.Property = C1.Win.C1GanttView.TaskProperty.Start;
            taskPropertyColumn5.Visible = false;
            taskPropertyColumn6.Caption = "Finish";
            taskPropertyColumn6.ID = 1693626873;
            taskPropertyColumn6.Property = C1.Win.C1GanttView.TaskProperty.Finish;
            taskPropertyColumn6.Visible = false;
            taskPropertyColumn7.Caption = "% Complete";
            taskPropertyColumn7.ID = 1286460094;
            taskPropertyColumn7.Property = C1.Win.C1GanttView.TaskProperty.PercentComplete;
            taskPropertyColumn7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            taskPropertyColumn7.Visible = false;
            taskPropertyColumn8.Caption = "Constraint Type";
            taskPropertyColumn8.ID = 75260408;
            taskPropertyColumn8.Property = C1.Win.C1GanttView.TaskProperty.ConstraintType;
            taskPropertyColumn8.Visible = false;
            taskPropertyColumn9.Caption = "Constraint Date";
            taskPropertyColumn9.ID = 1865906439;
            taskPropertyColumn9.Property = C1.Win.C1GanttView.TaskProperty.ConstraintDate;
            taskPropertyColumn9.Visible = false;
            taskPropertyColumn10.Caption = "Predecessors";
            taskPropertyColumn10.ID = 1740914904;
            taskPropertyColumn10.Property = C1.Win.C1GanttView.TaskProperty.Predecessors;
            taskPropertyColumn10.Visible = false;
            taskPropertyColumn11.Caption = "Deadline";
            taskPropertyColumn11.ID = 1361526201;
            taskPropertyColumn11.Property = C1.Win.C1GanttView.TaskProperty.Deadline;
            taskPropertyColumn11.Visible = false;
            taskPropertyColumn12.Caption = "Calendar";
            taskPropertyColumn12.ID = 273762191;
            taskPropertyColumn12.Property = C1.Win.C1GanttView.TaskProperty.Calendar;
            taskPropertyColumn12.Visible = false;
            taskPropertyColumn13.Caption = "Resource Names";
            taskPropertyColumn13.ID = 1753264019;
            taskPropertyColumn13.Property = C1.Win.C1GanttView.TaskProperty.ResourceNames;
            taskPropertyColumn13.Visible = false;
            taskPropertyColumn14.Caption = "Notes";
            taskPropertyColumn14.ID = 1536890612;
            taskPropertyColumn14.Property = C1.Win.C1GanttView.TaskProperty.Notes;
            taskPropertyColumn14.Visible = false;
            this.c1GanttView1.Columns.Add(taskPropertyColumn1);
            this.c1GanttView1.Columns.Add(taskPropertyColumn2);
            this.c1GanttView1.Columns.Add(taskPropertyColumn3);
            this.c1GanttView1.Columns.Add(taskPropertyColumn4);
            this.c1GanttView1.Columns.Add(taskPropertyColumn5);
            this.c1GanttView1.Columns.Add(taskPropertyColumn6);
            this.c1GanttView1.Columns.Add(taskPropertyColumn7);
            this.c1GanttView1.Columns.Add(taskPropertyColumn8);
            this.c1GanttView1.Columns.Add(taskPropertyColumn9);
            this.c1GanttView1.Columns.Add(taskPropertyColumn10);
            this.c1GanttView1.Columns.Add(taskPropertyColumn11);
            this.c1GanttView1.Columns.Add(taskPropertyColumn12);
            this.c1GanttView1.Columns.Add(taskPropertyColumn13);
            this.c1GanttView1.Columns.Add(taskPropertyColumn14);
            this.c1GanttView1.DefaultWorkingTimes.Interval_1.Empty = false;
            this.c1GanttView1.DefaultWorkingTimes.Interval_1.From = new System.DateTime(1, 1, 1, 9, 0, 0, 0);
            this.c1GanttView1.DefaultWorkingTimes.Interval_1.To = new System.DateTime(1, 1, 1, 13, 0, 0, 0);
            this.c1GanttView1.DefaultWorkingTimes.Interval_2.Empty = false;
            this.c1GanttView1.DefaultWorkingTimes.Interval_2.From = new System.DateTime(1, 1, 1, 14, 0, 0, 0);
            this.c1GanttView1.DefaultWorkingTimes.Interval_2.To = new System.DateTime(1, 1, 1, 18, 0, 0, 0);
            this.c1GanttView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1GanttView1.FixedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(237)))));
            this.c1GanttView1.Location = new System.Drawing.Point(0, 0);
            this.c1GanttView1.Name = "c1GanttView1";
            this.c1GanttView1.Size = new System.Drawing.Size(526, 367);
            this.c1GanttView1.StartDate = new System.DateTime(2012, 6, 19, 0, 0, 0, 0);
            this.c1GanttView1.TabIndex = 0;
            task1.ID = 1043157751;
            task2.ID = 85205305;
            task3.ID = 1694617920;
            task4.ID = 2057552532;
            task5.ID = 1924700933;
            task6.ID = 620404982;
            task7.ID = 117809017;
            task8.ID = 349037338;
            task9.ID = 1746817701;
            task10.ID = 562444048;
            task11.ID = 772200645;
            task12.ID = 709495941;
            task13.ID = 1030869519;
            task14.ID = 1504090170;
            task15.ID = 882044215;
            task16.ID = 722138024;
            task17.ID = 90488149;
            task18.ID = 2024720520;
            task19.ID = 1884816981;
            task20.ID = 999993386;
            task21.ID = 1557082822;
            task22.ID = 1111353325;
            task23.ID = 1491734462;
            task24.ID = 2113894062;
            task25.ID = 805673655;
            task26.ID = 1222656908;
            task27.ID = 1097534470;
            task28.ID = 1702553923;
            task29.ID = 1828829627;
            task30.ID = 491954284;
            task31.ID = 1168919790;
            task32.ID = 1455412781;
            task33.ID = 2145416648;
            task34.ID = 909512129;
            task35.ID = 1349535258;
            task36.ID = 1934199994;
            task37.ID = 1758168285;
            task38.ID = 629380785;
            task39.ID = 571158496;
            task40.ID = 1559324083;
            task41.ID = 2112353178;
            task42.ID = 1936810171;
            task43.ID = 2011632641;
            task44.ID = 34416201;
            task45.ID = 550000795;
            task46.ID = 1995644107;
            task47.ID = 662757355;
            task48.ID = 1929853572;
            task49.ID = 1340699841;
            task50.ID = 1143768416;
            task51.ID = 1650426756;
            task52.ID = 1484289329;
            task53.ID = 536428858;
            task54.ID = 753270634;
            task55.ID = 2127291438;
            task56.ID = 2079288074;
            task57.ID = 740954491;
            task58.ID = 1728207506;
            task59.ID = 1251878878;
            task60.ID = 702044026;
            this.c1GanttView1.Tasks.Add(task1);
            this.c1GanttView1.Tasks.Add(task2);
            this.c1GanttView1.Tasks.Add(task3);
            this.c1GanttView1.Tasks.Add(task4);
            this.c1GanttView1.Tasks.Add(task5);
            this.c1GanttView1.Tasks.Add(task6);
            this.c1GanttView1.Tasks.Add(task7);
            this.c1GanttView1.Tasks.Add(task8);
            this.c1GanttView1.Tasks.Add(task9);
            this.c1GanttView1.Tasks.Add(task10);
            this.c1GanttView1.Tasks.Add(task11);
            this.c1GanttView1.Tasks.Add(task12);
            this.c1GanttView1.Tasks.Add(task13);
            this.c1GanttView1.Tasks.Add(task14);
            this.c1GanttView1.Tasks.Add(task15);
            this.c1GanttView1.Tasks.Add(task16);
            this.c1GanttView1.Tasks.Add(task17);
            this.c1GanttView1.Tasks.Add(task18);
            this.c1GanttView1.Tasks.Add(task19);
            this.c1GanttView1.Tasks.Add(task20);
            this.c1GanttView1.Tasks.Add(task21);
            this.c1GanttView1.Tasks.Add(task22);
            this.c1GanttView1.Tasks.Add(task23);
            this.c1GanttView1.Tasks.Add(task24);
            this.c1GanttView1.Tasks.Add(task25);
            this.c1GanttView1.Tasks.Add(task26);
            this.c1GanttView1.Tasks.Add(task27);
            this.c1GanttView1.Tasks.Add(task28);
            this.c1GanttView1.Tasks.Add(task29);
            this.c1GanttView1.Tasks.Add(task30);
            this.c1GanttView1.Tasks.Add(task31);
            this.c1GanttView1.Tasks.Add(task32);
            this.c1GanttView1.Tasks.Add(task33);
            this.c1GanttView1.Tasks.Add(task34);
            this.c1GanttView1.Tasks.Add(task35);
            this.c1GanttView1.Tasks.Add(task36);
            this.c1GanttView1.Tasks.Add(task37);
            this.c1GanttView1.Tasks.Add(task38);
            this.c1GanttView1.Tasks.Add(task39);
            this.c1GanttView1.Tasks.Add(task40);
            this.c1GanttView1.Tasks.Add(task41);
            this.c1GanttView1.Tasks.Add(task42);
            this.c1GanttView1.Tasks.Add(task43);
            this.c1GanttView1.Tasks.Add(task44);
            this.c1GanttView1.Tasks.Add(task45);
            this.c1GanttView1.Tasks.Add(task46);
            this.c1GanttView1.Tasks.Add(task47);
            this.c1GanttView1.Tasks.Add(task48);
            this.c1GanttView1.Tasks.Add(task49);
            this.c1GanttView1.Tasks.Add(task50);
            this.c1GanttView1.Tasks.Add(task51);
            this.c1GanttView1.Tasks.Add(task52);
            this.c1GanttView1.Tasks.Add(task53);
            this.c1GanttView1.Tasks.Add(task54);
            this.c1GanttView1.Tasks.Add(task55);
            this.c1GanttView1.Tasks.Add(task56);
            this.c1GanttView1.Tasks.Add(task57);
            this.c1GanttView1.Tasks.Add(task58);
            this.c1GanttView1.Tasks.Add(task59);
            this.c1GanttView1.Tasks.Add(task60);
            this.c1GanttView1.Timescale.BottomTier.Align = C1.Win.C1GanttView.ScaleLabelAlignment.Center;
            this.c1GanttView1.Timescale.BottomTier.Format = "w";
            this.c1GanttView1.Timescale.BottomTier.Visible = true;
            this.c1GanttView1.Timescale.MiddleTier.Format = "nnnn d";
            this.c1GanttView1.Timescale.MiddleTier.Units = C1.Win.C1GanttView.TimescaleUnits.Weeks;
            this.c1GanttView1.Timescale.MiddleTier.Visible = true;
            this.c1GanttView1.ToolbarBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(237)))), ((int)(((byte)(241)))));
            // 
            // GanttViewDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 367);
            this.Controls.Add(this.c1GanttView1);
            this.Name = "GanttViewDemo";
            this.Text = "GanttViewDemo";
            this.Load += new System.EventHandler(this.GanttViewDemo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1GanttView.C1GanttView c1GanttView1;

    }
}