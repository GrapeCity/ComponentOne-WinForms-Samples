﻿namespace ControlExplorer.Gauges
{
    partial class WeatherDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange1 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark1 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks1 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks2 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels1 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel1 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark2 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark3 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel2 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel3 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle1 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector1 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse1 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer1 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer2 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment1 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeImage c1GaugeImage1 = new C1.Win.C1Gauge.C1GaugeImage();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange2 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks3 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark4 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel4 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle2 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle3 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption1 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks4 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks5 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks6 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels2 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange3 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange4 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector2 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption2 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer3 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks7 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks8 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange5 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels3 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector3 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption3 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer4 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer5 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption4 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption5 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption6 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment2 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels4 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange6 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks9 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel5 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange7 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark5 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark6 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse2 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse3 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse4 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption7 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer6 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer7 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment3 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels5 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks10 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks11 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks12 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange8 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels6 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark7 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark8 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse5 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse6 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse7 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption8 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption9 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption10 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer8 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer9 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment4 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse8 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse9 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse10 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeImage c1GaugeImage2 = new C1.Win.C1Gauge.C1GaugeImage();
            C1.Win.C1Gauge.C1GaugeImage c1GaugeImage3 = new C1.Win.C1Gauge.C1GaugeImage();
            C1.Win.C1Gauge.C1GaugeImage c1GaugeImage4 = new C1.Win.C1Gauge.C1GaugeImage();
            C1.Win.C1Gauge.C1GaugeImage c1GaugeImage5 = new C1.Win.C1Gauge.C1GaugeImage();
            C1.Win.C1Gauge.C1GaugeImage c1GaugeImage6 = new C1.Win.C1Gauge.C1GaugeImage();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer10 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer11 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks13 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels7 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark9 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark10 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption11 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer12 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer13 = new C1.Win.C1Gauge.C1GaugePointer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WeatherDashboard));
            this.c1Button1 = new C1.Win.C1Input.C1Button();
            this.c1Gauge1 = new C1.Win.C1Gauge.C1Gauge();
            this.tempGauge = new C1.Win.C1Gauge.C1LinearGauge();
            this.weatherData1 = new ControlExplorer.Chart.WeatherData();
            this.cloudGauge = new C1.Win.C1Gauge.C1LinearGauge();
            this.windGauge = new C1.Win.C1Gauge.C1RadialGauge();
            this.visMilesGauge = new C1.Win.C1Gauge.C1RadialGauge();
            this.humidityGauge = new C1.Win.C1Gauge.C1RadialGauge();
            this.pressureGauge = new C1.Win.C1Gauge.C1RadialGauge();
            this.eventsGauge = new C1.Win.C1Gauge.C1RadialGauge();
            this.dewPtGauge = new C1.Win.C1Gauge.C1RadialGauge();
            this.c1DbNavigator1 = new C1.Win.C1Input.C1DbNavigator();
            this.c1TrueDBGrid1 = new C1.Win.C1TrueDBGrid.C1TrueDBGrid();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.c1Button1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.weatherData1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1DbNavigator1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBGrid1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // c1Button1
            // 
            this.c1Button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.c1Button1.Location = new System.Drawing.Point(903, 3);
            this.c1Button1.Name = "c1Button1";
            this.c1Button1.Size = new System.Drawing.Size(75, 23);
            this.c1Button1.TabIndex = 5;
            this.c1Button1.Text = "Print";
            this.c1Button1.UseVisualStyleBackColor = true;
            this.c1Button1.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Black;
            this.c1Button1.Click += new System.EventHandler(this.c1Button1_Click);
            // 
            // c1Gauge1
            // 
            this.c1Gauge1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge1, 2);
            this.c1Gauge1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge1.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.tempGauge,
            this.cloudGauge,
            this.windGauge,
            this.visMilesGauge,
            this.humidityGauge,
            this.pressureGauge,
            this.eventsGauge,
            this.dewPtGauge});
            this.c1Gauge1.Location = new System.Drawing.Point(3, 38);
            this.c1Gauge1.MaximumSize = new System.Drawing.Size(836, 0);
            this.c1Gauge1.Name = "c1Gauge1";
            this.c1Gauge1.Size = new System.Drawing.Size(836, 394);
            this.c1Gauge1.TabIndex = 2;
            this.c1Gauge1.Viewport.AspectRatio = 2.5D;
            this.c1Gauge1.Viewport.MarginY = 20;
            this.c1Gauge1.ViewTag = ((long)(653736575547060513));
            // 
            // tempGauge
            // 
            this.tempGauge.AxisLength = 0.42D;
            this.tempGauge.AxisStart = 0.42D;
            this.tempGauge.BaseFactor = 0.7D;
            this.tempGauge.BaseOrigin = -0.28D;
            this.tempGauge.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.weatherData1, "meanTempF", true));
            this.tempGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_0", this.weatherData1, "minTempF", true));
            this.tempGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_1", this.weatherData1, "maxTempF", true));
            c1GaugeRange1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRange1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeRange1.Filling.Color2 = System.Drawing.Color.Red;
            c1GaugeRange1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeRange1.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRange1.Location = 50D;
            c1GaugeRange1.ToPointerIndex = 100;
            c1GaugeRange1.ViewTag = ((long)(739294773683120203));
            c1GaugeSingleMark1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark1.CustomShape.EndAngle = 60D;
            c1GaugeSingleMark1.CustomShape.EndRadius = 10D;
            c1GaugeSingleMark1.CustomShape.EndWidth = 3D;
            c1GaugeSingleMark1.CustomShape.StartAngle = 60D;
            c1GaugeSingleMark1.CustomShape.StartRadius = 10D;
            c1GaugeSingleMark1.CustomShape.StartWidth = 3D;
            c1GaugeSingleMark1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSingleMark1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeSingleMark1.Filling.Color2 = System.Drawing.Color.LightCoral;
            c1GaugeSingleMark1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSingleMark1.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSingleMark1.Length = 12D;
            c1GaugeSingleMark1.Location = 50D;
            c1GaugeSingleMark1.PointerIndex = 100;
            c1GaugeSingleMark1.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Custom;
            c1GaugeSingleMark1.ViewTag = ((long)(637124138919996870));
            c1GaugeMarks1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks1.CustomShape.EndRadius = 15D;
            c1GaugeMarks1.CustomShape.EndWidth = 12D;
            c1GaugeMarks1.CustomShape.StartRadius = -15D;
            c1GaugeMarks1.CustomShape.StartWidth = 12D;
            c1GaugeMarks1.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeMarks1.Interval = 20D;
            c1GaugeMarks1.Length = 0.5D;
            c1GaugeMarks1.Location = 50D;
            c1GaugeMarks1.OrthogonalOffset = -2D;
            c1GaugeMarks1.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Custom;
            c1GaugeMarks1.ShapeAngle = 90D;
            c1GaugeMarks1.ViewTag = ((long)(737605923822856267));
            c1GaugeMarks2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks2.CustomShape.EndRadius = 7.5D;
            c1GaugeMarks2.CustomShape.EndWidth = 6D;
            c1GaugeMarks2.CustomShape.StartRadius = -7.5D;
            c1GaugeMarks2.CustomShape.StartWidth = 6D;
            c1GaugeMarks2.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeMarks2.Interval = 10D;
            c1GaugeMarks2.Length = 0.5D;
            c1GaugeMarks2.Location = 50D;
            c1GaugeMarks2.OrthogonalOffset = -2D;
            c1GaugeMarks2.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Custom;
            c1GaugeMarks2.ShapeAngle = 90D;
            c1GaugeMarks2.ViewTag = ((long)(738168873776277579));
            c1GaugeLabels1.Color = System.Drawing.Color.Black;
            c1GaugeLabels1.FontSize = 9D;
            c1GaugeLabels1.Interval = 40D;
            c1GaugeLabels1.Location = 30D;
            c1GaugeLabels1.OrthogonalOffset = -2D;
            c1GaugeLabels1.To = 100D;
            c1GaugeLabels1.ViewTag = ((long)(738731823729698891));
            c1GaugeSingleLabel1.Color = System.Drawing.Color.Black;
            c1GaugeSingleLabel1.FontSize = 16D;
            c1GaugeSingleLabel1.Location = 28D;
            c1GaugeSingleLabel1.Text = "°F";
            c1GaugeSingleLabel1.Value = 120D;
            c1GaugeSingleLabel1.ViewTag = ((long)(641350885385835916));
            c1GaugeSingleMark2.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugeSingleMark2.Filling.Color = System.Drawing.Color.Blue;
            c1GaugeSingleMark2.FlipShape = true;
            c1GaugeSingleMark2.Length = 12D;
            c1GaugeSingleMark2.Location = 62D;
            c1GaugeSingleMark2.Name = "MinMark";
            c1GaugeSingleMark2.PointerIndex = 0;
            c1GaugeSingleMark2.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Triangle;
            c1GaugeSingleMark2.ViewTag = ((long)(641632364787533100));
            c1GaugeSingleMark2.Width = 12D;
            c1GaugeSingleMark3.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugeSingleMark3.Filling.Color = System.Drawing.Color.Red;
            c1GaugeSingleMark3.FlipShape = true;
            c1GaugeSingleMark3.Length = 12D;
            c1GaugeSingleMark3.Location = 62D;
            c1GaugeSingleMark3.Name = "MaxMark";
            c1GaugeSingleMark3.PointerIndex = 1;
            c1GaugeSingleMark3.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Triangle;
            c1GaugeSingleMark3.ViewTag = ((long)(641913839780623861));
            c1GaugeSingleMark3.Width = 12D;
            c1GaugeSingleLabel2.Color = System.Drawing.Color.Black;
            c1GaugeSingleLabel2.FontSize = 10D;
            c1GaugeSingleLabel2.Location = 80D;
            c1GaugeSingleLabel2.PointerIndex = 1;
            c1GaugeSingleLabel2.Text = "High";
            c1GaugeSingleLabel2.ViewTag = ((long)(642758267265740207));
            c1GaugeSingleLabel3.Color = System.Drawing.Color.Black;
            c1GaugeSingleLabel3.FontSize = 10D;
            c1GaugeSingleLabel3.Location = 80D;
            c1GaugeSingleLabel3.PointerIndex = 0;
            c1GaugeSingleLabel3.Text = "Low";
            c1GaugeSingleLabel3.ViewTag = ((long)(643039742279423100));
            this.tempGauge.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange1,
            c1GaugeSingleMark1,
            c1GaugeMarks1,
            c1GaugeMarks2,
            c1GaugeLabels1,
            c1GaugeSingleLabel1,
            c1GaugeSingleMark2,
            c1GaugeSingleMark3,
            c1GaugeSingleLabel2,
            c1GaugeSingleLabel3});
            c1GaugeRectangle1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle1.CenterPointX = 0.85D;
            c1GaugeRectangle1.CenterPointY = 0.55D;
            c1GaugeRectangle1.CornerRadius = 3D;
            c1GaugeRectangle1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle1.Filling.Color = System.Drawing.Color.White;
            c1GaugeRectangle1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeRectangle1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle1.Height = -1.5D;
            c1GaugeRectangle1.Width = -1.4D;
            c1GaugeSector1.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugeSector1.CenterPointY = 1.05D;
            c1GaugeSector1.CornerRadius = 10D;
            c1GaugeSector1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector1.Filling.Color = System.Drawing.Color.White;
            c1GaugeSector1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeSector1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeSector1.Gradient.ScaleX = 0.2D;
            c1GaugeSector1.Gradient.TranslateX = 0.4D;
            c1GaugeSector1.InnerRadius = -15D;
            c1GaugeSector1.OuterRadius = 140D;
            c1GaugeSector1.SweepAngle = 0D;
            c1GaugeEllipse1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse1.CenterPointY = 1.05D;
            c1GaugeEllipse1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse1.Filling.Color = System.Drawing.Color.Red;
            c1GaugeEllipse1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeEllipse1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeEllipse1.Height = 20D;
            c1GaugeEllipse1.Width = 20D;
            this.tempGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle1,
            c1GaugeSector1,
            c1GaugeEllipse1});
            this.tempGauge.IsReversed = true;
            this.tempGauge.Maximum = 120D;
            this.tempGauge.Minimum = -40D;
            c1GaugePointer1.Value = 20D;
            c1GaugePointer1.ViewTag = ((long)(642195315057168439));
            c1GaugePointer1.Visible = false;
            c1GaugePointer2.Value = 40D;
            c1GaugePointer2.ViewTag = ((long)(642476790039807133));
            c1GaugePointer2.Visible = false;
            this.tempGauge.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer1,
            c1GaugePointer2});
            this.tempGauge.Name = "tempGauge";
            this.tempGauge.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.tempGauge.Pointer.SweepTime = 2D;
            this.tempGauge.Pointer.Value = 10D;
            this.tempGauge.Pointer.Visible = false;
            this.tempGauge.Viewport.AspectRatio = 0.5D;
            this.tempGauge.ViewTag = ((long)(737042973869434955));
            // 
            // weatherData1
            // 
            this.weatherData1.DataMember = "WeatherData";
            this.weatherData1.Position = 0;
            this.weatherData1.CurrentChanged += new System.EventHandler(this.weatherData1_CurrentChanged);
            // 
            // cloudGauge
            // 
            this.cloudGauge.AxisLength = 0.55D;
            this.cloudGauge.AxisStart = 0.4D;
            this.cloudGauge.BaseFactor = 0.7D;
            this.cloudGauge.BaseOrigin = 0.57D;
            c1GaugeSegment1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment1.CenterPointX = 0.7D;
            c1GaugeSegment1.CenterPointY = 0.1D;
            c1GaugeSegment1.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("Face", C1.Win.C1Gauge.C1GaugeClipOperation.Replace, 0.98D)});
            c1GaugeSegment1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment1.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment1.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment1.Filling.Opacity = 0.2D;
            c1GaugeSegment1.Filling.Opacity2 = 0.4D;
            c1GaugeSegment1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment1.InnerRadius = 130D;
            c1GaugeSegment1.StartAngle = -140D;
            c1GaugeSegment1.SweepAngle = 198D;
            c1GaugeImage1.CenterPointX = 0.51D;
            c1GaugeImage1.CenterPointY = 0.02D;
            c1GaugeImage1.Image = ((System.Drawing.Image)(resources.GetObject("c1GaugeImage1.Image")));
            c1GaugeImage1.Width = -1.1D;
            this.cloudGauge.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment1,
            c1GaugeImage1});
            this.cloudGauge.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.weatherData1, "cloudCover", true));
            c1GaugeRange2.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeRange2.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(97)))), ((int)(((byte)(163)))));
            c1GaugeRange2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRange2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(97)))), ((int)(((byte)(163)))));
            c1GaugeRange2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(169)))), ((int)(((byte)(223)))));
            c1GaugeRange2.Filling.Opacity = 0.8D;
            c1GaugeRange2.Filling.Opacity2 = 0.8D;
            c1GaugeRange2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeRange2.Location = 25D;
            c1GaugeRange2.ToPointerIndex = 100;
            c1GaugeRange2.ViewTag = ((long)(654568073860413945));
            c1GaugeRange2.Width = 25D;
            c1GaugeMarks3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeMarks3.Filling.Opacity = 0.5D;
            c1GaugeMarks3.Interval = 1D;
            c1GaugeMarks3.Length = 25D;
            c1GaugeMarks3.Location = 25D;
            c1GaugeMarks3.ViewTag = ((long)(651753275780104499));
            c1GaugeMarks3.Width = 1D;
            c1GaugeSingleMark4.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(160)))), ((int)(((byte)(204)))));
            c1GaugeSingleMark4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSingleMark4.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            c1GaugeSingleMark4.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(226)))), ((int)(((byte)(239)))));
            c1GaugeSingleMark4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSingleMark4.Length = 32D;
            c1GaugeSingleMark4.Location = 37D;
            c1GaugeSingleMark4.OrthogonalOffset = 12D;
            c1GaugeSingleMark4.PointerIndex = 100;
            c1GaugeSingleMark4.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeSingleMark4.Shadow.Opacity = 0.15D;
            c1GaugeSingleMark4.Shadow.Visible = true;
            c1GaugeSingleMark4.ViewTag = ((long)(661043586079997651));
            c1GaugeSingleMark4.Width = 18D;
            c1GaugeSingleLabel4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeSingleLabel4.FontSize = 12D;
            c1GaugeSingleLabel4.Format = "n0";
            c1GaugeSingleLabel4.Location = 37D;
            c1GaugeSingleLabel4.OrthogonalOffset = 12D;
            c1GaugeSingleLabel4.PointerIndex = 100;
            c1GaugeSingleLabel4.ViewTag = ((long)(654286592041409128));
            this.cloudGauge.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange2,
            c1GaugeMarks3,
            c1GaugeSingleMark4,
            c1GaugeSingleLabel4});
            c1GaugeRectangle2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle2.Border.Thickness = 1D;
            c1GaugeRectangle2.CenterPointX = 0.25D;
            c1GaugeRectangle2.CornerRadius = 3D;
            c1GaugeRectangle2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle2.Filling.Color = System.Drawing.Color.White;
            c1GaugeRectangle2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeRectangle2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle2.Height = -1.15D;
            c1GaugeRectangle2.Width = -1.6D;
            c1GaugeRectangle3.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugeRectangle3.Border.Thickness = 1D;
            c1GaugeRectangle3.CornerRadius = 2D;
            c1GaugeRectangle3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeRectangle3.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeRectangle3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle3.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRectangle3.Gradient.Focus = 0.6D;
            c1GaugeRectangle3.Height = -1.1D;
            c1GaugeRectangle3.Name = "Face";
            c1GaugeRectangle3.Width = -0.9D;
            c1GaugeCaption1.CenterPointX = 0.75D;
            c1GaugeCaption1.DirectionVertical = true;
            c1GaugeCaption1.FontSize = 20D;
            c1GaugeCaption1.RotateAngle = 180D;
            c1GaugeCaption1.Text = "Cloud Cover";
            this.cloudGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle2,
            c1GaugeRectangle3,
            c1GaugeCaption1});
            this.cloudGauge.IsReversed = true;
            this.cloudGauge.Maximum = 10D;
            this.cloudGauge.Name = "cloudGauge";
            this.cloudGauge.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.cloudGauge.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.cloudGauge.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.cloudGauge.Pointer.FlipShape = true;
            this.cloudGauge.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            this.cloudGauge.Pointer.Length = 58D;
            this.cloudGauge.Pointer.Offset = 8D;
            this.cloudGauge.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.cloudGauge.Pointer.Shadow.Opacity = 0.15D;
            this.cloudGauge.Pointer.Shadow.Visible = true;
            this.cloudGauge.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Rectangle;
            this.cloudGauge.Pointer.SweepTime = 1D;
            this.cloudGauge.Pointer.Value = 3D;
            this.cloudGauge.Pointer.Visible = false;
            this.cloudGauge.Pointer.Width = 8D;
            this.cloudGauge.Viewport.AspectRatio = 0.3D;
            this.cloudGauge.ViewTag = ((long)(650627358688755457));
            // 
            // windGauge
            // 
            this.windGauge.Cap.Visible = false;
            this.windGauge.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.weatherData1, "meanWindSpeed", true));
            this.windGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_0", this.weatherData1, "maxGustSpeed", true));
            c1GaugeMarks4.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks4.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks4.Interval = 10D;
            c1GaugeMarks4.Length = 8D;
            c1GaugeMarks4.ViewTag = ((long)(639371875277416646));
            c1GaugeMarks4.Width = 0.15D;
            c1GaugeMarks5.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks5.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks5.Interval = 5D;
            c1GaugeMarks5.Length = 6D;
            c1GaugeMarks5.ViewTag = ((long)(641060729845969881));
            c1GaugeMarks5.Width = 0.15D;
            c1GaugeMarks6.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks6.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks6.Interval = 1D;
            c1GaugeMarks6.Length = 3D;
            c1GaugeMarks6.ViewTag = ((long)(639653350254137302));
            c1GaugeMarks6.Width = 0.15D;
            c1GaugeLabels2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugeLabels2.Font = new System.Drawing.Font("Tahoma", 9.75F);
            c1GaugeLabels2.FontSize = 4D;
            c1GaugeLabels2.Interval = 10D;
            c1GaugeLabels2.IsRotated = true;
            c1GaugeLabels2.Location = 95D;
            c1GaugeLabels2.ViewTag = ((long)(639934825230857959));
            c1GaugeRange3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange3.Filling.Color = System.Drawing.Color.LightCoral;
            c1GaugeRange3.Location = 85D;
            c1GaugeRange3.ToPointerIndex = 0;
            c1GaugeRange3.ViewTag = ((long)(1069194397655543054));
            c1GaugeRange3.Width = 4D;
            c1GaugeRange4.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange4.Filling.Color = System.Drawing.Color.ForestGreen;
            c1GaugeRange4.Location = 83D;
            c1GaugeRange4.ToPointerIndex = 100;
            c1GaugeRange4.ViewTag = ((long)(1068631444341704201));
            c1GaugeRange4.Width = 4D;
            this.windGauge.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks4,
            c1GaugeMarks5,
            c1GaugeMarks6,
            c1GaugeLabels2,
            c1GaugeRange3,
            c1GaugeRange4});
            c1GaugeSector2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector2.Border.Thickness = 0.5D;
            c1GaugeSector2.CenterRadius = 3D;
            c1GaugeSector2.CornerRadius = 2D;
            c1GaugeSector2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector2.Filling.Color = System.Drawing.Color.White;
            c1GaugeSector2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeSector2.Filling.SwapColors = true;
            c1GaugeSector2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeSector2.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSector2.Gradient.ScaleY = 0.5D;
            c1GaugeSector2.InnerOffset = -150D;
            c1GaugeSector2.InnerRadius = 200D;
            c1GaugeSector2.Name = "sc";
            c1GaugeSector2.StartAngle = -22D;
            c1GaugeSector2.SweepAngle = 35D;
            c1GaugeCaption2.CenterPointX = 0.48D;
            c1GaugeCaption2.CenterPointY = 0.14D;
            c1GaugeCaption2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeCaption2.FontSize = 5D;
            c1GaugeCaption2.Text = "Windspeed";
            this.windGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSector2,
            c1GaugeCaption2});
            this.windGauge.Maximum = 30D;
            c1GaugePointer3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugePointer3.CustomShape.EndWidth = 0D;
            c1GaugePointer3.CustomShape.StartWidth = 3D;
            c1GaugePointer3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugePointer3.Filling.Color = System.Drawing.Color.Coral;
            c1GaugePointer3.Filling.Color2 = System.Drawing.Color.IndianRed;
            c1GaugePointer3.Length = 25D;
            c1GaugePointer3.Offset = 70D;
            c1GaugePointer3.Shadow.Visible = true;
            c1GaugePointer3.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer3.SweepTime = 2D;
            c1GaugePointer3.Value = 20D;
            c1GaugePointer3.ViewTag = ((long)(1068912921131614480));
            this.windGauge.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer3});
            this.windGauge.Name = "windGauge";
            this.windGauge.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.windGauge.Pointer.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("sc", C1.Win.C1Gauge.C1GaugeClipOperation.Intersect, 1.01D)});
            this.windGauge.Pointer.CustomShape.EndWidth = 0D;
            this.windGauge.Pointer.CustomShape.StartWidth = 3D;
            this.windGauge.Pointer.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.windGauge.Pointer.Filling.Color = System.Drawing.Color.LimeGreen;
            this.windGauge.Pointer.Filling.Color2 = System.Drawing.Color.ForestGreen;
            this.windGauge.Pointer.Length = 25D;
            this.windGauge.Pointer.Offset = 68D;
            this.windGauge.Pointer.Shadow.Visible = true;
            this.windGauge.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.windGauge.Pointer.SweepTime = 2D;
            this.windGauge.Pointer.Value = 7D;
            this.windGauge.PointerOriginX = 0.26D;
            this.windGauge.PointerOriginY = 1.15D;
            this.windGauge.Radius = 1D;
            this.windGauge.StartAngle = -20D;
            this.windGauge.SweepAngle = 28D;
            this.windGauge.Viewport.AspectPinY = 0.5D;
            this.windGauge.Viewport.AspectRatio = 2.1D;
            this.windGauge.ViewTag = ((long)(640497775184369276));
            // 
            // visMilesGauge
            // 
            this.visMilesGauge.Cap.Visible = false;
            this.visMilesGauge.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.weatherData1, "meanVisMiles", true));
            this.visMilesGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_0", this.weatherData1, "minVisMiles", true));
            this.visMilesGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_1", this.weatherData1, "maxVisMiles", true));
            c1GaugeMarks7.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks7.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks7.Interval = 5D;
            c1GaugeMarks7.Length = 8D;
            c1GaugeMarks7.ViewTag = ((long)(639371875277416646));
            c1GaugeMarks7.Width = 0.15D;
            c1GaugeMarks8.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks8.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks8.Interval = 1D;
            c1GaugeMarks8.Length = 6D;
            c1GaugeMarks8.ViewTag = ((long)(641060729845969881));
            c1GaugeMarks8.Width = 0.15D;
            c1GaugeRange5.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeRange5.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeRange5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeRange5.Filling.Opacity = 0.5D;
            c1GaugeRange5.FromPointerIndex = 0;
            c1GaugeRange5.Location = 85D;
            c1GaugeRange5.ToPointerIndex = 1;
            c1GaugeRange5.ViewTag = ((long)(1087771775570253944));
            c1GaugeRange5.Width = 6D;
            c1GaugeLabels3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugeLabels3.Font = new System.Drawing.Font("Tahoma", 9.75F);
            c1GaugeLabels3.FontSize = 4D;
            c1GaugeLabels3.Interval = 2D;
            c1GaugeLabels3.IsRotated = true;
            c1GaugeLabels3.Location = 95D;
            c1GaugeLabels3.ViewTag = ((long)(639934825230857959));
            this.visMilesGauge.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks7,
            c1GaugeMarks8,
            c1GaugeRange5,
            c1GaugeLabels3});
            c1GaugeSector3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector3.Border.Thickness = 0.5D;
            c1GaugeSector3.CenterRadius = 3D;
            c1GaugeSector3.CornerRadius = 2D;
            c1GaugeSector3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector3.Filling.Color = System.Drawing.Color.White;
            c1GaugeSector3.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeSector3.Filling.SwapColors = true;
            c1GaugeSector3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeSector3.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSector3.Gradient.ScaleY = 0.5D;
            c1GaugeSector3.InnerOffset = -150D;
            c1GaugeSector3.InnerRadius = 200D;
            c1GaugeSector3.Name = "sc";
            c1GaugeSector3.StartAngle = -15D;
            c1GaugeSector3.SweepAngle = 35D;
            c1GaugeCaption3.CenterPointX = 0.53D;
            c1GaugeCaption3.CenterPointY = 0.14D;
            c1GaugeCaption3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeCaption3.FontSize = 5D;
            c1GaugeCaption3.Text = "Vis (Miles)";
            this.visMilesGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSector3,
            c1GaugeCaption3});
            this.visMilesGauge.Maximum = 10D;
            c1GaugePointer4.SweepTime = 1D;
            c1GaugePointer4.Value = 4D;
            c1GaugePointer4.ViewTag = ((long)(1087208825430567438));
            c1GaugePointer4.Visible = false;
            c1GaugePointer5.SweepTime = 1D;
            c1GaugePointer5.Value = 8D;
            c1GaugePointer5.ViewTag = ((long)(1087490300417886162));
            c1GaugePointer5.Visible = false;
            this.visMilesGauge.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer4,
            c1GaugePointer5});
            this.visMilesGauge.Name = "visMilesGauge";
            this.visMilesGauge.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.visMilesGauge.Pointer.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("sc", C1.Win.C1Gauge.C1GaugeClipOperation.Intersect, 1.01D)});
            this.visMilesGauge.Pointer.CustomShape.EndAngle = 75D;
            this.visMilesGauge.Pointer.CustomShape.EndRadius = 0.166666666667D;
            this.visMilesGauge.Pointer.CustomShape.EndSwellAngle = 45D;
            this.visMilesGauge.Pointer.CustomShape.EndSwellWidth = 1.166666666667D;
            this.visMilesGauge.Pointer.CustomShape.EndWidth = 1D;
            this.visMilesGauge.Pointer.CustomShape.StartWidth = 1D;
            this.visMilesGauge.Pointer.Filling.Color = System.Drawing.Color.MediumBlue;
            this.visMilesGauge.Pointer.Length = 20D;
            this.visMilesGauge.Pointer.Offset = 70D;
            this.visMilesGauge.Pointer.Shadow.Visible = true;
            this.visMilesGauge.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.visMilesGauge.Pointer.SweepTime = 1D;
            this.visMilesGauge.Pointer.Value = 7D;
            this.visMilesGauge.PointerOriginX = 0.74D;
            this.visMilesGauge.PointerOriginY = 1.15D;
            this.visMilesGauge.Radius = 1D;
            this.visMilesGauge.StartAngle = -10D;
            this.visMilesGauge.SweepAngle = 28D;
            this.visMilesGauge.Viewport.AspectPinY = 0.5D;
            this.visMilesGauge.Viewport.AspectRatio = 2.1D;
            this.visMilesGauge.ViewTag = ((long)(640497775184369276));
            // 
            // humidityGauge
            // 
            this.humidityGauge.Cap.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.humidityGauge.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.humidityGauge.Cap.Filling.Color = System.Drawing.Color.White;
            this.humidityGauge.Cap.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.humidityGauge.Cap.Radius = 12D;
            this.humidityGauge.Cap.Shadow.Visible = true;
            c1GaugeCaption4.CenterPointX = 0.06D;
            c1GaugeCaption4.DirectionVertical = true;
            c1GaugeCaption4.FontSize = 10D;
            c1GaugeCaption4.LineAlignment = System.Drawing.StringAlignment.Far;
            c1GaugeCaption4.RotateAngle = 180D;
            c1GaugeCaption4.Text = "DESERT";
            c1GaugeCaption5.CenterPointY = 0.06D;
            c1GaugeCaption5.FontSize = 10D;
            c1GaugeCaption5.Text = "MODERATE";
            c1GaugeCaption6.CenterPointX = 0.94D;
            c1GaugeCaption6.DirectionVertical = true;
            c1GaugeCaption6.FontSize = 10D;
            c1GaugeCaption6.Text = "TROPICAL";
            c1GaugeSegment2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment2.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment2.Filling.Color2 = System.Drawing.Color.CornflowerBlue;
            c1GaugeSegment2.Filling.Opacity = 0.6D;
            c1GaugeSegment2.Filling.Opacity2 = 0.1D;
            c1GaugeSegment2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment2.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSegment2.InnerRadius = 130D;
            c1GaugeSegment2.SweepAngle = 190D;
            this.humidityGauge.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption4,
            c1GaugeCaption5,
            c1GaugeCaption6,
            c1GaugeSegment2});
            this.humidityGauge.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.weatherData1, "meanHumidity", true));
            this.humidityGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_0", this.weatherData1, "minHumidity", true));
            this.humidityGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_1", this.weatherData1, "maxHumidity", true));
            c1GaugeLabels4.AllowFlip = true;
            c1GaugeLabels4.FontSize = 10D;
            c1GaugeLabels4.Interval = 10D;
            c1GaugeLabels4.Location = 60D;
            c1GaugeLabels4.ViewTag = ((long)(728035773812438077));
            c1GaugeRange6.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange6.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange6.Location = 99D;
            c1GaugeRange6.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Firebrick, 0.8D, ((long)(729161673719280701))),
            new C1.Win.C1Gauge.C1GaugeValueColor(40D, -1, System.Drawing.Color.Yellow, 0.8D, ((long)(729724623672702013))),
            new C1.Win.C1Gauge.C1GaugeValueColor(90D, -1, System.Drawing.Color.LimeGreen, 0.8D, ((long)(730287573626123325)))});
            c1GaugeRange6.ViewTag = ((long)(728598723765859389));
            c1GaugeRange6.Width = 20D;
            c1GaugeMarks9.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks9.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks9.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks9.Interval = 5D;
            c1GaugeMarks9.Length = 12D;
            c1GaugeMarks9.Location = 80D;
            c1GaugeMarks9.ViewTag = ((long)(730850523579544637));
            c1GaugeMarks9.Width = 1D;
            c1GaugeSingleLabel5.Angle = 150D;
            c1GaugeSingleLabel5.FontSize = 16D;
            c1GaugeSingleLabel5.Format = "##%";
            c1GaugeSingleLabel5.Location = 38D;
            c1GaugeSingleLabel5.PointerIndex = 100;
            c1GaugeSingleLabel5.ValueFactor = 0.01D;
            c1GaugeSingleLabel5.ViewTag = ((long)(731976423486387261));
            c1GaugeRange7.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange7.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRange7.Filling.Color = System.Drawing.Color.Blue;
            c1GaugeRange7.Filling.Color2 = System.Drawing.Color.Red;
            c1GaugeRange7.FromPointerIndex = 0;
            c1GaugeRange7.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeRange7.Location = 80D;
            c1GaugeRange7.Name = "MinMaxRange";
            c1GaugeRange7.ToPointerIndex = 1;
            c1GaugeRange7.ViewTag = ((long)(640787907661184623));
            c1GaugeRange7.Width = 5D;
            c1GaugeSingleMark5.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeSingleMark5.Filling.Color = System.Drawing.Color.Blue;
            c1GaugeSingleMark5.FlipShape = true;
            c1GaugeSingleMark5.Length = 18D;
            c1GaugeSingleMark5.Name = "MinMark";
            c1GaugeSingleMark5.PointerIndex = 0;
            c1GaugeSingleMark5.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Triangle;
            c1GaugeSingleMark5.ViewTag = ((long)(640224954841429726));
            c1GaugeSingleMark5.Width = 12D;
            c1GaugeSingleMark6.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeSingleMark6.Filling.Color = System.Drawing.Color.Red;
            c1GaugeSingleMark6.FlipShape = true;
            c1GaugeSingleMark6.Length = 18D;
            c1GaugeSingleMark6.Name = "MaxMark";
            c1GaugeSingleMark6.PointerIndex = 1;
            c1GaugeSingleMark6.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Triangle;
            c1GaugeSingleMark6.ViewTag = ((long)(640506430302523487));
            c1GaugeSingleMark6.Width = 12D;
            this.humidityGauge.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeLabels4,
            c1GaugeRange6,
            c1GaugeMarks9,
            c1GaugeSingleLabel5,
            c1GaugeRange7,
            c1GaugeSingleMark5,
            c1GaugeSingleMark6});
            c1GaugeEllipse2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse2.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeEllipse2.Filling.SwapColors = true;
            c1GaugeEllipse2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse2.Height = -1.08D;
            c1GaugeEllipse2.Width = -1.08D;
            c1GaugeEllipse3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse3.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse3.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse3.Filling.SwapColors = true;
            c1GaugeEllipse3.Height = -1.02D;
            c1GaugeEllipse3.Width = -1.02D;
            c1GaugeEllipse4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse4.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse4.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeEllipse4.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeEllipse4.Gradient.Focus = 0.08D;
            c1GaugeCaption7.CenterPointY = 0.35D;
            c1GaugeCaption7.Color = System.Drawing.Color.Black;
            c1GaugeCaption7.FontSize = 10D;
            c1GaugeCaption7.Text = "HUMIDITY";
            this.humidityGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse2,
            c1GaugeEllipse3,
            c1GaugeEllipse4,
            c1GaugeCaption7});
            c1GaugePointer6.Value = 35D;
            c1GaugePointer6.ViewTag = ((long)(639662004562590328));
            c1GaugePointer6.Visible = false;
            c1GaugePointer7.Value = 60D;
            c1GaugePointer7.ViewTag = ((long)(639943479546477030));
            c1GaugePointer7.Visible = false;
            this.humidityGauge.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer6,
            c1GaugePointer7});
            this.humidityGauge.Name = "humidityGauge";
            this.humidityGauge.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.humidityGauge.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.humidityGauge.Pointer.CustomShape.EndWidth = 1D;
            this.humidityGauge.Pointer.CustomShape.StartWidth = 10D;
            this.humidityGauge.Pointer.Filling.Color = System.Drawing.Color.Black;
            this.humidityGauge.Pointer.Filling.HatchStyle = C1.Win.C1Gauge.C1GaugeHatchStyle.Wave;
            this.humidityGauge.Pointer.Length = 100D;
            this.humidityGauge.Pointer.Offset = -30D;
            this.humidityGauge.Pointer.Shadow.Visible = true;
            this.humidityGauge.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.humidityGauge.Pointer.SweepTime = 2D;
            this.humidityGauge.Pointer.Value = 45D;
            this.humidityGauge.Radius = 0.45D;
            this.humidityGauge.StartAngle = -125D;
            this.humidityGauge.SweepAngle = 250D;
            this.humidityGauge.ViewTag = ((long)(727472823859016765));
            // 
            // pressureGauge
            // 
            this.pressureGauge.Cap.Border.Color = System.Drawing.Color.Black;
            this.pressureGauge.Cap.Border.Thickness = 2D;
            this.pressureGauge.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.pressureGauge.Cap.Filling.Color = System.Drawing.Color.Gold;
            this.pressureGauge.Cap.Filling.Color2 = System.Drawing.Color.Black;
            this.pressureGauge.Cap.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialOuter;
            this.pressureGauge.Cap.Shadow.Visible = true;
            c1GaugeSegment3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment3.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment3.Filling.Color2 = System.Drawing.Color.CornflowerBlue;
            c1GaugeSegment3.Filling.Opacity = 0.6D;
            c1GaugeSegment3.Filling.Opacity2 = 0.1D;
            c1GaugeSegment3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment3.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSegment3.InnerRadius = 130D;
            c1GaugeSegment3.SweepAngle = 190D;
            this.pressureGauge.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment3});
            this.pressureGauge.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.weatherData1, "meanSeaPressure", true));
            this.pressureGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_0", this.weatherData1, "minSeaPressure", true));
            this.pressureGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_1", this.weatherData1, "maxSeaPressure", true));
            c1GaugeLabels5.AllowFlip = true;
            c1GaugeLabels5.FontSize = 12D;
            c1GaugeLabels5.Interval = 100D;
            c1GaugeLabels5.Location = 90D;
            c1GaugeLabels5.ViewTag = ((long)(728035773812438077));
            c1GaugeMarks10.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks10.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks10.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks10.Interval = 50D;
            c1GaugeMarks10.Length = 20D;
            c1GaugeMarks10.Location = 60D;
            c1GaugeMarks10.ViewTag = ((long)(730850523579544637));
            c1GaugeMarks10.Width = 1D;
            c1GaugeMarks11.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks11.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks11.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks11.Interval = 10D;
            c1GaugeMarks11.Length = 8D;
            c1GaugeMarks11.Location = 60D;
            c1GaugeMarks11.ViewTag = ((long)(649514403884524153));
            c1GaugeMarks11.Width = 1D;
            c1GaugeMarks12.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks12.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks12.Filling.Color = System.Drawing.Color.Red;
            c1GaugeMarks12.Interval = 25D;
            c1GaugeMarks12.Length = 10D;
            c1GaugeMarks12.Location = 55D;
            c1GaugeMarks12.ViewTag = ((long)(649795879440154520));
            c1GaugeMarks12.Width = 1D;
            c1GaugeRange8.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange8.Filling.Color = System.Drawing.Color.Red;
            c1GaugeRange8.Location = 55D;
            c1GaugeRange8.ViewTag = ((long)(650077355452711816));
            c1GaugeRange8.Width = 1D;
            c1GaugeLabels6.Color = System.Drawing.Color.Red;
            c1GaugeLabels6.FontSize = 9D;
            c1GaugeLabels6.Format = "n0";
            c1GaugeLabels6.Interval = 133.333333D;
            c1GaugeLabels6.Location = 35D;
            c1GaugeLabels6.ValueFactor = 15D;
            c1GaugeLabels6.ViewTag = ((long)(650358830775900693));
            c1GaugeSingleMark7.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeSingleMark7.Filling.Color = System.Drawing.Color.Blue;
            c1GaugeSingleMark7.FlipShape = true;
            c1GaugeSingleMark7.Length = 18D;
            c1GaugeSingleMark7.Location = 100D;
            c1GaugeSingleMark7.Name = "MinMark";
            c1GaugeSingleMark7.PointerIndex = 0;
            c1GaugeSingleMark7.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark7.ViewTag = ((long)(640224954841429726));
            c1GaugeSingleMark8.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeSingleMark8.Filling.Color = System.Drawing.Color.Red;
            c1GaugeSingleMark8.FlipShape = true;
            c1GaugeSingleMark8.Length = 18D;
            c1GaugeSingleMark8.Location = 100D;
            c1GaugeSingleMark8.Name = "MaxMark";
            c1GaugeSingleMark8.PointerIndex = 1;
            c1GaugeSingleMark8.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark8.ViewTag = ((long)(640506430302523487));
            this.pressureGauge.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeLabels5,
            c1GaugeMarks10,
            c1GaugeMarks11,
            c1GaugeMarks12,
            c1GaugeRange8,
            c1GaugeLabels6,
            c1GaugeSingleMark7,
            c1GaugeSingleMark8});
            c1GaugeEllipse5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse5.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse5.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeEllipse5.Filling.SwapColors = true;
            c1GaugeEllipse5.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse5.Height = -1.08D;
            c1GaugeEllipse5.Width = -1.08D;
            c1GaugeEllipse6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse6.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse6.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse6.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse6.Filling.SwapColors = true;
            c1GaugeEllipse6.Height = -1.02D;
            c1GaugeEllipse6.Width = -1.02D;
            c1GaugeEllipse7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse7.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse7.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse7.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse7.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeEllipse7.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeEllipse7.Gradient.Focus = 0.08D;
            c1GaugeCaption8.CenterPointY = 0.75D;
            c1GaugeCaption8.FontSize = 10D;
            c1GaugeCaption8.Text = "Bar";
            c1GaugeCaption9.CenterPointX = 0.6D;
            c1GaugeCaption9.CenterPointY = 0.38D;
            c1GaugeCaption9.Color = System.Drawing.Color.Red;
            c1GaugeCaption9.FontSize = 10D;
            c1GaugeCaption9.Text = "psi";
            c1GaugeCaption10.CenterPointY = 0.85D;
            c1GaugeCaption10.FontSize = 12D;
            c1GaugeCaption10.Text = "Sea Pressure";
            this.pressureGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse5,
            c1GaugeEllipse6,
            c1GaugeEllipse7,
            c1GaugeCaption8,
            c1GaugeCaption9,
            c1GaugeCaption10});
            this.pressureGauge.Maximum = 600D;
            c1GaugePointer8.Value = 35D;
            c1GaugePointer8.ViewTag = ((long)(639662004562590328));
            c1GaugePointer8.Visible = false;
            c1GaugePointer9.Value = 60D;
            c1GaugePointer9.ViewTag = ((long)(639943479546477030));
            c1GaugePointer9.Visible = false;
            this.pressureGauge.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer8,
            c1GaugePointer9});
            this.pressureGauge.Name = "pressureGauge";
            this.pressureGauge.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.pressureGauge.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.pressureGauge.Pointer.CustomShape.EndWidth = 2D;
            this.pressureGauge.Pointer.CustomShape.StartAngle = 5D;
            this.pressureGauge.Pointer.CustomShape.StartRadius = 5D;
            this.pressureGauge.Pointer.CustomShape.StartSwellAngle = -50D;
            this.pressureGauge.Pointer.CustomShape.StartSwellLength = 5D;
            this.pressureGauge.Pointer.CustomShape.StartSwellWidth = 10D;
            this.pressureGauge.Pointer.CustomShape.StartWidth = 10D;
            this.pressureGauge.Pointer.Filling.Color = System.Drawing.Color.Black;
            this.pressureGauge.Pointer.Filling.HatchStyle = C1.Win.C1Gauge.C1GaugeHatchStyle.Wave;
            this.pressureGauge.Pointer.Length = 120D;
            this.pressureGauge.Pointer.Offset = -40D;
            this.pressureGauge.Pointer.Shadow.Visible = true;
            this.pressureGauge.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.pressureGauge.Pointer.SweepTime = 2D;
            this.pressureGauge.Pointer.Value = 45D;
            this.pressureGauge.PointerOriginX = 0.235D;
            this.pressureGauge.PointerOriginY = 0.78D;
            this.pressureGauge.Radius = 0.25D;
            this.pressureGauge.StartAngle = -130D;
            this.pressureGauge.SweepAngle = 260D;
            this.pressureGauge.ViewTag = ((long)(727472823859016765));
            // 
            // eventsGauge
            // 
            this.eventsGauge.Cap.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.eventsGauge.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.eventsGauge.Cap.Filling.Color = System.Drawing.Color.White;
            this.eventsGauge.Cap.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.eventsGauge.Cap.Radius = 15D;
            this.eventsGauge.Cap.Shadow.Visible = true;
            c1GaugeSegment4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment4.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment4.Filling.Color2 = System.Drawing.Color.CornflowerBlue;
            c1GaugeSegment4.Filling.Opacity = 0.6D;
            c1GaugeSegment4.Filling.Opacity2 = 0.1D;
            c1GaugeSegment4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment4.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSegment4.InnerRadius = 130D;
            c1GaugeSegment4.SweepAngle = 190D;
            this.eventsGauge.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment4});
            c1GaugeEllipse8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse8.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse8.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse8.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeEllipse8.Filling.SwapColors = true;
            c1GaugeEllipse8.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse8.Height = -1.08D;
            c1GaugeEllipse8.Width = -1.08D;
            c1GaugeEllipse9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse9.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse9.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse9.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse9.Filling.SwapColors = true;
            c1GaugeEllipse9.Height = -1.02D;
            c1GaugeEllipse9.Width = -1.02D;
            c1GaugeEllipse10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse10.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse10.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse10.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            c1GaugeEllipse10.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeEllipse10.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeEllipse10.Gradient.Focus = 0.08D;
            c1GaugeImage2.CenterPointY = 0.2D;
            c1GaugeImage2.Height = -0.35D;
            c1GaugeImage2.Image = ((System.Drawing.Image)(resources.GetObject("c1GaugeImage2.Image")));
            c1GaugeImage2.Name = "Sun";
            c1GaugeImage2.Width = -0.35D;
            c1GaugeImage3.CenterPointX = 0.2D;
            c1GaugeImage3.CenterPointY = 0.4D;
            c1GaugeImage3.Height = -0.35D;
            c1GaugeImage3.Image = ((System.Drawing.Image)(resources.GetObject("c1GaugeImage3.Image")));
            c1GaugeImage3.Name = "Fog";
            c1GaugeImage3.Width = -0.35D;
            c1GaugeImage4.CenterPointX = 0.29D;
            c1GaugeImage4.CenterPointY = 0.69D;
            c1GaugeImage4.FlipType = C1.Win.C1Gauge.C1GaugeFlipType.FlipX;
            c1GaugeImage4.Height = -0.35D;
            c1GaugeImage4.Image = ((System.Drawing.Image)(resources.GetObject("c1GaugeImage4.Image")));
            c1GaugeImage4.Name = "Snow";
            c1GaugeImage4.Width = -0.35D;
            c1GaugeImage5.CenterPointX = 0.8D;
            c1GaugeImage5.CenterPointY = 0.4D;
            c1GaugeImage5.Height = -0.35D;
            c1GaugeImage5.Image = ((System.Drawing.Image)(resources.GetObject("c1GaugeImage5.Image")));
            c1GaugeImage5.Name = "Rain";
            c1GaugeImage5.Width = -0.35D;
            c1GaugeImage6.CenterPointX = 0.75D;
            c1GaugeImage6.CenterPointY = 0.75D;
            c1GaugeImage6.Height = -0.35D;
            c1GaugeImage6.Image = ((System.Drawing.Image)(resources.GetObject("c1GaugeImage6.Image")));
            c1GaugeImage6.Name = "Thunderstorm";
            c1GaugeImage6.Width = -0.35D;
            this.eventsGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse8,
            c1GaugeEllipse9,
            c1GaugeEllipse10,
            c1GaugeImage2,
            c1GaugeImage3,
            c1GaugeImage4,
            c1GaugeImage5,
            c1GaugeImage6});
            this.eventsGauge.Maximum = 5D;
            this.eventsGauge.Minimum = 1D;
            c1GaugePointer10.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugePointer10.CustomShape.EndAngle = 70D;
            c1GaugePointer10.CustomShape.EndSwellAngle = 10D;
            c1GaugePointer10.CustomShape.EndSwellWidth = 6D;
            c1GaugePointer10.CustomShape.EndWidth = 12D;
            c1GaugePointer10.CustomShape.StartWidth = 12D;
            c1GaugePointer10.Filling.Color = System.Drawing.Color.IndianRed;
            c1GaugePointer10.Length = 75D;
            c1GaugePointer10.Offset = 0D;
            c1GaugePointer10.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer10.SweepTime = 1D;
            c1GaugePointer10.Value = 2D;
            c1GaugePointer10.ViewTag = ((long)(639662004562590328));
            c1GaugePointer11.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            c1GaugePointer11.CustomShape.EndAngle = 70D;
            c1GaugePointer11.CustomShape.EndSwellAngle = 10D;
            c1GaugePointer11.CustomShape.EndSwellWidth = 6D;
            c1GaugePointer11.CustomShape.EndWidth = 12D;
            c1GaugePointer11.CustomShape.StartWidth = 12D;
            c1GaugePointer11.Filling.Color = System.Drawing.Color.IndianRed;
            c1GaugePointer11.Length = 75D;
            c1GaugePointer11.Offset = 0D;
            c1GaugePointer11.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer11.SweepTime = 1D;
            c1GaugePointer11.Value = 3D;
            c1GaugePointer11.ViewTag = ((long)(639943479546477030));
            this.eventsGauge.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer10,
            c1GaugePointer11});
            this.eventsGauge.Name = "eventsGauge";
            this.eventsGauge.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.eventsGauge.Pointer.CustomShape.EndAngle = 70D;
            this.eventsGauge.Pointer.CustomShape.EndSwellAngle = 10D;
            this.eventsGauge.Pointer.CustomShape.EndSwellWidth = 6D;
            this.eventsGauge.Pointer.CustomShape.EndWidth = 12D;
            this.eventsGauge.Pointer.CustomShape.StartWidth = 12D;
            this.eventsGauge.Pointer.Filling.Color = System.Drawing.Color.IndianRed;
            this.eventsGauge.Pointer.Filling.HatchStyle = C1.Win.C1Gauge.C1GaugeHatchStyle.Wave;
            this.eventsGauge.Pointer.Length = 75D;
            this.eventsGauge.Pointer.Offset = 0D;
            this.eventsGauge.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.eventsGauge.Pointer.SweepTime = 1D;
            this.eventsGauge.Pointer.Value = 4D;
            this.eventsGauge.PointerOriginX = 0.765D;
            this.eventsGauge.PointerOriginY = 0.78D;
            this.eventsGauge.Radius = 0.25D;
            this.eventsGauge.StartAngle = -130D;
            this.eventsGauge.SweepAngle = 260D;
            this.eventsGauge.ViewTag = ((long)(727472823859016765));
            // 
            // dewPtGauge
            // 
            this.dewPtGauge.Cap.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.dewPtGauge.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.dewPtGauge.Cap.Filling.Color = System.Drawing.Color.White;
            this.dewPtGauge.Cap.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.dewPtGauge.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.weatherData1, "meanDewPt", true));
            this.dewPtGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_0", this.weatherData1, "minDewPt", true));
            this.dewPtGauge.DataBindings.Add(new System.Windows.Forms.Binding("MorePointersValue_1", this.weatherData1, "maxDewPt", true));
            c1GaugeMarks13.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks13.Filling.Color = System.Drawing.Color.Navy;
            c1GaugeMarks13.Interval = 20D;
            c1GaugeMarks13.Location = 75D;
            c1GaugeMarks13.ViewTag = ((long)(1180095605290459004));
            c1GaugeMarks13.Width = 2D;
            c1GaugeLabels7.Color = System.Drawing.Color.Navy;
            c1GaugeLabels7.FontSize = 18D;
            c1GaugeLabels7.Interval = 20D;
            c1GaugeLabels7.Location = 100D;
            c1GaugeLabels7.ViewTag = ((long)(1180377083196655837));
            c1GaugeSingleMark9.Filling.Color = System.Drawing.Color.Red;
            c1GaugeSingleMark9.Length = 15D;
            c1GaugeSingleMark9.Location = 75D;
            c1GaugeSingleMark9.PointerIndex = 0;
            c1GaugeSingleMark9.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark9.ViewTag = ((long)(1180658559533539212));
            c1GaugeSingleMark9.Width = 6D;
            c1GaugeSingleMark10.Filling.Color = System.Drawing.Color.Blue;
            c1GaugeSingleMark10.Length = 15D;
            c1GaugeSingleMark10.Location = 75D;
            c1GaugeSingleMark10.PointerIndex = 1;
            c1GaugeSingleMark10.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark10.ViewTag = ((long)(1181502985757075471));
            c1GaugeSingleMark10.Width = 6D;
            this.dewPtGauge.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks13,
            c1GaugeLabels7,
            c1GaugeSingleMark9,
            c1GaugeSingleMark10});
            c1GaugeCaption11.CenterPointY = 0.7D;
            c1GaugeCaption11.FontSize = 16D;
            c1GaugeCaption11.Text = "Dew Pt.";
            this.dewPtGauge.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption11});
            this.dewPtGauge.Minimum = -40D;
            c1GaugePointer12.Value = 40D;
            c1GaugePointer12.ViewTag = ((long)(1180940034564226214));
            c1GaugePointer12.Visible = false;
            c1GaugePointer13.Value = 80D;
            c1GaugePointer13.ViewTag = ((long)(1181221509546084903));
            c1GaugePointer13.Visible = false;
            this.dewPtGauge.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer12,
            c1GaugePointer13});
            this.dewPtGauge.Name = "dewPtGauge";
            this.dewPtGauge.Pointer.Filling.Color = System.Drawing.Color.Black;
            this.dewPtGauge.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Triangle;
            this.dewPtGauge.Pointer.SweepTime = 1D;
            this.dewPtGauge.PointerOriginY = 0.73D;
            this.dewPtGauge.Radius = 0.2D;
            this.dewPtGauge.StartAngle = -100D;
            this.dewPtGauge.SweepAngle = -160D;
            this.dewPtGauge.ViewTag = ((long)(1179532654792906204));
            // 
            // c1DbNavigator1
            // 
            this.c1DbNavigator1.AutoSize = false;
            this.c1DbNavigator1.ColorWhenHover = false;
            this.c1DbNavigator1.DataSource = this.weatherData1;
            this.c1DbNavigator1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1DbNavigator1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(199)))), ((int)(((byte)(216)))));
            this.c1DbNavigator1.Location = new System.Drawing.Point(3, 3);
            this.c1DbNavigator1.Name = "c1DbNavigator1";
            this.c1DbNavigator1.Size = new System.Drawing.Size(300, 29);
            this.c1DbNavigator1.TabIndex = 1;
            this.c1DbNavigator1.VisualStyleBaseStyle = C1.Win.C1Input.VisualStyle.Office2007Black;
            // 
            // c1TrueDBGrid1
            // 
            this.c1TrueDBGrid1.Caption = "Weather Data";
            this.c1TrueDBGrid1.CaptionHeight = 20;
            this.tableLayoutPanel1.SetColumnSpan(this.c1TrueDBGrid1, 2);
            this.c1TrueDBGrid1.DataSource = this.weatherData1;
            this.c1TrueDBGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1TrueDBGrid1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1TrueDBGrid1.Images.Add(((System.Drawing.Image)(resources.GetObject("c1TrueDBGrid1.Images"))));
            this.c1TrueDBGrid1.Location = new System.Drawing.Point(3, 438);
            this.c1TrueDBGrid1.Name = "c1TrueDBGrid1";
            this.c1TrueDBGrid1.PreviewInfo.Location = new System.Drawing.Point(0, 0);
            this.c1TrueDBGrid1.PreviewInfo.Size = new System.Drawing.Size(0, 0);
            this.c1TrueDBGrid1.PreviewInfo.ZoomFactor = 75D;
            this.c1TrueDBGrid1.PrintInfo.MeasurementDevice = C1.Win.C1TrueDBGrid.PrintInfo.MeasurementDeviceEnum.Screen;
            this.c1TrueDBGrid1.PrintInfo.MeasurementPrinterName = null;
            this.c1TrueDBGrid1.PrintInfo.PageSettings = ((System.Drawing.Printing.PageSettings)(resources.GetObject("c1TrueDBGrid1.PrintInfo.PageSettings")));
            this.c1TrueDBGrid1.RowHeight = 20;
            this.c1TrueDBGrid1.Size = new System.Drawing.Size(975, 261);
            this.c1TrueDBGrid1.TabIndex = 3;
            this.c1TrueDBGrid1.Text = "c1TrueDBGrid1";
            this.c1TrueDBGrid1.VisualStyle = C1.Win.C1TrueDBGrid.VisualStyle.Office2007Black;
            this.c1TrueDBGrid1.PropBag = resources.GetString("c1TrueDBGrid1.PropBag");
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.c1DbNavigator1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Button1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1TrueDBGrid1, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(981, 702);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // WeatherDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(72)))), ((int)(((byte)(105)))));
            this.ClientSize = new System.Drawing.Size(981, 702);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "WeatherDashboard";
            this.Text = "WeatherDashboard";
            ((System.ComponentModel.ISupportInitialize)(this.c1Button1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.weatherData1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1DbNavigator1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TrueDBGrid1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1Input.C1DbNavigator c1DbNavigator1;
        private C1.Win.C1Gauge.C1Gauge c1Gauge1;
        private C1.Win.C1Gauge.C1RadialGauge humidityGauge;
        private C1.Win.C1Gauge.C1RadialGauge pressureGauge;
        private C1.Win.C1Gauge.C1RadialGauge eventsGauge;
        private C1.Win.C1Gauge.C1LinearGauge tempGauge;
        private C1.Win.C1Gauge.C1LinearGauge cloudGauge;
        private C1.Win.C1Gauge.C1RadialGauge windGauge;
        private C1.Win.C1Gauge.C1RadialGauge visMilesGauge;
        private C1.Win.C1TrueDBGrid.C1TrueDBGrid c1TrueDBGrid1;
        private C1.Win.C1Gauge.C1RadialGauge dewPtGauge;
        private C1.Win.C1Input.C1Button c1Button1;
        private ControlExplorer.Chart.WeatherData weatherData1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}