﻿namespace ControlExplorer.Gauges
{
    partial class LinearGauges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment1 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange1 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange2 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks1 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks2 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels1 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark1 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel1 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle1 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle2 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse1 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks3 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks4 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels2 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle3 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle4 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle5 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle6 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle7 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer1 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange4 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark3 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks7 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks8 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels4 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector1 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse2 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse3 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks9 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks10 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange5 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel3 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle10 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle11 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle12 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle13 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle14 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment2 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange3 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks5 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks6 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels3 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark2 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel2 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle8 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle9 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption1 = new C1.Win.C1Gauge.C1GaugeCaption();
            this.c1Gauge1 = new C1.Win.C1Gauge.C1Gauge();
            this.c1LinearGauge1 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1Gauge2 = new C1.Win.C1Gauge.C1Gauge();
            this.c1LinearGauge3 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1Gauge4 = new C1.Win.C1Gauge.C1Gauge();
            this.c1LinearGauge4 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1Gauge3 = new C1.Win.C1Gauge.C1Gauge();
            this.c1LinearGauge2 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1Gauge5 = new C1.Win.C1Gauge.C1Gauge();
            this.c1LinearGauge5 = new C1.Win.C1Gauge.C1LinearGauge();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // c1Gauge1
            // 
            this.c1Gauge1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge1.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1LinearGauge1});
            this.c1Gauge1.Location = new System.Drawing.Point(3, 3);
            this.c1Gauge1.Name = "c1Gauge1";
            this.tableLayoutPanel1.SetRowSpan(this.c1Gauge1, 2);
            this.c1Gauge1.Size = new System.Drawing.Size(239, 740);
            this.c1Gauge1.TabIndex = 0;
            this.c1Gauge1.ViewTag = ((long)(650345882961079712));
            // 
            // c1LinearGauge1
            // 
            this.c1LinearGauge1.AxisLength = 0.85D;
            this.c1LinearGauge1.AxisStart = 0.075D;
            c1GaugeSegment1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment1.CenterPointX = 0.7D;
            c1GaugeSegment1.CenterPointY = 0.1D;
            c1GaugeSegment1.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("Face", C1.Win.C1Gauge.C1GaugeClipOperation.Replace, 0.98D)});
            c1GaugeSegment1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment1.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment1.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment1.Filling.Opacity = 0.2D;
            c1GaugeSegment1.Filling.Opacity2 = 0.4D;
            c1GaugeSegment1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment1.InnerRadius = 130D;
            c1GaugeSegment1.StartAngle = -140D;
            c1GaugeSegment1.SweepAngle = 198D;
            this.c1LinearGauge1.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment1});
            c1GaugeRange1.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeRange1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(213)))), ((int)(((byte)(240)))));
            c1GaugeRange1.Filling.Opacity = 0.75D;
            c1GaugeRange1.From = 80D;
            c1GaugeRange1.Location = 25D;
            c1GaugeRange1.To = 100D;
            c1GaugeRange1.ViewTag = ((long)(660762109709106058));
            c1GaugeRange1.Width = 25D;
            c1GaugeRange2.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeRange2.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(97)))), ((int)(((byte)(163)))));
            c1GaugeRange2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRange2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(97)))), ((int)(((byte)(163)))));
            c1GaugeRange2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(169)))), ((int)(((byte)(223)))));
            c1GaugeRange2.Filling.Opacity = 0.8D;
            c1GaugeRange2.Filling.Opacity2 = 0.8D;
            c1GaugeRange2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeRange2.Location = 25D;
            c1GaugeRange2.ToPointerIndex = 100;
            c1GaugeRange2.ViewTag = ((long)(672865563871181964));
            c1GaugeRange2.Width = 25D;
            c1GaugeMarks1.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeMarks1.Interval = 20D;
            c1GaugeMarks1.Length = 32D;
            c1GaugeMarks1.Location = 25D;
            c1GaugeMarks1.ViewTag = ((long)(651190316563358808));
            c1GaugeMarks1.Width = 1.5D;
            c1GaugeMarks2.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeMarks2.Filling.Opacity = 0.5D;
            c1GaugeMarks2.Interval = 4D;
            c1GaugeMarks2.Length = 25D;
            c1GaugeMarks2.Location = 25D;
            c1GaugeMarks2.ViewTag = ((long)(651753275780104499));
            c1GaugeMarks2.Width = 1D;
            c1GaugeLabels1.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeLabels1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeLabels1.FontSize = 11D;
            c1GaugeLabels1.Interval = 20D;
            c1GaugeLabels1.ViewTag = ((long)(651471795264041824));
            c1GaugeSingleMark1.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(160)))), ((int)(((byte)(204)))));
            c1GaugeSingleMark1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSingleMark1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            c1GaugeSingleMark1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(226)))), ((int)(((byte)(239)))));
            c1GaugeSingleMark1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSingleMark1.Length = 32D;
            c1GaugeSingleMark1.Location = 37D;
            c1GaugeSingleMark1.OrthogonalOffset = 12D;
            c1GaugeSingleMark1.PointerIndex = 100;
            c1GaugeSingleMark1.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeSingleMark1.Shadow.Opacity = 0.15D;
            c1GaugeSingleMark1.Shadow.Visible = true;
            c1GaugeSingleMark1.ViewTag = ((long)(661043586079997651));
            c1GaugeSingleMark1.Width = 18D;
            c1GaugeSingleLabel1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeSingleLabel1.FontSize = 12D;
            c1GaugeSingleLabel1.Format = "n0";
            c1GaugeSingleLabel1.Location = 37D;
            c1GaugeSingleLabel1.OrthogonalOffset = 12D;
            c1GaugeSingleLabel1.PointerIndex = 100;
            c1GaugeSingleLabel1.ViewTag = ((long)(661325062457441286));
            this.c1LinearGauge1.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange1,
            c1GaugeRange2,
            c1GaugeMarks1,
            c1GaugeMarks2,
            c1GaugeLabels1,
            c1GaugeSingleMark1,
            c1GaugeSingleLabel1});
            c1GaugeRectangle1.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(217)))), ((int)(((byte)(241)))));
            c1GaugeRectangle1.Border.Thickness = 1D;
            c1GaugeRectangle1.CornerRadius = 3D;
            c1GaugeRectangle1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            c1GaugeRectangle1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(217)))), ((int)(((byte)(241)))));
            c1GaugeRectangle1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle1.Height = -1.15D;
            c1GaugeRectangle1.Width = -1.08D;
            c1GaugeRectangle2.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(160)))), ((int)(((byte)(204)))));
            c1GaugeRectangle2.Border.Thickness = 1D;
            c1GaugeRectangle2.CornerRadius = 2D;
            c1GaugeRectangle2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            c1GaugeRectangle2.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeRectangle2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle2.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRectangle2.Gradient.Focus = 0.6D;
            c1GaugeRectangle2.Height = -1.1D;
            c1GaugeRectangle2.Name = "Face";
            c1GaugeRectangle2.Width = -0.9D;
            this.c1LinearGauge1.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle1,
            c1GaugeRectangle2});
            this.c1LinearGauge1.IsReversed = true;
            this.c1LinearGauge1.Name = "c1LinearGauge1";
            this.c1LinearGauge1.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge1.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.c1LinearGauge1.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1LinearGauge1.Pointer.FlipShape = true;
            this.c1LinearGauge1.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            this.c1LinearGauge1.Pointer.Length = 58D;
            this.c1LinearGauge1.Pointer.Offset = 8D;
            this.c1LinearGauge1.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1LinearGauge1.Pointer.Shadow.Opacity = 0.15D;
            this.c1LinearGauge1.Pointer.Shadow.Visible = true;
            this.c1LinearGauge1.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Rectangle;
            this.c1LinearGauge1.Pointer.SweepTime = 3D;
            this.c1LinearGauge1.Pointer.Value = 63D;
            this.c1LinearGauge1.Pointer.Visible = false;
            this.c1LinearGauge1.Pointer.Width = 8D;
            this.c1LinearGauge1.Viewport.AspectRatio = 0.3D;
            this.c1LinearGauge1.ViewTag = ((long)(650627358688755457));
            // 
            // c1Gauge2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge2, 3);
            this.c1Gauge2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge2.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1LinearGauge3});
            this.c1Gauge2.Location = new System.Drawing.Point(248, 487);
            this.c1Gauge2.Name = "c1Gauge2";
            this.c1Gauge2.Size = new System.Drawing.Size(730, 256);
            this.c1Gauge2.TabIndex = 1;
            this.c1Gauge2.ViewTag = ((long)(682997085326371631));
            // 
            // c1LinearGauge3
            // 
            this.c1LinearGauge3.AxisLength = 0.85D;
            this.c1LinearGauge3.AxisStart = 0.08D;
            c1GaugeEllipse1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse1.CenterPointY = 0.05D;
            c1GaugeEllipse1.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("Face", C1.Win.C1Gauge.C1GaugeClipOperation.Replace, 1D)});
            c1GaugeEllipse1.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse1.Filling.Opacity = 0.4D;
            c1GaugeEllipse1.Width = -1.2D;
            this.c1LinearGauge3.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse1});
            c1GaugeMarks3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(136)))), ((int)(((byte)(190)))));
            c1GaugeMarks3.Interval = 10D;
            c1GaugeMarks3.Length = 50D;
            c1GaugeMarks3.Location = 75D;
            c1GaugeMarks3.ViewTag = ((long)(683841510969454887));
            c1GaugeMarks3.Width = 2D;
            c1GaugeMarks4.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks4.Filling.Color = System.Drawing.Color.White;
            c1GaugeMarks4.Interval = 1D;
            c1GaugeMarks4.Length = 25D;
            c1GaugeMarks4.Location = 74D;
            c1GaugeMarks4.ViewTag = ((long)(687500698342680887));
            c1GaugeMarks4.Width = 1D;
            c1GaugeLabels2.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeLabels2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(106)))), ((int)(((byte)(170)))));
            c1GaugeLabels2.FontSize = 10D;
            c1GaugeLabels2.Interval = 10D;
            c1GaugeLabels2.Location = 25D;
            c1GaugeLabels2.ViewTag = ((long)(684404461482982204));
            this.c1LinearGauge3.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks3,
            c1GaugeMarks4,
            c1GaugeLabels2});
            c1GaugeRectangle3.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(178)))), ((int)(((byte)(227)))));
            c1GaugeRectangle3.Border.Thickness = 1D;
            c1GaugeRectangle3.CornerRadius = 5D;
            c1GaugeRectangle3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            c1GaugeRectangle3.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(145)))), ((int)(((byte)(205)))));
            c1GaugeRectangle3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle3.Height = -1.1D;
            c1GaugeRectangle3.Name = "Face";
            c1GaugeRectangle3.Width = -1.1D;
            c1GaugeRectangle4.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(248)))), ((int)(((byte)(254)))));
            c1GaugeRectangle4.Border.Thickness = 1D;
            c1GaugeRectangle4.CornerRadius = 3D;
            c1GaugeRectangle4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle4.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(241)))), ((int)(((byte)(250)))));
            c1GaugeRectangle4.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(230)))), ((int)(((byte)(242)))));
            c1GaugeRectangle4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle4.Height = -0.95D;
            c1GaugeRectangle4.Width = -1.05D;
            c1GaugeRectangle5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(216)))), ((int)(((byte)(242)))));
            c1GaugeRectangle5.Height = -0.5D;
            c1GaugeRectangle6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle6.CenterPointY = 0.75D;
            c1GaugeRectangle6.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(136)))), ((int)(((byte)(190)))));
            c1GaugeRectangle6.Height = 2D;
            c1GaugeRectangle6.Width = -1.005D;
            c1GaugeRectangle7.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(136)))), ((int)(((byte)(190)))));
            c1GaugeRectangle7.CenterPointY = 0.85D;
            c1GaugeRectangle7.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle7.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(50)))), ((int)(((byte)(88)))));
            c1GaugeRectangle7.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(218)))), ((int)(((byte)(241)))));
            c1GaugeRectangle7.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle7.Height = 3D;
            c1GaugeRectangle7.Width = -1.005D;
            this.c1LinearGauge3.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle3,
            c1GaugeRectangle4,
            c1GaugeRectangle5,
            c1GaugeRectangle6,
            c1GaugeRectangle7});
            this.c1LinearGauge3.Maximum = 30D;
            this.c1LinearGauge3.Minimum = -20D;
            c1GaugePointer1.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugePointer1.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(177)))), ((int)(((byte)(42)))));
            c1GaugePointer1.CustomShape.EndRadius = 1D;
            c1GaugePointer1.CustomShape.EndWidth = 3D;
            c1GaugePointer1.CustomShape.StartRadius = 2D;
            c1GaugePointer1.CustomShape.StartWidth = 9D;
            c1GaugePointer1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugePointer1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(215)))), ((int)(((byte)(106)))));
            c1GaugePointer1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(229)))), ((int)(((byte)(155)))));
            c1GaugePointer1.FlipShape = true;
            c1GaugePointer1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugePointer1.Length = 70D;
            c1GaugePointer1.Offset = 90D;
            c1GaugePointer1.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(70)))), ((int)(((byte)(154)))));
            c1GaugePointer1.Shadow.Opacity = 0.4D;
            c1GaugePointer1.Shadow.Visible = true;
            c1GaugePointer1.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer1.SweepTime = 4D;
            c1GaugePointer1.ViewTag = ((long)(687782176789898559));
            this.c1LinearGauge3.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer1});
            this.c1LinearGauge3.Name = "c1LinearGauge3";
            this.c1LinearGauge3.Pointer.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            this.c1LinearGauge3.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1LinearGauge3.Pointer.CustomShape.EndRadius = 1D;
            this.c1LinearGauge3.Pointer.CustomShape.EndWidth = 3D;
            this.c1LinearGauge3.Pointer.CustomShape.StartRadius = 2D;
            this.c1LinearGauge3.Pointer.CustomShape.StartWidth = 9D;
            this.c1LinearGauge3.Pointer.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1LinearGauge3.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1LinearGauge3.Pointer.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(207)))), ((int)(((byte)(153)))));
            this.c1LinearGauge3.Pointer.FlipShape = true;
            this.c1LinearGauge3.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            this.c1LinearGauge3.Pointer.Length = 70D;
            this.c1LinearGauge3.Pointer.Offset = 92D;
            this.c1LinearGauge3.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(70)))), ((int)(((byte)(154)))));
            this.c1LinearGauge3.Pointer.Shadow.Opacity = 0.4D;
            this.c1LinearGauge3.Pointer.Shadow.Visible = true;
            this.c1LinearGauge3.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.c1LinearGauge3.Pointer.SweepTime = 4D;
            this.c1LinearGauge3.Pointer.Value = 12D;
            this.c1LinearGauge3.Viewport.AspectRatio = 3D;
            this.c1LinearGauge3.ViewTag = ((long)(683278560329494928));
            // 
            // c1Gauge4
            // 
            this.c1Gauge4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge4.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1LinearGauge4});
            this.c1Gauge4.Location = new System.Drawing.Point(248, 3);
            this.c1Gauge4.Name = "c1Gauge4";
            this.c1Gauge4.Size = new System.Drawing.Size(239, 478);
            this.c1Gauge4.TabIndex = 3;
            this.c1Gauge4.ViewTag = ((long)(761248883865943896));
            // 
            // c1LinearGauge4
            // 
            this.c1LinearGauge4.AxisLength = 0.77D;
            this.c1LinearGauge4.AxisStart = 0.08D;
            c1GaugeRange4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRange4.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeRange4.Filling.Color2 = System.Drawing.Color.Red;
            c1GaugeRange4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeRange4.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRange4.Location = 50D;
            c1GaugeRange4.ToPointerIndex = 1;
            c1GaugeRange4.ViewTag = ((long)(739294773683120203));
            c1GaugeRange4.Width = 15D;
            c1GaugeSingleMark3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark3.CustomShape.EndAngle = 60D;
            c1GaugeSingleMark3.CustomShape.EndRadius = 10D;
            c1GaugeSingleMark3.CustomShape.EndWidth = 3D;
            c1GaugeSingleMark3.CustomShape.StartAngle = 60D;
            c1GaugeSingleMark3.CustomShape.StartRadius = 10D;
            c1GaugeSingleMark3.CustomShape.StartWidth = 3D;
            c1GaugeSingleMark3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSingleMark3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeSingleMark3.Filling.Color2 = System.Drawing.Color.LightCoral;
            c1GaugeSingleMark3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSingleMark3.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSingleMark3.Length = 15D;
            c1GaugeSingleMark3.Location = 50D;
            c1GaugeSingleMark3.PointerIndex = 1;
            c1GaugeSingleMark3.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Custom;
            c1GaugeSingleMark3.ViewTag = ((long)(637124138919996870));
            c1GaugeMarks7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks7.CustomShape.EndRadius = 15D;
            c1GaugeMarks7.CustomShape.EndWidth = 12D;
            c1GaugeMarks7.CustomShape.StartRadius = -15D;
            c1GaugeMarks7.CustomShape.StartWidth = 12D;
            c1GaugeMarks7.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeMarks7.Interval = 0.1D;
            c1GaugeMarks7.Length = 0.5D;
            c1GaugeMarks7.Location = 50D;
            c1GaugeMarks7.OrthogonalOffset = -2D;
            c1GaugeMarks7.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Custom;
            c1GaugeMarks7.ShapeAngle = 90D;
            c1GaugeMarks7.ViewTag = ((long)(737605923822856267));
            c1GaugeMarks8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks8.CustomShape.EndRadius = 7.5D;
            c1GaugeMarks8.CustomShape.EndWidth = 6D;
            c1GaugeMarks8.CustomShape.StartRadius = -7.5D;
            c1GaugeMarks8.CustomShape.StartWidth = 6D;
            c1GaugeMarks8.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeMarks8.Interval = 0.05D;
            c1GaugeMarks8.Length = 0.5D;
            c1GaugeMarks8.Location = 50D;
            c1GaugeMarks8.OrthogonalOffset = -2D;
            c1GaugeMarks8.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Custom;
            c1GaugeMarks8.ShapeAngle = 90D;
            c1GaugeMarks8.ViewTag = ((long)(738168873776277579));
            c1GaugeLabels4.Color = System.Drawing.Color.DimGray;
            c1GaugeLabels4.FontSize = 9D;
            c1GaugeLabels4.Format = "p0";
            c1GaugeLabels4.From = 0D;
            c1GaugeLabels4.Interval = 0.1D;
            c1GaugeLabels4.Location = 92D;
            c1GaugeLabels4.OrthogonalOffset = -2D;
            c1GaugeLabels4.ViewTag = ((long)(738731823729698891));
            this.c1LinearGauge4.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange4,
            c1GaugeSingleMark3,
            c1GaugeMarks7,
            c1GaugeMarks8,
            c1GaugeLabels4});
            this.c1LinearGauge4.FaceAhead = true;
            c1GaugeSector1.Border.Color = System.Drawing.Color.DarkGray;
            c1GaugeSector1.CenterPointY = 1.05D;
            c1GaugeSector1.CenterRadius = 12D;
            c1GaugeSector1.CornerRadius = 10D;
            c1GaugeSector1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector1.Filling.Color = System.Drawing.Color.White;
            c1GaugeSector1.Filling.Color2 = System.Drawing.Color.DarkGray;
            c1GaugeSector1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeSector1.Gradient.ScaleX = 0.2D;
            c1GaugeSector1.Gradient.TranslateX = 0.4D;
            c1GaugeSector1.OuterRadius = 208.5D;
            c1GaugeSector1.SweepAngle = 0D;
            c1GaugeEllipse2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse2.CenterPointY = 1.05D;
            c1GaugeEllipse2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse2.Filling.Color = System.Drawing.Color.Red;
            c1GaugeEllipse2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeEllipse2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeEllipse2.Height = 25D;
            c1GaugeEllipse2.Width = 25D;
            this.c1LinearGauge4.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSector1,
            c1GaugeEllipse2});
            this.c1LinearGauge4.IsReversed = true;
            this.c1LinearGauge4.Maximum = 1D;
            this.c1LinearGauge4.Name = "c1LinearGauge4";
            this.c1LinearGauge4.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge4.Pointer.SweepTime = 6D;
            this.c1LinearGauge4.Pointer.Value = 0.42D;
            this.c1LinearGauge4.Pointer.Visible = false;
            this.c1LinearGauge4.Viewport.AspectRatio = 0.5D;
            this.c1LinearGauge4.ViewTag = ((long)(737042973869434955));
            // 
            // c1Gauge3
            // 
            this.c1Gauge3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge3.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1LinearGauge2});
            this.c1Gauge3.Location = new System.Drawing.Point(493, 3);
            this.c1Gauge3.Name = "c1Gauge3";
            this.c1Gauge3.Size = new System.Drawing.Size(239, 478);
            this.c1Gauge3.TabIndex = 4;
            this.c1Gauge3.ViewTag = ((long)(650345882961079712));
            // 
            // c1LinearGauge2
            // 
            this.c1LinearGauge2.AxisLength = 0.8D;
            this.c1LinearGauge2.AxisStart = 0.07D;
            c1GaugeEllipse3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse3.CenterPointY = -0.04D;
            c1GaugeEllipse3.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("Face", C1.Win.C1Gauge.C1GaugeClipOperation.Replace, 1D)});
            c1GaugeEllipse3.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse3.Filling.Opacity = 0.4D;
            c1GaugeEllipse3.Height = -0.25D;
            c1GaugeEllipse3.Width = -1.2D;
            this.c1LinearGauge2.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse3});
            c1GaugeMarks9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks9.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(83)))), ((int)(((byte)(83)))));
            c1GaugeMarks9.Interval = 0.2D;
            c1GaugeMarks9.Length = 45D;
            c1GaugeMarks9.Location = 50D;
            c1GaugeMarks9.ViewTag = ((long)(651190316563358808));
            c1GaugeMarks9.Width = 2D;
            c1GaugeMarks10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks10.Filling.Color = System.Drawing.Color.White;
            c1GaugeMarks10.Interval = 0.03D;
            c1GaugeMarks10.Length = 35D;
            c1GaugeMarks10.Location = 50D;
            c1GaugeMarks10.ViewTag = ((long)(651753275780104499));
            c1GaugeMarks10.Width = 1D;
            c1GaugeRange5.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            c1GaugeRange5.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRange5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            c1GaugeRange5.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(207)))), ((int)(((byte)(153)))));
            c1GaugeRange5.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            c1GaugeRange5.Location = 50D;
            c1GaugeRange5.ToPointerIndex = 100;
            c1GaugeRange5.ViewTag = ((long)(654568073860413945));
            c1GaugeRange5.Width = 25D;
            c1GaugeSingleLabel3.Color = System.Drawing.Color.White;
            c1GaugeSingleLabel3.FontSize = 18D;
            c1GaugeSingleLabel3.Format = "p0";
            c1GaugeSingleLabel3.Location = 50D;
            c1GaugeSingleLabel3.PointerIndex = 100;
            c1GaugeSingleLabel3.Position = -0.08D;
            c1GaugeSingleLabel3.ViewTag = ((long)(654286592041409128));
            this.c1LinearGauge2.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks9,
            c1GaugeMarks10,
            c1GaugeRange5,
            c1GaugeSingleLabel3});
            c1GaugeRectangle10.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeRectangle10.Border.Thickness = 1D;
            c1GaugeRectangle10.CenterPointY = 0.54D;
            c1GaugeRectangle10.CornerRadius = 5D;
            c1GaugeRectangle10.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle10.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(84)))), ((int)(((byte)(83)))));
            c1GaugeRectangle10.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeRectangle10.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle10.Height = -1.2D;
            c1GaugeRectangle10.Name = "Face";
            c1GaugeRectangle10.Width = -1.09D;
            c1GaugeRectangle11.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeRectangle11.Border.Thickness = 1D;
            c1GaugeRectangle11.CenterPointY = 0.54D;
            c1GaugeRectangle11.CornerRadius = 3D;
            c1GaugeRectangle11.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle11.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(245)))));
            c1GaugeRectangle11.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(191)))), ((int)(((byte)(200)))));
            c1GaugeRectangle11.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle11.Height = -1.16D;
            c1GaugeRectangle11.Width = -0.98D;
            c1GaugeRectangle12.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle12.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            c1GaugeRectangle12.Width = -0.25D;
            c1GaugeRectangle13.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle13.CenterPointX = 0.15D;
            c1GaugeRectangle13.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            c1GaugeRectangle13.Filling.Opacity = 0.5D;
            c1GaugeRectangle13.Height = -1.01D;
            c1GaugeRectangle13.Width = 2D;
            c1GaugeRectangle14.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle14.CenterPointY = 1.07D;
            c1GaugeRectangle14.CornerRadius = 1D;
            c1GaugeRectangle14.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            c1GaugeRectangle14.Height = 25D;
            c1GaugeRectangle14.Width = -0.92D;
            this.c1LinearGauge2.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle10,
            c1GaugeRectangle11,
            c1GaugeRectangle12,
            c1GaugeRectangle13,
            c1GaugeRectangle14});
            this.c1LinearGauge2.IsReversed = true;
            this.c1LinearGauge2.Maximum = 1D;
            this.c1LinearGauge2.Name = "c1LinearGauge2";
            this.c1LinearGauge2.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge2.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1LinearGauge2.Pointer.CustomShape.EndRadius = 1D;
            this.c1LinearGauge2.Pointer.CustomShape.EndWidth = 3D;
            this.c1LinearGauge2.Pointer.CustomShape.StartRadius = 2D;
            this.c1LinearGauge2.Pointer.CustomShape.StartWidth = 9D;
            this.c1LinearGauge2.Pointer.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1LinearGauge2.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1LinearGauge2.Pointer.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(207)))), ((int)(((byte)(153)))));
            this.c1LinearGauge2.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            this.c1LinearGauge2.Pointer.Offset = 8D;
            this.c1LinearGauge2.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(70)))), ((int)(((byte)(154)))));
            this.c1LinearGauge2.Pointer.Shadow.Opacity = 0.4D;
            this.c1LinearGauge2.Pointer.Shadow.Visible = true;
            this.c1LinearGauge2.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.c1LinearGauge2.Pointer.SweepTime = 2D;
            this.c1LinearGauge2.Pointer.Value = 0.5D;
            this.c1LinearGauge2.Viewport.AspectRatio = 0.3D;
            this.c1LinearGauge2.ViewTag = ((long)(650627358688755457));
            // 
            // c1Gauge5
            // 
            this.c1Gauge5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge5.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1LinearGauge5});
            this.c1Gauge5.Location = new System.Drawing.Point(738, 3);
            this.c1Gauge5.Name = "c1Gauge5";
            this.c1Gauge5.Size = new System.Drawing.Size(240, 478);
            this.c1Gauge5.TabIndex = 5;
            this.c1Gauge5.ViewTag = ((long)(650345882961079712));
            // 
            // c1LinearGauge5
            // 
            this.c1LinearGauge5.AxisLength = 0.8D;
            this.c1LinearGauge5.AxisStart = 0.12D;
            c1GaugeSegment2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment2.CenterPointX = 0.7D;
            c1GaugeSegment2.CenterPointY = 0.1D;
            c1GaugeSegment2.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("Face", C1.Win.C1Gauge.C1GaugeClipOperation.Replace, 0.98D)});
            c1GaugeSegment2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment2.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment2.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment2.Filling.Opacity = 0.2D;
            c1GaugeSegment2.Filling.Opacity2 = 0.4D;
            c1GaugeSegment2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment2.InnerRadius = 130D;
            c1GaugeSegment2.StartAngle = -140D;
            c1GaugeSegment2.SweepAngle = 188D;
            this.c1LinearGauge5.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment2});
            c1GaugeRange3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(213)))), ((int)(((byte)(240)))));
            c1GaugeRange3.Filling.Opacity = 0.75D;
            c1GaugeRange3.From = 20D;
            c1GaugeRange3.Location = 50D;
            c1GaugeRange3.To = 80D;
            c1GaugeRange3.ViewTag = ((long)(660762109709106058));
            c1GaugeRange3.Width = 25D;
            c1GaugeMarks5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeMarks5.Interval = 20D;
            c1GaugeMarks5.Length = 32D;
            c1GaugeMarks5.Location = 50D;
            c1GaugeMarks5.ViewTag = ((long)(651190316563358808));
            c1GaugeMarks5.Width = 1.5D;
            c1GaugeMarks6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks6.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeMarks6.Filling.Opacity = 0.5D;
            c1GaugeMarks6.Interval = 4D;
            c1GaugeMarks6.Length = 25D;
            c1GaugeMarks6.Location = 50D;
            c1GaugeMarks6.ViewTag = ((long)(651753275780104499));
            c1GaugeMarks6.Width = 1D;
            c1GaugeLabels3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeLabels3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeLabels3.FontSize = 11D;
            c1GaugeLabels3.Interval = 20D;
            c1GaugeLabels3.Location = 90D;
            c1GaugeLabels3.ViewTag = ((long)(651471795264041824));
            c1GaugeSingleMark2.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(160)))), ((int)(((byte)(204)))));
            c1GaugeSingleMark2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSingleMark2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            c1GaugeSingleMark2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(226)))), ((int)(((byte)(239)))));
            c1GaugeSingleMark2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSingleMark2.Length = 32D;
            c1GaugeSingleMark2.Location = 82D;
            c1GaugeSingleMark2.PointerIndex = 100;
            c1GaugeSingleMark2.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeSingleMark2.Shadow.Opacity = 0.15D;
            c1GaugeSingleMark2.Shadow.Visible = true;
            c1GaugeSingleMark2.ViewTag = ((long)(661043586079997651));
            c1GaugeSingleMark2.Width = 18D;
            c1GaugeSingleLabel2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeSingleLabel2.FontSize = 12D;
            c1GaugeSingleLabel2.Format = "n0";
            c1GaugeSingleLabel2.Location = 82D;
            c1GaugeSingleLabel2.PointerIndex = 100;
            c1GaugeSingleLabel2.ViewTag = ((long)(661325062457441286));
            this.c1LinearGauge5.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange3,
            c1GaugeMarks5,
            c1GaugeMarks6,
            c1GaugeLabels3,
            c1GaugeSingleMark2,
            c1GaugeSingleLabel2});
            c1GaugeRectangle8.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(217)))), ((int)(((byte)(241)))));
            c1GaugeRectangle8.Border.Thickness = 1D;
            c1GaugeRectangle8.CenterPointY = 0.47D;
            c1GaugeRectangle8.CornerRadius = 3D;
            c1GaugeRectangle8.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle8.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            c1GaugeRectangle8.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(217)))), ((int)(((byte)(241)))));
            c1GaugeRectangle8.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle8.Height = -1.2D;
            c1GaugeRectangle8.Width = -1.08D;
            c1GaugeRectangle9.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(160)))), ((int)(((byte)(204)))));
            c1GaugeRectangle9.Border.Thickness = 1D;
            c1GaugeRectangle9.CenterPointY = 0.47D;
            c1GaugeRectangle9.CornerRadius = 2D;
            c1GaugeRectangle9.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle9.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            c1GaugeRectangle9.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeRectangle9.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle9.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRectangle9.Gradient.Focus = 0.6D;
            c1GaugeRectangle9.Height = -1.14D;
            c1GaugeRectangle9.Name = "Face";
            c1GaugeRectangle9.Width = -0.9D;
            c1GaugeCaption1.CenterPointY = -0.05D;
            c1GaugeCaption1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(160)))), ((int)(((byte)(204)))));
            c1GaugeCaption1.FontSize = 12D;
            c1GaugeCaption1.Text = "Windows 7";
            this.c1LinearGauge5.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle8,
            c1GaugeRectangle9,
            c1GaugeCaption1});
            this.c1LinearGauge5.IsReversed = true;
            this.c1LinearGauge5.Name = "c1LinearGauge5";
            this.c1LinearGauge5.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge5.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.c1LinearGauge5.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1LinearGauge5.Pointer.FlipShape = true;
            this.c1LinearGauge5.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            this.c1LinearGauge5.Pointer.Length = 58D;
            this.c1LinearGauge5.Pointer.Offset = 8D;
            this.c1LinearGauge5.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1LinearGauge5.Pointer.Shadow.Opacity = 0.15D;
            this.c1LinearGauge5.Pointer.Shadow.Visible = true;
            this.c1LinearGauge5.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Rectangle;
            this.c1LinearGauge5.Pointer.SweepTime = 4D;
            this.c1LinearGauge5.Pointer.Value = 63D;
            this.c1LinearGauge5.Pointer.Width = 8D;
            this.c1LinearGauge5.Viewport.AspectRatio = 0.3D;
            this.c1LinearGauge5.ViewTag = ((long)(650627358688755457));
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge5, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge3, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(981, 746);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // LinearGauges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 746);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "LinearGauges";
            this.Text = "LinearGauges";
            this.Load += new System.EventHandler(this.LinearGauges_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1Gauge.C1Gauge c1Gauge1;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge1;
        private C1.Win.C1Gauge.C1Gauge c1Gauge2;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge3;
        private C1.Win.C1Gauge.C1Gauge c1Gauge4;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge4;
        private C1.Win.C1Gauge.C1Gauge c1Gauge3;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge2;
        private C1.Win.C1Gauge.C1Gauge c1Gauge5;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}