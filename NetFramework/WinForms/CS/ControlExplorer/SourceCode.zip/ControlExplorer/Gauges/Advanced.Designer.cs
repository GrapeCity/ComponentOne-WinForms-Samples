﻿namespace ControlExplorer.Gauges
{
    partial class Advanced
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange1 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks1 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange2 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange3 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks2 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel1 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels1 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel2 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels2 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel3 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange4 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse1 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer1 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer2 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer3 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks3 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks4 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels3 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment1 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel4 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark1 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark2 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark3 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark4 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark5 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark6 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark7 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark8 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark9 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark10 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark11 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark12 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark13 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark14 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark15 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark16 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark17 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark18 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark19 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark20 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark21 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark22 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark23 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark24 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark25 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark26 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark27 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark28 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark29 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark30 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark31 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark32 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark33 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark34 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark35 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark36 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark37 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark38 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark39 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark40 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark41 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark42 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark43 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark44 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark45 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark46 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark47 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark48 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark49 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark50 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark51 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark52 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark53 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark54 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark55 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark56 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark57 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark58 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark59 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark60 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark61 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark62 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark63 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark64 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark65 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark66 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark67 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark68 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark69 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark70 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark71 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark72 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark73 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark74 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark75 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark76 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark77 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark78 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark79 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark80 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark81 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark82 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark83 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark84 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark85 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark86 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark87 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark88 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark89 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark90 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark91 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark92 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark93 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark94 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark95 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark96 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark97 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark98 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark99 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark100 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle1 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks5 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks6 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks7 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks8 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks9 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks10 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks11 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks12 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks13 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks14 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle2 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption1 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption2 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption3 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption4 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption5 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption6 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption7 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption8 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption9 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption10 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer4 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer5 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer6 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer7 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer8 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer9 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer10 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer11 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer12 = new C1.Win.C1Gauge.C1GaugePointer();
            C1.Win.C1Gauge.C1GaugePointer c1GaugePointer13 = new C1.Win.C1Gauge.C1GaugePointer();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Advanced));
            this.c1Gauge1 = new C1.Win.C1Gauge.C1Gauge();
            this.c1RadialGauge1 = new C1.Win.C1Gauge.C1RadialGauge();
            this.c1Gauge2 = new C1.Win.C1Gauge.C1Gauge();
            this.c1RadialGauge2 = new C1.Win.C1Gauge.C1RadialGauge();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.c1Gauge3 = new C1.Win.C1Gauge.C1Gauge();
            this.c1LinearGauge1 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1Gauge4 = new C1.Win.C1Gauge.C1Gauge();
            this.c1LinearGauge2 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1Sizer1 = new C1.Win.C1Sizer.C1Sizer();
            this.trackBar4 = new System.Windows.Forms.TrackBar();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer1)).BeginInit();
            this.c1Sizer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            this.SuspendLayout();
            // 
            // c1Gauge1
            // 
            this.c1Gauge1.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1RadialGauge1});
            this.c1Gauge1.Location = new System.Drawing.Point(4, 4);
            this.c1Gauge1.Name = "c1Gauge1";
            this.c1Gauge1.Size = new System.Drawing.Size(382, 300);
            this.c1Gauge1.TabIndex = 1;
            this.c1Gauge1.ViewTag = ((long)(643031879101921487));
            // 
            // c1RadialGauge1
            // 
            this.c1RadialGauge1.Cap.Visible = false;
            c1GaugeRange1.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRange1.Filling.Color = System.Drawing.Color.AntiqueWhite;
            c1GaugeRange1.Filling.Color2 = System.Drawing.Color.RosyBrown;
            c1GaugeRange1.Gradient.CenterPointX = 0.4D;
            c1GaugeRange1.Gradient.CenterPointY = 0.6D;
            c1GaugeRange1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeRange1.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.SigmaBell;
            c1GaugeRange1.Location = 90D;
            c1GaugeRange1.Location2 = 30D;
            c1GaugeRange1.ViewTag = ((long)(655418274945540252));
            c1GaugeRange1.Width = 40D;
            c1GaugeRange1.Width2 = 10D;
            c1GaugeMarks1.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks1.Filling.Color = System.Drawing.Color.RosyBrown;
            c1GaugeMarks1.Interval = 10D;
            c1GaugeMarks1.Length = 39.5D;
            c1GaugeMarks1.Length2 = 11.5D;
            c1GaugeMarks1.Location = 89D;
            c1GaugeMarks1.Location2 = 32.3D;
            c1GaugeMarks1.ScaleFrom = -90D;
            c1GaugeMarks1.ScaleTo = 180D;
            c1GaugeMarks1.ViewTag = ((long)(656825655115455895));
            c1GaugeMarks1.Width = 1D;
            c1GaugeRange2.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeRange2.Border.Color = System.Drawing.Color.LightCoral;
            c1GaugeRange2.Location = 95D;
            c1GaugeRange2.Location2 = 35D;
            c1GaugeRange2.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(-90D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224))))), 1D, ((long)(676529226475175784))),
            new C1.Win.C1Gauge.C1GaugeValueColor(-40D, -1, System.Drawing.Color.PaleGreen, 1D, ((long)(677936611759773970))),
            new C1.Win.C1Gauge.C1GaugeValueColor(-25D, -1, System.Drawing.Color.LightSalmon, 1D, ((long)(678218087732741609))),
            new C1.Win.C1Gauge.C1GaugeValueColor(-7D, -1, System.Drawing.Color.IndianRed, 1D, ((long)(677655136309166209))),
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.SteelBlue, 1D, ((long)(678499567948351913))),
            new C1.Win.C1Gauge.C1GaugeValueColor(70D, -1, System.Drawing.Color.MidnightBlue, 1D, ((long)(678781044024275440))),
            new C1.Win.C1Gauge.C1GaugeValueColor(180D, -1, System.Drawing.Color.IndianRed, 1D, ((long)(677373661041038885)))});
            c1GaugeRange2.ViewTag = ((long)(653447916928237854));
            c1GaugeRange2.Width = 18D;
            c1GaugeRange2.Width2 = 18D;
            c1GaugeRange3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange3.Filling.Color = System.Drawing.Color.LightCoral;
            c1GaugeRange3.Location = 95D;
            c1GaugeRange3.Location2 = 35D;
            c1GaugeRange3.ViewTag = ((long)(655136798311694813));
            c1GaugeRange3.Width = 5D;
            c1GaugeMarks2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeMarks2.Filling.Color = System.Drawing.Color.White;
            c1GaugeMarks2.Filling.Color2 = System.Drawing.Color.DimGray;
            c1GaugeMarks2.From = -90D;
            c1GaugeMarks2.Interval = 10D;
            c1GaugeMarks2.IsRotated = false;
            c1GaugeMarks2.Length = 5D;
            c1GaugeMarks2.Location = 91.5D;
            c1GaugeMarks2.Location2 = 32.7D;
            c1GaugeMarks2.SequenceNo = -1;
            c1GaugeMarks2.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks2.ViewTag = ((long)(641063176673067260));
            c1GaugeSingleLabel1.Angle = -86D;
            c1GaugeSingleLabel1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            c1GaugeSingleLabel1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            c1GaugeSingleLabel1.FontSize = 9D;
            c1GaugeSingleLabel1.Location = 100D;
            c1GaugeSingleLabel1.SequenceNo = 0;
            c1GaugeSingleLabel1.Text = " RPM\r\nx1000";
            c1GaugeSingleLabel1.ViewTag = ((long)(637122515720112954));
            c1GaugeLabels1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            c1GaugeLabels1.FontSize = 10D;
            c1GaugeLabels1.FontSize2 = 14D;
            c1GaugeLabels1.Interval = 10D;
            c1GaugeLabels1.Location = 103D;
            c1GaugeLabels1.Location2 = 84D;
            c1GaugeLabels1.ScaleFrom = -90D;
            c1GaugeLabels1.ScaleTo = 0D;
            c1GaugeLabels1.To = -1D;
            c1GaugeLabels1.ValueFactor = 0.1D;
            c1GaugeLabels1.ValueOffset = 9D;
            c1GaugeLabels1.ViewTag = ((long)(636559562791001442));
            c1GaugeSingleLabel2.Angle = 170D;
            c1GaugeSingleLabel2.Color = System.Drawing.Color.White;
            c1GaugeSingleLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            c1GaugeSingleLabel2.FontSize = 10D;
            c1GaugeSingleLabel2.Location = 24D;
            c1GaugeSingleLabel2.Text = "MPH";
            c1GaugeSingleLabel2.ViewTag = ((long)(637403993970580858));
            c1GaugeLabels2.Color = System.Drawing.Color.White;
            c1GaugeLabels2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            c1GaugeLabels2.FontSize = 11D;
            c1GaugeLabels2.FontSize2 = 6D;
            c1GaugeLabels2.Interval = 10D;
            c1GaugeLabels2.Location = 84D;
            c1GaugeLabels2.Location2 = 44D;
            c1GaugeLabels2.ScaleFrom = 0D;
            c1GaugeLabels2.ViewTag = ((long)(641344658725412619));
            c1GaugeSingleLabel3.Angle = -113D;
            c1GaugeSingleLabel3.Color = System.Drawing.Color.Snow;
            c1GaugeSingleLabel3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            c1GaugeSingleLabel3.FontSize = 10D;
            c1GaugeSingleLabel3.Location = 102D;
            c1GaugeSingleLabel3.Text = "Fuel";
            c1GaugeSingleLabel3.ViewTag = ((long)(688914168538589149));
            c1GaugeRange4.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange4.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.LowQuality;
            c1GaugeRange4.Border.Color = System.Drawing.Color.White;
            c1GaugeRange4.From = 60D;
            c1GaugeRange4.Location = 100D;
            c1GaugeRange4.Location2 = 106D;
            c1GaugeRange4.To = 80D;
            c1GaugeRange4.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeRange4.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LightCoral, 1D, ((long)(688069741589521705))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 2, System.Drawing.Color.Lavender, 1D, ((long)(688351217164156560)))});
            c1GaugeRange4.ViewTag = ((long)(687788264195372779));
            c1GaugeRange4.Width = 6D;
            c1GaugeRange4.Width2 = 14D;
            this.c1RadialGauge1.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange1,
            c1GaugeMarks1,
            c1GaugeRange2,
            c1GaugeRange3,
            c1GaugeMarks2,
            c1GaugeSingleLabel1,
            c1GaugeLabels1,
            c1GaugeSingleLabel2,
            c1GaugeLabels2,
            c1GaugeSingleLabel3,
            c1GaugeRange4});
            c1GaugeEllipse1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse1.CenterPointX = 0.44D;
            c1GaugeEllipse1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse1.Filling.Color = System.Drawing.Color.Lavender;
            c1GaugeEllipse1.Filling.Color2 = System.Drawing.Color.DarkBlue;
            c1GaugeEllipse1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse1.Height = -1.05D;
            c1GaugeEllipse1.RotateAngle = -32D;
            c1GaugeEllipse1.Width = -1.1D;
            this.c1RadialGauge1.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse1});
            this.c1RadialGauge1.Maximum = 186D;
            this.c1RadialGauge1.Minimum = -95D;
            c1GaugePointer1.Border.Color = System.Drawing.Color.DarkSlateBlue;
            c1GaugePointer1.Border.Thickness = 1D;
            c1GaugePointer1.CustomShape.EndWidth = 0D;
            c1GaugePointer1.CustomShape.StartAngle = -25D;
            c1GaugePointer1.CustomShape.StartWidth = 12D;
            c1GaugePointer1.Filling.Color = System.Drawing.Color.RoyalBlue;
            c1GaugePointer1.Length = 10D;
            c1GaugePointer1.Name = "mph";
            c1GaugePointer1.Offset = 80D;
            c1GaugePointer1.Offset2 = 20D;
            c1GaugePointer1.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer1.SweepTime = 10D;
            c1GaugePointer1.Value = 65D;
            c1GaugePointer1.ViewTag = ((long)(677092177610324687));
            c1GaugePointer2.Border.Color = System.Drawing.Color.DarkOliveGreen;
            c1GaugePointer2.Border.Thickness = 1D;
            c1GaugePointer2.CustomShape.EndWidth = 0D;
            c1GaugePointer2.CustomShape.StartAngle = -25D;
            c1GaugePointer2.CustomShape.StartWidth = 12D;
            c1GaugePointer2.Filling.Color = System.Drawing.Color.OliveDrab;
            c1GaugePointer2.Length = 10D;
            c1GaugePointer2.Name = "rpm";
            c1GaugePointer2.Offset = 80D;
            c1GaugePointer2.Offset2 = 20D;
            c1GaugePointer2.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer2.SweepTime = 7D;
            c1GaugePointer2.Value = 2500D;
            c1GaugePointer2.ValueFactor = 0.01D;
            c1GaugePointer2.ValueOffset = -90D;
            c1GaugePointer2.ViewTag = ((long)(682721708515102101));
            c1GaugePointer3.Name = "fuel";
            c1GaugePointer3.SweepTime = 30D;
            c1GaugePointer3.Value = 70D;
            c1GaugePointer3.ValueFactor = 0.2D;
            c1GaugePointer3.ValueOffset = 60D;
            c1GaugePointer3.ViewTag = ((long)(688632692472186167));
            c1GaugePointer3.Visible = false;
            this.c1RadialGauge1.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer1,
            c1GaugePointer2,
            c1GaugePointer3});
            this.c1RadialGauge1.Name = "c1RadialGauge1";
            this.c1RadialGauge1.Pointer.Visible = false;
            this.c1RadialGauge1.PointerOriginX = 0.56D;
            this.c1RadialGauge1.Radius = 0.45D;
            this.c1RadialGauge1.StartAngle = -76D;
            this.c1RadialGauge1.SweepAngle = 506D;
            this.c1RadialGauge1.Viewport.AspectPinX = 0.45D;
            this.c1RadialGauge1.Viewport.AspectPinY = 0.5D;
            this.c1RadialGauge1.Viewport.AspectRatio = 1D;
            this.c1RadialGauge1.ViewTag = ((long)(652884948141329328));
            // 
            // c1Gauge2
            // 
            this.c1Gauge2.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1RadialGauge2});
            this.c1Gauge2.Location = new System.Drawing.Point(390, 4);
            this.c1Gauge2.Name = "c1Gauge2";
            this.c1Gauge2.Size = new System.Drawing.Size(362, 351);
            this.c1Gauge2.TabIndex = 2;
            this.c1Gauge2.ViewTag = ((long)(644720729662777127));
            // 
            // c1RadialGauge2
            // 
            this.c1RadialGauge2.Cap.Visible = false;
            c1GaugeMarks3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks3.Border.Color = System.Drawing.Color.Blue;
            c1GaugeMarks3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks3.Filling.Color = System.Drawing.Color.RoyalBlue;
            c1GaugeMarks3.Interval = 5D;
            c1GaugeMarks3.Length = 6.5D;
            c1GaugeMarks3.Location = 75D;
            c1GaugeMarks3.ScaleFrom = -30D;
            c1GaugeMarks3.ScaleTo = 30D;
            c1GaugeMarks3.ViewTag = ((long)(643876304732645159));
            c1GaugeMarks3.Width = 0.6D;
            c1GaugeMarks4.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks4.Filling.Color = System.Drawing.Color.IndianRed;
            c1GaugeMarks4.Interval = 1D;
            c1GaugeMarks4.Length = 4D;
            c1GaugeMarks4.Location = 75D;
            c1GaugeMarks4.ScaleFrom = -30D;
            c1GaugeMarks4.ScaleTo = 30D;
            c1GaugeMarks4.ViewTag = ((long)(644157779709355815));
            c1GaugeMarks4.Width = 0.6D;
            c1GaugeLabels3.Color = System.Drawing.Color.MidnightBlue;
            c1GaugeLabels3.FontSize = 4D;
            c1GaugeLabels3.Interval = 5D;
            c1GaugeLabels3.IsRotated = true;
            c1GaugeLabels3.Location = 63D;
            c1GaugeLabels3.ScaleFrom = -30D;
            c1GaugeLabels3.ScaleTo = 30D;
            c1GaugeLabels3.TextAngle = 90D;
            c1GaugeLabels3.ViewTag = ((long)(644439254686066471));
            this.c1RadialGauge2.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks3,
            c1GaugeMarks4,
            c1GaugeLabels3});
            c1GaugeSegment1.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeSegment1.CenterPointX = 0.305D;
            c1GaugeSegment1.CornerRadius = 12D;
            c1GaugeSegment1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment1.Filling.Color = System.Drawing.Color.SlateGray;
            c1GaugeSegment1.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment1.Filling.HatchStyle = C1.Win.C1Gauge.C1GaugeHatchStyle.Vertical;
            c1GaugeSegment1.Filling.SwapColors = true;
            c1GaugeSegment1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeSegment1.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.SigmaBell;
            c1GaugeSegment1.InnerRadius = 100D;
            c1GaugeSegment1.OuterRadius = 50D;
            c1GaugeSegment1.StartAngle = -180D;
            c1GaugeSegment1.SweepAngle = 180D;
            this.c1RadialGauge2.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment1});
            this.c1RadialGauge2.Maximum = 15D;
            this.c1RadialGauge2.Minimum = -15D;
            this.c1RadialGauge2.Name = "c1RadialGauge2";
            this.c1RadialGauge2.Pointer.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Center;
            this.c1RadialGauge2.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.c1RadialGauge2.Pointer.CustomShape.EndRadius = 0.333333333333D;
            this.c1RadialGauge2.Pointer.CustomShape.EndWidth = 0.5D;
            this.c1RadialGauge2.Pointer.CustomShape.StartRadius = 0.5D;
            this.c1RadialGauge2.Pointer.Filling.Color = System.Drawing.Color.Red;
            this.c1RadialGauge2.Pointer.FlipShape = true;
            this.c1RadialGauge2.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Horizontal;
            this.c1RadialGauge2.Pointer.Length = 4D;
            this.c1RadialGauge2.Pointer.Offset = 80D;
            this.c1RadialGauge2.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge2.PointerOriginX = 2D;
            this.c1RadialGauge2.Radius = 2.2D;
            this.c1RadialGauge2.StartAngle = -120D;
            this.c1RadialGauge2.SweepAngle = 60D;
            this.c1RadialGauge2.Viewport.AspectPinX = 0.45D;
            this.c1RadialGauge2.Viewport.AspectRatio = 0.5D;
            this.c1RadialGauge2.ViewTag = ((long)(645002204639643784));
            this.c1RadialGauge2.ValueChanged += new System.EventHandler(this.c1RadialGauge2_ValueChanged);
            // 
            // trackBar2
            // 
            this.trackBar2.AutoSize = false;
            this.trackBar2.Location = new System.Drawing.Point(4, 308);
            this.trackBar2.Maximum = 180;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(382, 29);
            this.trackBar2.TabIndex = 4;
            this.trackBar2.TickFrequency = 50;
            this.trackBar2.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar2.Value = 65;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // trackBar1
            // 
            this.trackBar1.AutoSize = false;
            this.trackBar1.Location = new System.Drawing.Point(756, 4);
            this.trackBar1.Maximum = 120;
            this.trackBar1.Minimum = -120;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar1.Size = new System.Drawing.Size(27, 351);
            this.trackBar1.TabIndex = 5;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // c1Gauge3
            // 
            this.c1Gauge3.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1LinearGauge1});
            this.c1Gauge3.Location = new System.Drawing.Point(390, 359);
            this.c1Gauge3.Name = "c1Gauge3";
            this.c1Gauge3.Size = new System.Drawing.Size(393, 197);
            this.c1Gauge3.TabIndex = 6;
            this.c1Gauge3.ViewTag = ((long)(681884788892489119));
            // 
            // c1LinearGauge1
            // 
            this.c1LinearGauge1.BaseFactor = 0.9D;
            this.c1LinearGauge1.BaseOrigin = 0.05D;
            c1GaugeSingleLabel4.Color = System.Drawing.Color.Silver;
            c1GaugeSingleLabel4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            c1GaugeSingleLabel4.FontSize = 8D;
            c1GaugeSingleLabel4.Format = "p1";
            c1GaugeSingleLabel4.Location = 17D;
            c1GaugeSingleLabel4.PointerIndex = 100;
            c1GaugeSingleLabel4.Position = 0.8D;
            c1GaugeSingleLabel4.ViewTag = ((long)(646977542129652696));
            c1GaugeSingleMark1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark1.Length = 6D;
            c1GaugeSingleMark1.Location = 41.6087201833902D;
            c1GaugeSingleMark1.Position = 0.158721854536833D;
            c1GaugeSingleMark1.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark1.ShapeAngle = 73.4548542340931D;
            c1GaugeSingleMark1.Value = 0D;
            c1GaugeSingleMark1.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark1.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(635718615437660883))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(636000090414381540)))});
            c1GaugeSingleMark1.ViewTag = ((long)(635437140460920226));
            c1GaugeSingleMark1.Width = 2D;
            c1GaugeSingleMark2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark2.Length = 6.000042875D;
            c1GaugeSingleMark2.Location = 44.1073947488843D;
            c1GaugeSingleMark2.Position = 0.165696277394959D;
            c1GaugeSingleMark2.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark2.ShapeAngle = 65.6055966284335D;
            c1GaugeSingleMark2.Value = 0.01D;
            c1GaugeSingleMark2.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark2.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(636563040367822853))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(636844515344533509)))});
            c1GaugeSingleMark2.ViewTag = ((long)(636281565391112197));
            c1GaugeSingleMark2.Width = 2D;
            c1GaugeSingleMark3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark3.Length = 6.000343D;
            c1GaugeSingleMark3.Location = 46.4238055638608D;
            c1GaugeSingleMark3.Position = 0.175060708517585D;
            c1GaugeSingleMark3.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark3.ShapeAngle = 57.6168199372642D;
            c1GaugeSingleMark3.Value = 0.02D;
            c1GaugeSingleMark3.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark3.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(637407465297954821))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(637688940274665477)))});
            c1GaugeSingleMark3.ViewTag = ((long)(637125990321244165));
            c1GaugeSingleMark3.Width = 2D;
            c1GaugeSingleMark4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark4.Length = 6.001157625D;
            c1GaugeSingleMark4.Location = 48.5090895948331D;
            c1GaugeSingleMark4.Position = 0.186591292897558D;
            c1GaugeSingleMark4.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark4.ShapeAngle = 49.4457089260645D;
            c1GaugeSingleMark4.Value = 0.03D;
            c1GaugeSingleMark4.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark4.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(638251890228086789))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(638533365204797445)))});
            c1GaugeSingleMark4.ViewTag = ((long)(637970415251376133));
            c1GaugeSingleMark4.Width = 2D;
            c1GaugeSingleMark5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark5.Length = 6.002744D;
            c1GaugeSingleMark5.Location = 50.3206243013447D;
            c1GaugeSingleMark5.Position = 0.200023095023903D;
            c1GaugeSingleMark5.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark5.ShapeAngle = 41.0672973965101D;
            c1GaugeSingleMark5.Value = 0.04D;
            c1GaugeSingleMark5.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark5.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(639096315158218757))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(639377790134929413)))});
            c1GaugeSingleMark5.ViewTag = ((long)(638814840181508101));
            c1GaugeSingleMark5.Width = 2D;
            c1GaugeSingleMark6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark6.Length = 6.005359375D;
            c1GaugeSingleMark6.Location = 51.8226983674911D;
            c1GaugeSingleMark6.Position = 0.215057634054188D;
            c1GaugeSingleMark6.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark6.ShapeAngle = 32.4790071939558D;
            c1GaugeSingleMark6.Value = 0.05D;
            c1GaugeSingleMark6.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark6.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(639940740088350725))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(640222215065061381)))});
            c1GaugeSingleMark6.ViewTag = ((long)(639659265111640069));
            c1GaugeSingleMark6.Width = 2D;
            c1GaugeSingleMark7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark7.Length = 6.009261D;
            c1GaugeSingleMark7.Location = 52.9869875664037D;
            c1GaugeSingleMark7.Position = 0.231370743786552D;
            c1GaugeSingleMark7.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark7.ShapeAngle = 23.70409350769D;
            c1GaugeSingleMark7.Value = 0.06D;
            c1GaugeSingleMark7.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark7.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(640785165018482693))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(641066639995193349)))});
            c1GaugeSingleMark7.ViewTag = ((long)(640503690041772037));
            c1GaugeSingleMark7.Width = 2D;
            c1GaugeSingleMark8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark8.Length = 6.014706125D;
            c1GaugeSingleMark8.Location = 53.7928384385188D;
            c1GaugeSingleMark8.Position = 0.248620548838433D;
            c1GaugeSingleMark8.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark8.ShapeAngle = 14.7923325701059D;
            c1GaugeSingleMark8.Value = 0.07D;
            c1GaugeSingleMark8.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark8.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(641629589948614661))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(641911064925325317)))});
            c1GaugeSingleMark8.ViewTag = ((long)(641348114971904005));
            c1GaugeSingleMark8.Width = 2D;
            c1GaugeSingleMark9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark9.Length = 6.021952D;
            c1GaugeSingleMark9.Location = 54.2273669909866D;
            c1GaugeSingleMark9.Position = 0.266455363009384D;
            c1GaugeSingleMark9.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark9.ShapeAngle = 5.81645672399332D;
            c1GaugeSingleMark9.Value = 0.08D;
            c1GaugeSingleMark9.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark9.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(642474014878746629))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(642755489855457285)))});
            c1GaugeSingleMark9.ViewTag = ((long)(642192539902035973));
            c1GaugeSingleMark9.Width = 2D;
            c1GaugeSingleMark10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark10.Length = 6.031255875D;
            c1GaugeSingleMark10.Location = 54.285383537011D;
            c1GaugeSingleMark10.Position = 0.284521334026366D;
            c1GaugeSingleMark10.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark10.ShapeAngle = -3.13607343636312D;
            c1GaugeSingleMark10.Value = 0.09D;
            c1GaugeSingleMark10.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark10.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(643318439808878597))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(643599914785589253)))});
            c1GaugeSingleMark10.ViewTag = ((long)(643036964832167941));
            c1GaugeSingleMark10.Width = 2D;
            c1GaugeSingleMark11.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark11.Length = 6.042875D;
            c1GaugeSingleMark11.Location = 53.9691580483551D;
            c1GaugeSingleMark11.Position = 0.302469679864905D;
            c1GaugeSingleMark11.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark11.ShapeAngle = -11.9746279385873D;
            c1GaugeSingleMark11.Value = 0.1D;
            c1GaugeSingleMark11.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark11.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(644162864739010565))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(644444339715721221)))});
            c1GaugeSingleMark11.ViewTag = ((long)(643881389762299909));
            c1GaugeSingleMark11.Width = 2D;
            c1GaugeSingleMark12.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark12.Length = 6.057066625D;
            c1GaugeSingleMark12.Location = 53.288042973243D;
            c1GaugeSingleMark12.Position = 0.319963384752562D;
            c1GaugeSingleMark12.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark12.ShapeAngle = -20.6174785219914D;
            c1GaugeSingleMark12.Value = 0.11D;
            c1GaugeSingleMark12.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark12.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(645007289669142533))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(645288764645853189)))});
            c1GaugeSingleMark12.ViewTag = ((long)(644725814692431877));
            c1GaugeSingleMark12.Width = 2D;
            c1GaugeSingleMark13.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark13.Length = 6.074088D;
            c1GaugeSingleMark13.Location = 52.2579723781163D;
            c1GaugeSingleMark13.Position = 0.33668324698017D;
            c1GaugeSingleMark13.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark13.ShapeAngle = -29.0013041218357D;
            c1GaugeSingleMark13.Value = 0.12D;
            c1GaugeSingleMark13.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark13.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(645851714599274501))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(646133189575985157)))});
            c1GaugeSingleMark13.ViewTag = ((long)(645570239622563845));
            c1GaugeSingleMark13.Width = 2D;
            c1GaugeSingleMark14.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark14.Length = 6.094196375D;
            c1GaugeSingleMark14.Location = 50.9008575262644D;
            c1GaugeSingleMark14.Position = 0.352333195021586D;
            c1GaugeSingleMark14.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark14.ShapeAngle = -37.0862038154472D;
            c1GaugeSingleMark14.Value = 0.13D;
            c1GaugeSingleMark14.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark14.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(646696139529406469))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(646977614506117125)))});
            c1GaugeSingleMark14.ViewTag = ((long)(646414664552695813));
            c1GaugeSingleMark14.Width = 2D;
            c1GaugeSingleMark15.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark15.Length = 6.117649D;
            c1GaugeSingleMark15.Location = 49.2438996459332D;
            c1GaugeSingleMark15.Position = 0.366644812520879D;
            c1GaugeSingleMark15.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark15.ShapeAngle = -44.8560711035632D;
            c1GaugeSingleMark15.Value = 0.14D;
            c1GaugeSingleMark15.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark15.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(647540564459538437))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(647822039436249093)))});
            c1GaugeSingleMark15.ViewTag = ((long)(647259089482827781));
            c1GaugeSingleMark15.Width = 2D;
            c1GaugeSingleMark16.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark16.Length = 6.144703125D;
            c1GaugeSingleMark16.Location = 47.3188407143763D;
            c1GaugeSingleMark16.Position = 0.379381035860188D;
            c1GaugeSingleMark16.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark16.ShapeAngle = -52.3155642577446D;
            c1GaugeSingleMark16.Value = 0.15D;
            c1GaugeSingleMark16.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark16.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(648384989389670405))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(648666464366381061)))});
            c1GaugeSingleMark16.ViewTag = ((long)(648103514412959749));
            c1GaugeSingleMark16.Width = 2D;
            c1GaugeSingleMark17.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark17.Length = 6.175616D;
            c1GaugeSingleMark17.Location = 45.1611726513141D;
            c1GaugeSingleMark17.Position = 0.390339009777686D;
            c1GaugeSingleMark17.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark17.ShapeAngle = -59.4853864657846D;
            c1GaugeSingleMark17.Value = 0.16D;
            c1GaugeSingleMark17.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark17.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(649229414319802373))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(649510889296513029)))});
            c1GaugeSingleMark17.ViewTag = ((long)(648947939343091717));
            c1GaugeSingleMark17.Width = 2D;
            c1GaugeSingleMark18.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark18.Length = 6.210644875D;
            c1GaugeSingleMark18.Location = 42.8093244410169D;
            c1GaugeSingleMark18.Position = 0.399352106464004D;
            c1GaugeSingleMark18.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark18.ShapeAngle = -66.3973225501899D;
            c1GaugeSingleMark18.Value = 0.17D;
            c1GaugeSingleMark18.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark18.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(650073839249934341))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(650355314226644997)))});
            c1GaugeSingleMark18.ViewTag = ((long)(649792364273223685));
            c1GaugeSingleMark18.Width = 2D;
            c1GaugeSingleMark19.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark19.Length = 6.250047D;
            c1GaugeSingleMark19.Location = 40.3038454564017D;
            c1GaugeSingleMark19.Position = 0.406291131422315D;
            c1GaugeSingleMark19.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark19.ShapeAngle = -73.0899026919472D;
            c1GaugeSingleMark19.Value = 0.18D;
            c1GaugeSingleMark19.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark19.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(650918264180066309))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(651199739156776965)))});
            c1GaugeSingleMark19.ViewTag = ((long)(650636789203355653));
            c1GaugeSingleMark19.Width = 2D;
            c1GaugeSingleMark20.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark20.Length = 6.294079625D;
            c1GaugeSingleMark20.Location = 37.6866017123853D;
            c1GaugeSingleMark20.Position = 0.41106475491842D;
            c1GaugeSingleMark20.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark20.ShapeAngle = -79.6050267508373D;
            c1GaugeSingleMark20.Value = 0.19D;
            c1GaugeSingleMark20.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark20.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(651762689110198277))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(652044164086908933)))});
            c1GaugeSingleMark20.ViewTag = ((long)(651481214133487621));
            c1GaugeSingleMark20.Width = 2D;
            c1GaugeSingleMark21.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark21.Length = 6.343D;
            c1GaugeSingleMark21.Location = 35D;
            c1GaugeSingleMark21.Position = 0.413619220944516D;
            c1GaugeSingleMark21.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark21.ShapeAngle = -85.9855295526921D;
            c1GaugeSingleMark21.Value = 0.2D;
            c1GaugeSingleMark21.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark21.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(652607114040330245))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(652888589017040901)))});
            c1GaugeSingleMark21.ViewTag = ((long)(652325639063619589));
            c1GaugeSingleMark21.Width = 2D;
            c1GaugeSingleMark22.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark22.Length = 6.397065375D;
            c1GaugeSingleMark22.Location = 32.2862529157103D;
            c1GaugeSingleMark22.Position = 0.413937396223899D;
            c1GaugeSingleMark22.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark22.ShapeAngle = 267.726504886932D;
            c1GaugeSingleMark22.Value = 0.21D;
            c1GaugeSingleMark22.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark22.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(653451538970462213))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(653733013947172869)))});
            c1GaugeSingleMark22.ViewTag = ((long)(653170063993751557));
            c1GaugeSingleMark22.Width = 2D;
            c1GaugeSingleMark23.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark23.Length = 6.456533D;
            c1GaugeSingleMark23.Location = 29.5866957663009D;
            c1GaugeSingleMark23.Position = 0.412037229913632D;
            c1GaugeSingleMark23.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark23.ShapeAngle = 261.490922385584D;
            c1GaugeSingleMark23.Value = 0.22D;
            c1GaugeSingleMark23.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark23.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(654295963900594181))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(654577438877304837)))});
            c1GaugeSingleMark23.ViewTag = ((long)(654014488923883525));
            c1GaugeSingleMark23.Width = 2D;
            c1GaugeSingleMark24.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark24.Length = 6.521660125D;
            c1GaugeSingleMark24.Location = 26.9411642577315D;
            c1GaugeSingleMark24.Position = 0.40796970039829D;
            c1GaugeSingleMark24.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark24.ShapeAngle = 255.2703986107D;
            c1GaugeSingleMark24.Value = 0.23D;
            c1GaugeSingleMark24.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark24.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(655140388830726149))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(655421863807436805)))});
            c1GaugeSingleMark24.ViewTag = ((long)(654858913854015493));
            c1GaugeSingleMark24.Width = 2D;
            c1GaugeSingleMark25.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark25.Length = 6.592704D;
            c1GaugeSingleMark25.Location = 24.387439819481D;
            c1GaugeSingleMark25.Position = 0.401816329041008D;
            c1GaugeSingleMark25.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark25.ShapeAngle = 249.031246111008D;
            c1GaugeSingleMark25.Value = 0.24D;
            c1GaugeSingleMark25.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark25.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(655984813760858117))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(656266288737568773)))});
            c1GaugeSingleMark25.ViewTag = ((long)(655703338784147461));
            c1GaugeSingleMark25.Width = 2D;
            c1GaugeSingleMark26.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark26.Length = 6.669921875D;
            c1GaugeSingleMark26.Location = 21.960767420401D;
            c1GaugeSingleMark26.Position = 0.393686342139534D;
            c1GaugeSingleMark26.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark26.ShapeAngle = 242.744262666153D;
            c1GaugeSingleMark26.Value = 0.25D;
            c1GaugeSingleMark26.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark26.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(656829238690990085))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(657110713667700741)))});
            c1GaugeSingleMark26.ViewTag = ((long)(656547763714279429));
            c1GaugeSingleMark26.Width = 2D;
            c1GaugeSingleMark27.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark27.Length = 6.753571D;
            c1GaugeSingleMark27.Location = 19.6934488371496D;
            c1GaugeSingleMark27.Position = 0.383713561826983D;
            c1GaugeSingleMark27.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark27.ShapeAngle = 236.385697456364D;
            c1GaugeSingleMark27.Value = 0.26D;
            c1GaugeSingleMark27.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark27.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(657673663621122053))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(657955138597832709)))});
            c1GaugeSingleMark27.ViewTag = ((long)(657392188644411397));
            c1GaugeSingleMark27.Width = 2D;
            c1GaugeSingleMark28.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark28.Length = 6.843908625D;
            c1GaugeSingleMark28.Location = 17.6145125738944D;
            c1GaugeSingleMark28.Position = 0.372053104483537D;
            c1GaugeSingleMark28.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark28.ShapeAngle = 229.938345178363D;
            c1GaugeSingleMark28.Value = 0.27D;
            c1GaugeSingleMark28.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark28.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(658518088551254021))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(658799563527964677)))});
            c1GaugeSingleMark28.ViewTag = ((long)(658236613574543365));
            c1GaugeSingleMark28.Width = 2D;
            c1GaugeSingleMark29.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark29.Length = 6.941192D;
            c1GaugeSingleMark29.Location = 15.7494600270641D;
            c1GaugeSingleMark29.Position = 0.358877961623424D;
            c1GaugeSingleMark29.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark29.ShapeAngle = 223.392700770929D;
            c1GaugeSingleMark29.Value = 0.28D;
            c1GaugeSingleMark29.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark29.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(659362513481385989))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(659643988458096645)))});
            c1GaugeSingleMark29.ViewTag = ((long)(659081038504675333));
            c1GaugeSingleMark29.Width = 2D;
            c1GaugeSingleMark30.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark30.Length = 7.045678375D;
            c1GaugeSingleMark30.Location = 14.1200860596227D;
            c1GaugeSingleMark30.Position = 0.344375533433613D;
            c1GaugeSingleMark30.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark30.ShapeAngle = 216.748022428356D;
            c1GaugeSingleMark30.Value = 0.29D;
            c1GaugeSingleMark30.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark30.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(660206938411517957))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(660488413388228613)))});
            c1GaugeSingleMark30.ViewTag = ((long)(659925463434807301));
            c1GaugeSingleMark30.Width = 2D;
            c1GaugeSingleMark31.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark31.Length = 7.157625D;
            c1GaugeSingleMark31.Location = 12.7443709073666D;
            c1GaugeSingleMark31.Position = 0.328744179407913D;
            c1GaugeSingleMark31.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark31.ShapeAngle = 210.013072925863D;
            c1GaugeSingleMark31.Value = 0.3D;
            c1GaugeSingleMark31.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark31.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(661051363341649925))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(661332838318360581)))});
            c1GaugeSingleMark31.ViewTag = ((long)(660769888364939269));
            c1GaugeSingleMark31.Width = 2D;
            c1GaugeSingleMark32.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark32.Length = 7.277289125D;
            c1GaugeSingleMark32.Location = 11.6364392910083D;
            c1GaugeSingleMark32.Position = 0.312189844076141D;
            c1GaugeSingleMark32.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark32.ShapeAngle = 203.206266610729D;
            c1GaugeSingleMark32.Value = 0.31D;
            c1GaugeSingleMark32.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark32.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(661895788271781893))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(662177263248492549)))});
            c1GaugeSingleMark32.ViewTag = ((long)(661614313295071237));
            c1GaugeSingleMark32.Width = 2D;
            c1GaugeSingleMark33.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark33.Length = 7.404928D;
            c1GaugeSingleMark33.Location = 10.8065817529731D;
            c1GaugeSingleMark33.Position = 0.29492280889458D;
            c1GaugeSingleMark33.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark33.ShapeAngle = 196.354975554559D;
            c1GaugeSingleMark33.Value = 0.32D;
            c1GaugeSingleMark33.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark33.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(662740213201913861))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(663021688178624517)))});
            c1GaugeSingleMark33.ViewTag = ((long)(662458738225203205));
            c1GaugeSingleMark33.Width = 2D;
            c1GaugeSingleMark34.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark34.Length = 7.540798875D;
            c1GaugeSingleMark34.Location = 10.2613325730222D;
            c1GaugeSingleMark34.Position = 0.277154614146466D;
            c1GaugeSingleMark34.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark34.ShapeAngle = 189.49386626154D;
            c1GaugeSingleMark34.Value = 0.33D;
            c1GaugeSingleMark34.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark34.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(663584638132045829))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(663866113108756485)))});
            c1GaugeSingleMark34.ViewTag = ((long)(663303163155335173));
            c1GaugeSingleMark34.Width = 2D;
            c1GaugeSingleMark35.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark35.Length = 7.685159D;
            c1GaugeSingleMark35.Location = 10.0035981342564D;
            c1GaugeSingleMark35.Position = 0.259095187386577D;
            c1GaugeSingleMark35.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark35.ShapeAngle = 182.662338078845D;
            c1GaugeSingleMark35.Value = 0.34D;
            c1GaugeSingleMark35.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark35.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(664429063062177797))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(664710538038888453)))});
            c1GaugeSingleMark35.ViewTag = ((long)(664147588085467141));
            c1GaugeSingleMark35.Width = 2D;
            c1GaugeSingleMark36.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark36.Length = 7.838265625D;
            c1GaugeSingleMark36.Location = 10.0328292998484D;
            c1GaugeSingleMark36.Position = 0.240950207717858D;
            c1GaugeSingleMark36.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark36.ShapeAngle = 175.90136173986D;
            c1GaugeSingleMark36.Value = 0.35D;
            c1GaugeSingleMark36.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark36.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(665273487992309765))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(665554962969020421)))});
            c1GaugeSingleMark36.ViewTag = ((long)(664992013015599109));
            c1GaugeSingleMark36.Width = 2D;
            c1GaugeSingleMark37.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark37.Length = 8.000376D;
            c1GaugeSingleMark37.Location = 10.3452312075672D;
            c1GaugeSingleMark37.Position = 0.222918728153962D;
            c1GaugeSingleMark37.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark37.ShapeAngle = 169.250187466309D;
            c1GaugeSingleMark37.Value = 0.36D;
            c1GaugeSingleMark37.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark37.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(666117912922441733))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(666399387899152389)))});
            c1GaugeSingleMark37.ViewTag = ((long)(665836437945731077));
            c1GaugeSingleMark37.Width = 2D;
            c1GaugeSingleMark38.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark38.Length = 8.171747375D;
            c1GaugeSingleMark38.Location = 10.9340038785624D;
            c1GaugeSingleMark38.Position = 0.205191071620592D;
            c1GaugeSingleMark38.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark38.ShapeAngle = 162.743434319925D;
            c1GaugeSingleMark38.Value = 0.37D;
            c1GaugeSingleMark38.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark38.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(666962337852573701))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(667243812829284357)))});
            c1GaugeSingleMark38.ViewTag = ((long)(666680862875863045));
            c1GaugeSingleMark38.Width = 2D;
            c1GaugeSingleMark39.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark39.Length = 8.352637D;
            c1GaugeSingleMark39.Location = 11.789607152473D;
            c1GaugeSingleMark39.Position = 0.187947009879168D;
            c1GaugeSingleMark39.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark39.ShapeAngle = 156.408967140566D;
            c1GaugeSingleMark39.Value = 0.38D;
            c1GaugeSingleMark39.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark39.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(667806762782705669))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(668088237759416325)))});
            c1GaugeSingleMark39.ViewTag = ((long)(667525287805995013));
            c1GaugeSingleMark39.Width = 2D;
            c1GaugeSingleMark40.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark40.Length = 8.543302125D;
            c1GaugeSingleMark40.Location = 12.900043685544D;
            c1GaugeSingleMark40.Position = 0.171354228895106D;
            c1GaugeSingleMark40.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark40.ShapeAngle = 150.266760724146D;
            c1GaugeSingleMark40.Value = 0.39D;
            c1GaugeSingleMark40.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark40.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(668651187712837637))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(668932662689548293)))});
            c1GaugeSingleMark40.ViewTag = ((long)(668369712736126981));
            c1GaugeSingleMark40.Width = 2D;
            c1GaugeSingleMark41.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark41.Length = 8.744D;
            c1GaugeSingleMark41.Location = 14.2511540647079D;
            c1GaugeSingleMark41.Position = 0.155567078976185D;
            c1GaugeSingleMark41.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark41.ShapeAngle = 144.328726099568D;
            c1GaugeSingleMark41.Value = 0.4D;
            c1GaugeSingleMark41.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark41.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(669495612642969605))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(669777087619680261)))});
            c1GaugeSingleMark41.ViewTag = ((long)(669214137666258949));
            c1GaugeSingleMark41.Width = 2D;
            c1GaugeSingleMark42.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark42.Length = 8.954987875D;
            c1GaugeSingleMark42.Location = 15.8269184813742D;
            c1GaugeSingleMark42.Position = 0.140725603410723D;
            c1GaugeSingleMark42.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark42.ShapeAngle = 138.599305173617D;
            c1GaugeSingleMark42.Value = 0.41D;
            c1GaugeSingleMark42.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark42.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(670340037573101573))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(670621512549812229)))});
            c1GaugeSingleMark42.ViewTag = ((long)(670058562596390917));
            c1GaugeSingleMark42.Width = 2D;
            c1GaugeSingleMark43.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark43.Length = 9.176523D;
            c1GaugeSingleMark43.Location = 17.6097598574154D;
            c1GaugeSingleMark43.Position = 0.126954835360162D;
            c1GaugeSingleMark43.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark43.ShapeAngle = 133.076561895991D;
            c1GaugeSingleMark43.Value = 0.42D;
            c1GaugeSingleMark43.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark43.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(671184462503233541))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(671465937479944197)))});
            c1GaugeSingleMark43.ViewTag = ((long)(670902987526522885));
            c1GaugeSingleMark43.Width = 2D;
            c1GaugeSingleMark44.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark44.Length = 9.408862625D;
            c1GaugeSingleMark44.Location = 19.5808438068762D;
            c1GaugeSingleMark44.Position = 0.11436434941005D;
            c1GaugeSingleMark44.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark44.ShapeAngle = 127.753502747013D;
            c1GaugeSingleMark44.Value = 0.43D;
            c1GaugeSingleMark44.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark44.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(672028887433365509))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(672310362410076165)))});
            c1GaugeSingleMark44.ViewTag = ((long)(671747412456654853));
            c1GaugeSingleMark44.Width = 2D;
            c1GaugeSingleMark45.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark45.Length = 9.652264D;
            c1GaugeSingleMark45.Location = 21.7203713357075D;
            c1GaugeSingleMark45.Position = 0.103048051447613D;
            c1GaugeSingleMark45.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark45.ShapeAngle = 122.619415474653D;
            c1GaugeSingleMark45.Value = 0.44D;
            c1GaugeSingleMark45.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark45.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(672873312363497477))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(673154787340208133)))});
            c1GaugeSingleMark45.ViewTag = ((long)(672591837386786821));
            c1GaugeSingleMark45.Width = 2D;
            c1GaugeSingleMark46.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark46.Length = 9.906984375D;
            c1GaugeSingleMark46.Location = 24.0078607150705D;
            c1GaugeSingleMark46.Position = 0.0930841883921942D;
            c1GaugeSingleMark46.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark46.ShapeAngle = 117.661088818805D;
            c1GaugeSingleMark46.Value = 0.45D;
            c1GaugeSingleMark46.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark46.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(673717737293629445))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(673999212270340101)))});
            c1GaugeSingleMark46.ViewTag = ((long)(673436262316918789));
            c1GaugeSingleMark46.Width = 2D;
            c1GaugeSingleMark47.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark47.Length = 10.173281D;
            c1GaugeSingleMark47.Location = 26.4224154996084D;
            c1GaugeSingleMark47.Position = 0.084535557726108D;
            c1GaugeSingleMark47.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark47.ShapeAngle = 112.863843676203D;
            c1GaugeSingleMark47.Value = 0.46D;
            c1GaugeSingleMark47.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark47.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(674562162223761413))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(674843637200472069)))});
            c1GaugeSingleMark47.ViewTag = ((long)(674280687247050757));
            c1GaugeSingleMark47.Width = 2D;
            c1GaugeSingleMark48.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark48.Length = 10.451411125D;
            c1GaugeSingleMark48.Location = 28.9429761901529D;
            c1GaugeSingleMark48.Position = 0.0774498957200123D;
            c1GaugeSingleMark48.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark48.ShapeAngle = 108.212356630483D;
            c1GaugeSingleMark48.Value = 0.47D;
            c1GaugeSingleMark48.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark48.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(675406587153893381))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(675688062130604037)))});
            c1GaugeSingleMark48.ViewTag = ((long)(675125112177182725));
            c1GaugeSingleMark48.Width = 2D;
            c1GaugeSingleMark49.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark49.Length = 10.741632D;
            c1GaugeSingleMark49.Location = 31.5485535517241D;
            c1GaugeSingleMark49.Position = 0.0718604226750361D;
            c1GaugeSingleMark49.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark49.ShapeAngle = 103.691288333686D;
            c1GaugeSingleMark49.Value = 0.48D;
            c1GaugeSingleMark49.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark49.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(676251012084025349))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(676532487060736005)))});
            c1GaugeSingleMark49.ViewTag = ((long)(675969537107314693));
            c1GaugeSingleMark49.Width = 2D;
            c1GaugeSingleMark50.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark50.Length = 11.044200875D;
            c1GaugeSingleMark50.Location = 34.2184420849912D;
            c1GaugeSingleMark50.Position = 0.0677865233659965D;
            c1GaugeSingleMark50.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark50.ShapeAngle = 99.2857452014823D;
            c1GaugeSingleMark50.Value = 0.49D;
            c1GaugeSingleMark50.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark50.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(677095437014157317))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(677376911990867973)))});
            c1GaugeSingleMark50.ViewTag = ((long)(676813962037446661));
            c1GaugeSingleMark50.Width = 2D;
            c1GaugeSingleMark51.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark51.Length = 11.359375D;
            c1GaugeSingleMark51.Location = 36.9324126066075D;
            c1GaugeSingleMark51.Position = 0.0652345411161826D;
            c1GaugeSingleMark51.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark51.ShapeAngle = 94.981608075312D;
            c1GaugeSingleMark51.Value = 0.5D;
            c1GaugeSingleMark51.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark51.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(677939861944289285))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(678221336920999941)))});
            c1GaugeSingleMark51.ViewTag = ((long)(677658386967578629));
            c1GaugeSingleMark51.Width = 2D;
            c1GaugeSingleMark52.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark52.Length = 11.687411625D;
            c1GaugeSingleMark52.Location = 39.6708833164169D;
            c1GaugeSingleMark52.Position = 0.0641986645133985D;
            c1GaugeSingleMark52.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark52.ShapeAngle = 90.7657602690671D;
            c1GaugeSingleMark52.Value = 0.51D;
            c1GaugeSingleMark52.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark52.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(678784286874421253))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(679065761851131909)))});
            c1GaugeSingleMark52.ViewTag = ((long)(678502811897710597));
            c1GaugeSingleMark52.Width = 2D;
            c1GaugeSingleMark53.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark53.Length = 12.028568D;
            c1GaugeSingleMark53.Location = 42.4150691141177D;
            c1GaugeSingleMark53.Position = 0.0646618866385424D;
            c1GaugeSingleMark53.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark53.ShapeAngle = 86.6262429688913D;
            c1GaugeSingleMark53.Value = 0.52D;
            c1GaugeSingleMark53.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark53.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(679628711804553221))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(679910186781263877)))});
            c1GaugeSingleMark53.ViewTag = ((long)(679347236827842565));
            c1GaugeSingleMark53.Width = 2D;
            c1GaugeSingleMark54.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark54.Length = 12.383101375D;
            c1GaugeSingleMark54.Location = 45.1471092723888D;
            c1GaugeSingleMark54.Position = 0.0665970177725009D;
            c1GaugeSingleMark54.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark54.ShapeAngle = 82.5523603427334D;
            c1GaugeSingleMark54.Value = 0.53D;
            c1GaugeSingleMark54.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark54.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(680473136734685189))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(680754611711395845)))});
            c1GaugeSingleMark54.ViewTag = ((long)(680191661757974533));
            c1GaugeSingleMark54.Width = 2D;
            c1GaugeSingleMark55.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark55.Length = 12.751269D;
            c1GaugeSingleMark55.Location = 47.8501738766438D;
            c1GaugeSingleMark55.Position = 0.0699677338272114D;
            c1GaugeSingleMark55.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark55.ShapeAngle = 78.5347510910702D;
            c1GaugeSingleMark55.Value = 0.54D;
            c1GaugeSingleMark55.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark55.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(681317561664817157))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(681599036641527813)))});
            c1GaugeSingleMark55.ViewTag = ((long)(681036086688106501));
            c1GaugeSingleMark55.Width = 2D;
            c1GaugeSingleMark56.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark56.Length = 13.133328125D;
            c1GaugeSingleMark56.Location = 50.5085497032651D;
            c1GaugeSingleMark56.Position = 0.0747296441678812D;
            c1GaugeSingleMark56.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark56.ShapeAngle = 74.5654380830066D;
            c1GaugeSingleMark56.Value = 0.55D;
            c1GaugeSingleMark56.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark56.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(682161986594949125))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(682443461571659781)))});
            c1GaugeSingleMark56.ViewTag = ((long)(681880511618238469));
            c1GaugeSingleMark56.Width = 2D;
            c1GaugeSingleMark57.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark57.Length = 13.529536D;
            c1GaugeSingleMark57.Location = 53.1077064290264D;
            c1GaugeSingleMark57.Position = 0.0808313640143305D;
            c1GaugeSingleMark57.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark57.ShapeAngle = 70.6378633711394D;
            c1GaugeSingleMark57.Value = 0.56D;
            c1GaugeSingleMark57.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark57.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(683006411525081093))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(683287886501791749)))});
            c1GaugeSingleMark57.ViewTag = ((long)(682724936548370437));
            c1GaugeSingleMark57.Width = 2D;
            c1GaugeSingleMark58.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark58.Length = 13.940149875D;
            c1GaugeSingleMark58.Location = 55.6343442457209D;
            c1GaugeSingleMark58.Position = 0.0882155781927946D;
            c1GaugeSingleMark58.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark58.ShapeAngle = 66.7469122961359D;
            c1GaugeSingleMark58.Value = 0.57D;
            c1GaugeSingleMark58.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark58.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(683850836455213061))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(684132311431923717)))});
            c1GaugeSingleMark58.ViewTag = ((long)(683569361478502405));
            c1GaugeSingleMark58.Width = 2D;
            c1GaugeSingleMark59.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark59.Length = 14.365427D;
            c1GaugeSingleMark59.Location = 58.0764240976301D;
            c1GaugeSingleMark59.Position = 0.096820084621765D;
            c1GaugeSingleMark59.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark59.ShapeAngle = 62.8889275393906D;
            c1GaugeSingleMark59.Value = 0.58D;
            c1GaugeSingleMark59.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark59.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(684695261385345029))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(684976736362055685)))});
            c1GaugeSingleMark59.ViewTag = ((long)(684413786408634373));
            c1GaugeSingleMark59.Width = 2D;
            c1GaugeSingleMark60.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark60.Length = 14.805624625D;
            c1GaugeSingleMark60.Location = 60.4231818676951D;
            c1GaugeSingleMark60.Position = 0.106578807527181D;
            c1GaugeSingleMark60.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark60.ShapeAngle = 59.0617118247612D;
            c1GaugeSingleMark60.Value = 0.59D;
            c1GaugeSingleMark60.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark60.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(685539686315476997))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(685821161292187653)))});
            c1GaugeSingleMark60.ViewTag = ((long)(685258211338766341));
            c1GaugeSingleMark60.Width = 2D;
            c1GaugeSingleMark61.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark61.Length = 15.261D;
            c1GaugeSingleMark61.Location = 62.6651279137228D;
            c1GaugeSingleMark61.Position = 0.117422771968247D;
            c1GaugeSingleMark61.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark61.ShapeAngle = 55.2645164880132D;
            c1GaugeSingleMark61.Value = 0.6D;
            c1GaugeSingleMark61.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark61.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(686384111245608965))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(686665586222319621)))});
            c1GaugeSingleMark61.ViewTag = ((long)(686102636268898309));
            c1GaugeSingleMark61.Width = 2D;
            c1GaugeSingleMark62.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark62.Length = 15.731810375D;
            c1GaugeSingleMark62.Location = 64.7940334015418D;
            c1GaugeSingleMark62.Position = 0.129281032794223D;
            c1GaugeSingleMark62.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark62.ShapeAngle = 51.4980123372281D;
            c1GaugeSingleMark62.Value = 0.61D;
            c1GaugeSingleMark62.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark62.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(687228536175740933))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(687510011152451589)))});
            c1GaugeSingleMark62.ViewTag = ((long)(686947061199030277));
            c1GaugeSingleMark62.Width = 2D;
            c1GaugeSingleMark63.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark63.Length = 16.218313D;
            c1GaugeSingleMark63.Location = 66.80290490074D;
            c1GaugeSingleMark63.Position = 0.142081552627492D;
            c1GaugeSingleMark63.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark63.ShapeAngle = 47.7642391286685D;
            c1GaugeSingleMark63.Value = 0.62D;
            c1GaugeSingleMark63.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark63.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(688072961105872901))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(688354436082583557)))});
            c1GaugeSingleMark63.ViewTag = ((long)(687791486129162245));
            c1GaugeSingleMark63.Width = 2D;
            c1GaugeSingleMark64.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark64.Length = 16.720765125D;
            c1GaugeSingleMark64.Location = 68.6859487035632D;
            c1GaugeSingleMark64.Position = 0.155752024865767D;
            c1GaugeSingleMark64.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark64.ShapeAngle = 44.0665305829187D;
            c1GaugeSingleMark64.Value = 0.63D;
            c1GaugeSingleMark64.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark64.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(688917386036004869))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(689198861012715525)))});
            c1GaugeSingleMark64.ViewTag = ((long)(688635911059294213));
            c1GaugeSingleMark64.Width = 2D;
            c1GaugeSingleMark65.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark65.Length = 17.239424D;
            c1GaugeSingleMark65.Location = 70.438526301816D;
            c1GaugeSingleMark65.Position = 0.170220639006658D;
            c1GaugeSingleMark65.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark65.ShapeAngle = 40.4094131172647D;
            c1GaugeSingleMark65.Value = 0.64D;
            c1GaugeSingleMark65.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark65.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(689761810966136837))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(690043285942847493)))});
            c1GaugeSingleMark65.ViewTag = ((long)(689480335989426181));
            c1GaugeSingleMark65.Width = 2D;
            c1GaugeSingleMark66.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark66.Length = 17.774546875D;
            c1GaugeSingleMark66.Location = 72.0571024132249D;
            c1GaugeSingleMark66.Position = 0.185416786814587D;
            c1GaugeSingleMark66.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark66.ShapeAngle = 36.7984782598093D;
            c1GaugeSingleMark66.Value = 0.65D;
            c1GaugeSingleMark66.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark66.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(690606235896268805))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(690887710872979461)))});
            c1GaugeSingleMark66.ViewTag = ((long)(690324760919558149));
            c1GaugeSingleMark66.Width = 2D;
            c1GaugeSingleMark67.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark67.Length = 18.326391D;
            c1GaugeSingleMark67.Location = 73.5391868906333D;
            c1GaugeSingleMark67.Position = 0.201271708970017D;
            c1GaugeSingleMark67.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark67.ShapeAngle = 33.2402308472618D;
            c1GaugeSingleMark67.Value = 0.66D;
            c1GaugeSingleMark67.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark67.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(691450660826400773))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(691732135803111429)))});
            c1GaugeSingleMark67.ViewTag = ((long)(691169185849690117));
            c1GaugeSingleMark67.Width = 2D;
            c1GaugeSingleMark68.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark68.Length = 18.895213625D;
            c1GaugeSingleMark68.Location = 74.883271777371D;
            c1GaugeSingleMark68.Position = 0.217719082863759D;
            c1GaugeSingleMark68.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark68.ShapeAngle = 29.7419173328744D;
            c1GaugeSingleMark68.Value = 0.67D;
            c1GaugeSingleMark68.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark68.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(692295085756532741))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(692576560733243397)))});
            c1GaugeSingleMark68.ViewTag = ((long)(692013610779822085));
            c1GaugeSingleMark68.Width = 2D;
            c1GaugeSingleMark69.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark69.Length = 19.481272D;
            c1GaugeSingleMark69.Location = 76.0887646928108D;
            c1GaugeSingleMark69.Position = 0.234695553126978D;
            c1GaugeSingleMark69.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark69.ShapeAngle = 26.3113405452214D;
            c1GaugeSingleMark69.Value = 0.68D;
            c1GaugeSingleMark69.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark69.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(693139510686664709))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(693420985663375365)))});
            c1GaugeSingleMark69.ViewTag = ((long)(692858035709954053));
            c1GaugeSingleMark69.Width = 2D;
            c1GaugeSingleMark70.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark70.Length = 20.084823375D;
            c1GaugeSingleMark70.Location = 77.1559196458795D;
            c1GaugeSingleMark70.Position = 0.252141207325302D;
            c1GaugeSingleMark70.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark70.ShapeAngle = 22.9566687480804D;
            c1GaugeSingleMark70.Value = 0.69D;
            c1GaugeSingleMark70.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark70.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(693983935616796677))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(694265410593507333)))});
            c1GaugeSingleMark70.ViewTag = ((long)(693702460640086021));
            c1GaugeSingleMark70.Width = 2D;
            c1GaugeSingleMark71.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark71.Length = 20.706125D;
            c1GaugeSingleMark71.Location = 78.0857662833547D;
            c1GaugeSingleMark71.Position = 0.27D;
            c1GaugeSingleMark71.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark71.ShapeAngle = 19.6862476278143D;
            c1GaugeSingleMark71.Value = 0.7D;
            c1GaugeSingleMark71.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark71.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(694828360546928645))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(695109835523639301)))});
            c1GaugeSingleMark71.ViewTag = ((long)(694546885570217989));
            c1GaugeSingleMark71.Width = 2D;
            c1GaugeSingleMark72.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark72.Length = 21.345434125D;
            c1GaugeSingleMark72.Location = 78.8800384861149D;
            c1GaugeSingleMark72.Position = 0.288220128919944D;
            c1GaugeSingleMark72.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark72.ShapeAngle = 16.5084237441927D;
            c1GaugeSingleMark72.Value = 0.71D;
            c1GaugeSingleMark72.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark72.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(695672785477060613))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(695954260453771269)))});
            c1GaugeSingleMark72.ViewTag = ((long)(695391310500349957));
            c1GaugeSingleMark72.Width = 2D;
            c1GaugeSingleMark73.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark73.Length = 22.003008D;
            c1GaugeSingleMark73.Location = 79.5411031318755D;
            c1GaugeSingleMark73.Position = 0.306754368026083D;
            c1GaugeSingleMark73.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark73.ShapeAngle = 13.4313870306314D;
            c1GaugeSingleMark73.Value = 0.72D;
            c1GaugeSingleMark73.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark73.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(696517210407192581))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(696798685383903237)))});
            c1GaugeSingleMark73.ViewTag = ((long)(696235735430481925));
            c1GaugeSingleMark73.Width = 2D;
            c1GaugeSingleMark74.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark74.Length = 22.679103875D;
            c1GaugeSingleMark74.Location = 80.0718897488772D;
            c1GaugeSingleMark74.Position = 0.325560362119056D;
            c1GaugeSingleMark74.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark74.ShapeAngle = 10.4630382472919D;
            c1GaugeSingleMark74.Value = 0.73D;
            c1GaugeSingleMark74.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark74.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(697361635337324549))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(697643110314035205)))});
            c1GaugeSingleMark74.ViewTag = ((long)(697080160360613893));
            c1GaugeSingleMark74.Width = 2D;
            c1GaugeSingleMark75.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark75.Length = 23.373979D;
            c1GaugeSingleMark75.Location = 80.4758216927864D;
            c1GaugeSingleMark75.Position = 0.344600888875977D;
            c1GaugeSingleMark75.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark75.ShapeAngle = 7.61088510786989D;
            c1GaugeSingleMark75.Value = 0.74D;
            c1GaugeSingleMark75.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark75.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(698206060267456517))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(698487535244167173)))});
            c1GaugeSingleMark75.ViewTag = ((long)(697924585290745861));
            c1GaugeSingleMark75.Width = 2D;
            c1GaugeSingleMark76.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark76.Length = 24.087890625D;
            c1GaugeSingleMark76.Location = 80.7567493898487D;
            c1GaugeSingleMark76.Position = 0.363844094302524D;
            c1GaugeSingleMark76.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark76.ShapeAngle = 4.88196839544031D;
            c1GaugeSingleMark76.Value = 0.75D;
            c1GaugeSingleMark76.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark76.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(699050485197588485))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(699331960174299141)))});
            c1GaugeSingleMark76.ViewTag = ((long)(698769010220877829));
            c1GaugeSingleMark76.Width = 2D;
            c1GaugeSingleMark77.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark77.Length = 24.821096D;
            c1GaugeSingleMark77.Location = 80.9188861039787D;
            c1GaugeSingleMark77.Position = 0.383263708252465D;
            c1GaugeSingleMark77.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark77.ShapeAngle = 2.28281703343206D;
            c1GaugeSingleMark77.Value = 0.76D;
            c1GaugeSingleMark77.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark77.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(699894910127720453))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(700176385104431109)))});
            c1GaugeSingleMark77.ViewTag = ((long)(699613435151009797));
            c1GaugeSingleMark77.Width = 2D;
            c1GaugeSingleMark78.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark78.Length = 25.573852375D;
            c1GaugeSingleMark78.Location = 80.9667466047225D;
            c1GaugeSingleMark78.Position = 0.40283924720324D;
            c1GaugeSingleMark78.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark78.ShapeAngle = -0.180570985671004D;
            c1GaugeSingleMark78.Value = 0.77D;
            c1GaugeSingleMark78.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark78.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(700739335057852421))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(701020810034563077)))});
            c1GaugeSingleMark78.ViewTag = ((long)(700457860081141765));
            c1GaugeSingleMark78.Width = 2D;
            c1GaugeSingleMark79.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark79.Length = 26.346417D;
            c1GaugeSingleMark79.Location = 80.9050890374126D;
            c1GaugeSingleMark79.Position = 0.422556212092191D;
            c1GaugeSingleMark79.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark79.ShapeAngle = -2.5027265416383D;
            c1GaugeSingleMark79.Value = 0.78D;
            c1GaugeSingleMark79.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark79.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(701583759987984389))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(701865234964695045)))});
            c1GaugeSingleMark79.ViewTag = ((long)(701302285011273733));
            c1GaugeSingleMark79.Width = 2D;
            c1GaugeSingleMark80.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark80.Length = 27.139047125D;
            c1GaugeSingleMark80.Location = 80.7388602267624D;
            c1GaugeSingleMark80.Position = 0.442406289728273D;
            c1GaugeSingleMark80.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark80.ShapeAngle = -4.67869205207966D;
            c1GaugeSingleMark80.Value = 0.79D;
            c1GaugeSingleMark80.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark80.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(702428184918116357))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(702709659894827013)))});
            c1GaugeSingleMark80.ViewTag = ((long)(702146709941405701));
            c1GaugeSingleMark80.Width = 2D;
            c1GaugeSingleMark81.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark81.Length = 27.952D;
            c1GaugeSingleMark81.Location = 80.473144580862D;
            c1GaugeSingleMark81.Position = 0.462387567140201D;
            c1GaugeSingleMark81.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark81.ShapeAngle = -6.70399535185997D;
            c1GaugeSingleMark81.Value = 0.8D;
            c1GaugeSingleMark81.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark81.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(703272609848248325))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(703554084824958981)))});
            c1GaugeSingleMark81.ViewTag = ((long)(702991134871537669));
            c1GaugeSingleMark81.Width = 2D;
            c1GaugeSingleMark82.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark82.Length = 28.785532875D;
            c1GaugeSingleMark82.Location = 80.1131167041709D;
            c1GaugeSingleMark82.Position = 0.482504769255588D;
            c1GaugeSingleMark82.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark82.ShapeAngle = -8.57462147911425D;
            c1GaugeSingleMark82.Value = 0.81D;
            c1GaugeSingleMark82.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark82.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(704117034778380293))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(704398509755090949)))});
            c1GaugeSingleMark82.ViewTag = ((long)(703835559801669637));
            c1GaugeSingleMark82.Width = 2D;
            c1GaugeSingleMark83.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark83.Length = 29.639903D;
            c1GaugeSingleMark83.Location = 79.6639977756902D;
            c1GaugeSingleMark83.Position = 0.502769531590431D;
            c1GaugeSingleMark83.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark83.ShapeAngle = -10.2869889197985D;
            c1GaugeSingleMark83.Value = 0.82D;
            c1GaugeSingleMark83.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark83.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(704961459708512261))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(705242934685222917)))});
            c1GaugeSingleMark83.ViewTag = ((long)(704679984731801605));
            c1GaugeSingleMark83.Width = 2D;
            c1GaugeSingleMark84.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark84.Length = 30.515367625D;
            c1GaugeSingleMark84.Location = 79.1310157019475D;
            c1GaugeSingleMark84.Position = 0.523200721244964D;
            c1GaugeSingleMark84.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark84.ShapeAngle = -11.8379364614777D;
            c1GaugeSingleMark84.Value = 0.83D;
            c1GaugeSingleMark84.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark84.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(705805884638644229))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(706087359615354885)))});
            c1GaugeSingleMark84.ViewTag = ((long)(705524409661933573));
            c1GaugeSingleMark84.Width = 2D;
            c1GaugeSingleMark85.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark85.Length = 31.412184D;
            c1GaugeSingleMark85.Location = 78.5193690136277D;
            c1GaugeSingleMark85.Position = 0.543824821553517D;
            c1GaugeSingleMark85.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark85.ShapeAngle = -13.2247262096373D;
            c1GaugeSingleMark85.Value = 0.84D;
            c1GaugeSingleMark85.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark85.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Yellow, 1D, ((long)(706650309568776197))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(706931784545486853)))});
            c1GaugeSingleMark85.ViewTag = ((long)(706368834592065541));
            c1GaugeSingleMark85.Width = 2D;
            c1GaugeSingleMark86.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark86.Length = 32.330609375D;
            c1GaugeSingleMark86.Location = 77.8341944393889D;
            c1GaugeSingleMark86.Position = 0.564676398355767D;
            c1GaugeSingleMark86.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark86.ShapeAngle = -14.445067549652D;
            c1GaugeSingleMark86.Value = 0.85D;
            c1GaugeSingleMark86.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark86.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(707494734498908165))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(707776209475618821)))});
            c1GaugeSingleMark86.ViewTag = ((long)(707213259522197509));
            c1GaugeSingleMark86.Width = 2D;
            c1GaugeSingleMark87.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark87.Length = 33.270901D;
            c1GaugeSingleMark87.Location = 77.0805380603843D;
            c1GaugeSingleMark87.Position = 0.585798669219135D;
            c1GaugeSingleMark87.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark87.ShapeAngle = -15.4971658802714D;
            c1GaugeSingleMark87.Value = 0.86D;
            c1GaugeSingleMark87.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark87.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(708339159429040133))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(708620634405750789)))});
            c1GaugeSingleMark87.ViewTag = ((long)(708057684452329477));
            c1GaugeSingleMark87.Width = 2D;
            c1GaugeSingleMark88.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark88.Length = 34.233316125D;
            c1GaugeSingleMark88.Location = 76.2633299239486D;
            c1GaugeSingleMark88.Position = 0.607244201277697D;
            c1GaugeSingleMark88.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark88.ShapeAngle = -16.3797987397737D;
            c1GaugeSingleMark88.Value = 0.87D;
            c1GaugeSingleMark88.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark88.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(709183584359172101))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(709465059335882757)))});
            c1GaugeSingleMark88.ViewTag = ((long)(708902109382461445));
            c1GaugeSingleMark88.Width = 2D;
            c1GaugeSingleMark89.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark89.Length = 35.218112D;
            c1GaugeSingleMark89.Location = 75.387361974483D;
            c1GaugeSingleMark89.Position = 0.629075768970059D;
            c1GaugeSingleMark89.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark89.ShapeAngle = -17.092420403317D;
            c1GaugeSingleMark89.Value = 0.88D;
            c1GaugeSingleMark89.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark89.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(710028009289304069))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(710309484266014725)))});
            c1GaugeSingleMark89.ViewTag = ((long)(709746534312593413));
            c1GaugeSingleMark89.Width = 2D;
            c1GaugeSingleMark90.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark90.Length = 36.225545875D;
            c1GaugeSingleMark90.Location = 74.4572691434329D;
            c1GaugeSingleMark90.Position = 0.651367410273119D;
            c1GaugeSingleMark90.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark90.ShapeAngle = -17.6352940496441D;
            c1GaugeSingleMark90.Value = 0.89D;
            c1GaugeSingleMark90.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark90.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(710872434219436037))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(711153909196146693)))});
            c1GaugeSingleMark90.ViewTag = ((long)(710590959242725381));
            c1GaugeSingleMark90.Width = 2D;
            c1GaugeSingleMark91.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark91.Length = 37.255875D;
            c1GaugeSingleMark91.Location = 73.4775134280401D;
            c1GaugeSingleMark91.Position = 0.674205729607662D;
            c1GaugeSingleMark91.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark91.ShapeAngle = -18.0096480885447D;
            c1GaugeSingleMark91.Value = 0.9D;
            c1GaugeSingleMark91.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark91.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(711716859149568005))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(711998334126278661)))});
            c1GaugeSingleMark91.ViewTag = ((long)(711435384172857349));
            c1GaugeSingleMark91.Width = 2D;
            c1GaugeSingleMark92.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark92.Length = 38.309356625D;
            c1GaugeSingleMark92.Location = 72.4523707799026D;
            c1GaugeSingleMark92.Position = 0.697691508216125D;
            c1GaugeSingleMark92.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark92.ShapeAngle = -18.2178501933158D;
            c1GaugeSingleMark92.Value = 0.91D;
            c1GaugeSingleMark92.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark92.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(712561284079699973))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(712842759056410629)))});
            c1GaugeSingleMark92.ViewTag = ((long)(712279809102989317));
            c1GaugeSingleMark92.Width = 2D;
            c1GaugeSingleMark93.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark93.Length = 39.386248D;
            c1GaugeSingleMark93.Location = 71.3859206189222D;
            c1GaugeSingleMark93.Position = 0.72194169956917D;
            c1GaugeSingleMark93.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark93.ShapeAngle = -18.2635890800262D;
            c1GaugeSingleMark93.Value = 0.92D;
            c1GaugeSingleMark93.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark93.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(713405709009831941))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(713687183986542597)))});
            c1GaugeSingleMark93.ViewTag = ((long)(713124234033121285));
            c1GaugeSingleMark93.Width = 2D;
            c1GaugeSingleMark94.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark94.Length = 40.486806375D;
            c1GaugeSingleMark94.Location = 70.2820377856212D;
            c1GaugeSingleMark94.Position = 0.747091909774198D;
            c1GaugeSingleMark94.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark94.ShapeAngle = -18.1520503858045D;
            c1GaugeSingleMark94.Value = 0.93D;
            c1GaugeSingleMark94.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark94.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(714250133939963909))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(714531608916674565)))});
            c1GaugeSingleMark94.ViewTag = ((long)(713968658963253253));
            c1GaugeSingleMark94.Width = 2D;
            c1GaugeSingleMark95.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark95.Length = 41.611289D;
            c1GaugeSingleMark95.Location = 69.1443867447007D;
            c1GaugeSingleMark95.Position = 0.773299493209622D;
            c1GaugeSingleMark95.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark95.ShapeAngle = -17.8900695892207D;
            c1GaugeSingleMark95.Value = 0.94D;
            c1GaugeSingleMark95.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark95.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(715094558870095877))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(715376033846806533)))});
            c1GaugeSingleMark95.ViewTag = ((long)(714813083893385221));
            c1GaugeSingleMark95.Width = 2D;
            c1GaugeSingleMark96.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark96.Length = 42.759953125D;
            c1GaugeSingleMark96.Location = 67.9764178547885D;
            c1GaugeSingleMark96.Position = 0.800747434823418D;
            c1GaugeSingleMark96.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark96.ShapeAngle = -17.4862424617549D;
            c1GaugeSingleMark96.Value = 0.95D;
            c1GaugeSingleMark96.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark96.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(715938983800227845))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(716220458776938501)))});
            c1GaugeSingleMark96.ViewTag = ((long)(715657508823517189));
            c1GaugeSingleMark96.Width = 2D;
            c1GaugeSingleMark97.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark97.Length = 43.933056D;
            c1GaugeSingleMark97.Location = 66.7813655232477D;
            c1GaugeSingleMark97.Position = 0.829649247277254D;
            c1GaugeSingleMark97.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark97.ShapeAngle = -16.9509728526601D;
            c1GaugeSingleMark97.Value = 0.96D;
            c1GaugeSingleMark97.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark97.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(716783408730359813))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(717064883707070469)))});
            c1GaugeSingleMark97.ViewTag = ((long)(716501933753649157));
            c1GaugeSingleMark97.Width = 2D;
            c1GaugeSingleMark98.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark98.Length = 45.130854875D;
            c1GaugeSingleMark98.Location = 65.5622480704192D;
            c1GaugeSingleMark98.Position = 0.860255190134509D;
            c1GaugeSingleMark98.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark98.ShapeAngle = -16.2964394819946D;
            c1GaugeSingleMark98.Value = 0.97D;
            c1GaugeSingleMark98.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark98.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(717627833660491781))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(717909308637202437)))});
            c1GaugeSingleMark98.ViewTag = ((long)(717346358683781125));
            c1GaugeSingleMark98.Width = 2D;
            c1GaugeSingleMark99.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark99.Length = 46.353607D;
            c1GaugeSingleMark99.Location = 64.3218691344559D;
            c1GaugeSingleMark99.Position = 0.892860229700996D;
            c1GaugeSingleMark99.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark99.ShapeAngle = -15.5364683728914D;
            c1GaugeSingleMark99.Value = 0.98D;
            c1GaugeSingleMark99.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark99.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(718472258590623749))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(718753733567334405)))});
            c1GaugeSingleMark99.ViewTag = ((long)(718190783613913093));
            c1GaugeSingleMark99.Width = 2D;
            c1GaugeSingleMark100.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSingleMark100.Length = 47.601569625D;
            c1GaugeSingleMark100.Location = 63.0628204557437D;
            c1GaugeSingleMark100.Position = 0.927814317350771D;
            c1GaugeSingleMark100.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark100.ShapeAngle = -14.6863056135515D;
            c1GaugeSingleMark100.Value = 0.99D;
            c1GaugeSingleMark100.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeSingleMark100.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(64)))), ((int)(((byte)(64))))), 1D, ((long)(719316683520755717))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 100, System.Drawing.Color.DimGray, 1D, ((long)(719598158497466373)))});
            c1GaugeSingleMark100.ViewTag = ((long)(719035208544045061));
            c1GaugeSingleMark100.Width = 2D;
            this.c1LinearGauge1.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeSingleLabel4,
            c1GaugeSingleMark1,
            c1GaugeSingleMark2,
            c1GaugeSingleMark3,
            c1GaugeSingleMark4,
            c1GaugeSingleMark5,
            c1GaugeSingleMark6,
            c1GaugeSingleMark7,
            c1GaugeSingleMark8,
            c1GaugeSingleMark9,
            c1GaugeSingleMark10,
            c1GaugeSingleMark11,
            c1GaugeSingleMark12,
            c1GaugeSingleMark13,
            c1GaugeSingleMark14,
            c1GaugeSingleMark15,
            c1GaugeSingleMark16,
            c1GaugeSingleMark17,
            c1GaugeSingleMark18,
            c1GaugeSingleMark19,
            c1GaugeSingleMark20,
            c1GaugeSingleMark21,
            c1GaugeSingleMark22,
            c1GaugeSingleMark23,
            c1GaugeSingleMark24,
            c1GaugeSingleMark25,
            c1GaugeSingleMark26,
            c1GaugeSingleMark27,
            c1GaugeSingleMark28,
            c1GaugeSingleMark29,
            c1GaugeSingleMark30,
            c1GaugeSingleMark31,
            c1GaugeSingleMark32,
            c1GaugeSingleMark33,
            c1GaugeSingleMark34,
            c1GaugeSingleMark35,
            c1GaugeSingleMark36,
            c1GaugeSingleMark37,
            c1GaugeSingleMark38,
            c1GaugeSingleMark39,
            c1GaugeSingleMark40,
            c1GaugeSingleMark41,
            c1GaugeSingleMark42,
            c1GaugeSingleMark43,
            c1GaugeSingleMark44,
            c1GaugeSingleMark45,
            c1GaugeSingleMark46,
            c1GaugeSingleMark47,
            c1GaugeSingleMark48,
            c1GaugeSingleMark49,
            c1GaugeSingleMark50,
            c1GaugeSingleMark51,
            c1GaugeSingleMark52,
            c1GaugeSingleMark53,
            c1GaugeSingleMark54,
            c1GaugeSingleMark55,
            c1GaugeSingleMark56,
            c1GaugeSingleMark57,
            c1GaugeSingleMark58,
            c1GaugeSingleMark59,
            c1GaugeSingleMark60,
            c1GaugeSingleMark61,
            c1GaugeSingleMark62,
            c1GaugeSingleMark63,
            c1GaugeSingleMark64,
            c1GaugeSingleMark65,
            c1GaugeSingleMark66,
            c1GaugeSingleMark67,
            c1GaugeSingleMark68,
            c1GaugeSingleMark69,
            c1GaugeSingleMark70,
            c1GaugeSingleMark71,
            c1GaugeSingleMark72,
            c1GaugeSingleMark73,
            c1GaugeSingleMark74,
            c1GaugeSingleMark75,
            c1GaugeSingleMark76,
            c1GaugeSingleMark77,
            c1GaugeSingleMark78,
            c1GaugeSingleMark79,
            c1GaugeSingleMark80,
            c1GaugeSingleMark81,
            c1GaugeSingleMark82,
            c1GaugeSingleMark83,
            c1GaugeSingleMark84,
            c1GaugeSingleMark85,
            c1GaugeSingleMark86,
            c1GaugeSingleMark87,
            c1GaugeSingleMark88,
            c1GaugeSingleMark89,
            c1GaugeSingleMark90,
            c1GaugeSingleMark91,
            c1GaugeSingleMark92,
            c1GaugeSingleMark93,
            c1GaugeSingleMark94,
            c1GaugeSingleMark95,
            c1GaugeSingleMark96,
            c1GaugeSingleMark97,
            c1GaugeSingleMark98,
            c1GaugeSingleMark99,
            c1GaugeSingleMark100});
            c1GaugeRectangle1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.c1LinearGauge1.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle1});
            this.c1LinearGauge1.Maximum = 1D;
            this.c1LinearGauge1.Name = "c1LinearGauge1";
            this.c1LinearGauge1.Pointer.Value = 1D;
            this.c1LinearGauge1.Pointer.Visible = false;
            this.c1LinearGauge1.Viewport.AspectRatio = 1.5D;
            this.c1LinearGauge1.ViewTag = ((long)(639377651282252762));
            // 
            // c1Gauge4
            // 
            this.c1Gauge4.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1LinearGauge2});
            this.c1Gauge4.Location = new System.Drawing.Point(4, 341);
            this.c1Gauge4.Name = "c1Gauge4";
            this.c1Gauge4.Size = new System.Drawing.Size(356, 244);
            this.c1Gauge4.TabIndex = 7;
            this.c1Gauge4.ViewTag = ((long)(767453182492380901));
            // 
            // c1LinearGauge2
            // 
            this.c1LinearGauge2.AxisStart = 0.025D;
            this.c1LinearGauge2.BaseFactor = 0.95D;
            this.c1LinearGauge2.BaseOrigin = 0.025D;
            c1GaugeMarks5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks5.From = 0.001D;
            c1GaugeMarks5.IntervalWidth = 3D;
            c1GaugeMarks5.Length = 7D;
            c1GaugeMarks5.Location = 5D;
            c1GaugeMarks5.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks5.ScaleFrom = 0D;
            c1GaugeMarks5.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks5.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks5.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Khaki, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 0, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks5.ViewTag = ((long)(635151407842501340));
            c1GaugeMarks5.Width = 2D;
            c1GaugeMarks6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks6.From = 0.001D;
            c1GaugeMarks6.IntervalWidth = 3D;
            c1GaugeMarks6.Length = 7D;
            c1GaugeMarks6.Location = 15D;
            c1GaugeMarks6.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks6.ScaleFrom = 0D;
            c1GaugeMarks6.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks6.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks6.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.DeepSkyBlue, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 1, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks6.ViewTag = ((long)(635151407842501341));
            c1GaugeMarks6.Width = 2D;
            c1GaugeMarks7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks7.From = 0.001D;
            c1GaugeMarks7.IntervalWidth = 3D;
            c1GaugeMarks7.Length = 7D;
            c1GaugeMarks7.Location = 25D;
            c1GaugeMarks7.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks7.ScaleFrom = 0D;
            c1GaugeMarks7.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks7.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks7.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.SpringGreen, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 2, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks7.ViewTag = ((long)(635151407842501342));
            c1GaugeMarks7.Width = 2D;
            c1GaugeMarks8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks8.From = 0.001D;
            c1GaugeMarks8.IntervalWidth = 3D;
            c1GaugeMarks8.Length = 7D;
            c1GaugeMarks8.Location = 35D;
            c1GaugeMarks8.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks8.ScaleFrom = 0D;
            c1GaugeMarks8.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks8.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks8.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LightSteelBlue, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 3, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks8.ViewTag = ((long)(635151407842501343));
            c1GaugeMarks8.Width = 2D;
            c1GaugeMarks9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks9.From = 0.001D;
            c1GaugeMarks9.IntervalWidth = 3D;
            c1GaugeMarks9.Length = 7D;
            c1GaugeMarks9.Location = 45D;
            c1GaugeMarks9.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks9.ScaleFrom = 0D;
            c1GaugeMarks9.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks9.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks9.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Pink, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 4, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks9.ViewTag = ((long)(635151407842501344));
            c1GaugeMarks9.Width = 2D;
            c1GaugeMarks10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks10.From = 0.001D;
            c1GaugeMarks10.IntervalWidth = 3D;
            c1GaugeMarks10.Length = 7D;
            c1GaugeMarks10.Location = 55D;
            c1GaugeMarks10.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks10.ScaleFrom = 0D;
            c1GaugeMarks10.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks10.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks10.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.PaleGreen, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 5, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks10.ViewTag = ((long)(635151407842501345));
            c1GaugeMarks10.Width = 2D;
            c1GaugeMarks11.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks11.From = 0.001D;
            c1GaugeMarks11.IntervalWidth = 3D;
            c1GaugeMarks11.Length = 7D;
            c1GaugeMarks11.Location = 65D;
            c1GaugeMarks11.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks11.ScaleFrom = 0D;
            c1GaugeMarks11.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks11.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks11.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Cyan, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 6, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks11.ViewTag = ((long)(635151407842501346));
            c1GaugeMarks11.Width = 2D;
            c1GaugeMarks12.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks12.From = 0.001D;
            c1GaugeMarks12.IntervalWidth = 3D;
            c1GaugeMarks12.Length = 7D;
            c1GaugeMarks12.Location = 75D;
            c1GaugeMarks12.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks12.ScaleFrom = 0D;
            c1GaugeMarks12.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks12.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks12.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Gold, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 7, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks12.ViewTag = ((long)(635151407842501347));
            c1GaugeMarks12.Width = 2D;
            c1GaugeMarks13.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks13.From = 0.001D;
            c1GaugeMarks13.IntervalWidth = 3D;
            c1GaugeMarks13.Length = 7D;
            c1GaugeMarks13.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks13.ScaleFrom = 0D;
            c1GaugeMarks13.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks13.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks13.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.LightCoral, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 8, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks13.ViewTag = ((long)(635151407842501348));
            c1GaugeMarks13.Width = 2D;
            c1GaugeMarks14.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks14.From = 0.001D;
            c1GaugeMarks14.IntervalWidth = 3D;
            c1GaugeMarks14.Length = 7D;
            c1GaugeMarks14.Location = 95D;
            c1GaugeMarks14.OrthogonalAlignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks14.ScaleFrom = 0D;
            c1GaugeMarks14.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks14.ValueColorFalloff = C1.Win.C1Gauge.C1GaugeValueColorFalloff.None;
            c1GaugeMarks14.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.OldLace, 1D, ((long)(635432888687017615))),
            new C1.Win.C1Gauge.C1GaugeValueColor(double.NaN, 9, System.Drawing.Color.DimGray, 0.5D, ((long)(641906831190384476)))});
            c1GaugeMarks14.ViewTag = ((long)(635151407842501349));
            c1GaugeMarks14.Width = 2D;
            this.c1LinearGauge2.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks5,
            c1GaugeMarks6,
            c1GaugeMarks7,
            c1GaugeMarks8,
            c1GaugeMarks9,
            c1GaugeMarks10,
            c1GaugeMarks11,
            c1GaugeMarks12,
            c1GaugeMarks13,
            c1GaugeMarks14});
            c1GaugeRectangle2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle2.Filling.Color = System.Drawing.Color.Black;
            c1GaugeRectangle2.Viewport.ScaleY = 1.07D;
            c1GaugeRectangle2.Viewport.TranslateY = -0.01D;
            c1GaugeCaption1.CenterPointX = 0.055D;
            c1GaugeCaption1.CenterPointY = 1.03D;
            c1GaugeCaption1.Color = System.Drawing.Color.White;
            c1GaugeCaption1.FontSize = 4D;
            c1GaugeCaption1.Text = "31Hz";
            c1GaugeCaption2.CenterPointX = 0.15D;
            c1GaugeCaption2.CenterPointY = 1.03D;
            c1GaugeCaption2.Color = System.Drawing.Color.White;
            c1GaugeCaption2.FontSize = 4D;
            c1GaugeCaption2.Text = "62";
            c1GaugeCaption3.CenterPointX = 0.25D;
            c1GaugeCaption3.CenterPointY = 1.03D;
            c1GaugeCaption3.Color = System.Drawing.Color.White;
            c1GaugeCaption3.FontSize = 4D;
            c1GaugeCaption3.Text = "125";
            c1GaugeCaption4.CenterPointX = 0.35D;
            c1GaugeCaption4.CenterPointY = 1.03D;
            c1GaugeCaption4.Color = System.Drawing.Color.White;
            c1GaugeCaption4.FontSize = 4D;
            c1GaugeCaption4.Text = "250";
            c1GaugeCaption5.CenterPointX = 0.45D;
            c1GaugeCaption5.CenterPointY = 1.03D;
            c1GaugeCaption5.Color = System.Drawing.Color.White;
            c1GaugeCaption5.FontSize = 4D;
            c1GaugeCaption5.Text = "500";
            c1GaugeCaption6.CenterPointX = 0.55D;
            c1GaugeCaption6.CenterPointY = 1.03D;
            c1GaugeCaption6.Color = System.Drawing.Color.White;
            c1GaugeCaption6.FontSize = 4D;
            c1GaugeCaption6.Text = "1KHz";
            c1GaugeCaption7.CenterPointX = 0.65D;
            c1GaugeCaption7.CenterPointY = 1.03D;
            c1GaugeCaption7.Color = System.Drawing.Color.White;
            c1GaugeCaption7.FontSize = 4D;
            c1GaugeCaption7.Text = "2";
            c1GaugeCaption8.CenterPointX = 0.75D;
            c1GaugeCaption8.CenterPointY = 1.03D;
            c1GaugeCaption8.Color = System.Drawing.Color.White;
            c1GaugeCaption8.FontSize = 4D;
            c1GaugeCaption8.Text = "4";
            c1GaugeCaption9.CenterPointX = 0.85D;
            c1GaugeCaption9.CenterPointY = 1.03D;
            c1GaugeCaption9.Color = System.Drawing.Color.White;
            c1GaugeCaption9.FontSize = 4D;
            c1GaugeCaption9.Text = "8";
            c1GaugeCaption10.CenterPointX = 0.94D;
            c1GaugeCaption10.CenterPointY = 1.03D;
            c1GaugeCaption10.Color = System.Drawing.Color.White;
            c1GaugeCaption10.FontSize = 4D;
            c1GaugeCaption10.Text = "16KHz";
            this.c1LinearGauge2.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle2,
            c1GaugeCaption1,
            c1GaugeCaption2,
            c1GaugeCaption3,
            c1GaugeCaption4,
            c1GaugeCaption5,
            c1GaugeCaption6,
            c1GaugeCaption7,
            c1GaugeCaption8,
            c1GaugeCaption9,
            c1GaugeCaption10});
            this.c1LinearGauge2.IsReversed = true;
            c1GaugePointer4.SweepTime = 1D;
            c1GaugePointer4.Value = 9D;
            c1GaugePointer4.ViewTag = ((long)(639092078879292408));
            c1GaugePointer4.Visible = false;
            c1GaugePointer5.SweepTime = 1D;
            c1GaugePointer5.Value = 50D;
            c1GaugePointer5.ViewTag = ((long)(639373554037453443));
            c1GaugePointer5.Visible = false;
            c1GaugePointer6.SweepTime = 1D;
            c1GaugePointer6.Value = 68D;
            c1GaugePointer6.ViewTag = ((long)(639655029020324451));
            c1GaugePointer6.Visible = false;
            c1GaugePointer7.SweepTime = 1D;
            c1GaugePointer7.Value = 44D;
            c1GaugePointer7.ViewTag = ((long)(639936504002445416));
            c1GaugePointer7.Visible = false;
            c1GaugePointer8.SweepTime = 1D;
            c1GaugePointer8.Value = 89D;
            c1GaugePointer8.ViewTag = ((long)(640217978982406258));
            c1GaugePointer8.Visible = false;
            c1GaugePointer9.SweepTime = 1D;
            c1GaugePointer9.Value = 62D;
            c1GaugePointer9.ViewTag = ((long)(640499453962297096));
            c1GaugePointer9.Visible = false;
            c1GaugePointer10.SweepTime = 1D;
            c1GaugePointer10.Value = 27D;
            c1GaugePointer10.ViewTag = ((long)(640780928942047926));
            c1GaugePointer10.Visible = false;
            c1GaugePointer11.SweepTime = 1D;
            c1GaugePointer11.Value = 46D;
            c1GaugePointer11.ViewTag = ((long)(641062403921548742));
            c1GaugePointer11.Visible = false;
            c1GaugePointer12.SweepTime = 1D;
            c1GaugePointer12.Value = 75D;
            c1GaugePointer12.ViewTag = ((long)(641343878901929608));
            c1GaugePointer12.Visible = false;
            c1GaugePointer13.SweepTime = 1D;
            c1GaugePointer13.Value = 37D;
            c1GaugePointer13.ViewTag = ((long)(641625353888230812));
            c1GaugePointer13.Visible = false;
            this.c1LinearGauge2.MorePointers.AddRange(new C1.Win.C1Gauge.C1GaugePointer[] {
            c1GaugePointer4,
            c1GaugePointer5,
            c1GaugePointer6,
            c1GaugePointer7,
            c1GaugePointer8,
            c1GaugePointer9,
            c1GaugePointer10,
            c1GaugePointer11,
            c1GaugePointer12,
            c1GaugePointer13});
            this.c1LinearGauge2.Name = "c1LinearGauge2";
            this.c1LinearGauge2.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge2.Pointer.Value = 50D;
            this.c1LinearGauge2.Pointer.Visible = false;
            this.c1LinearGauge2.ViewTag = ((long)(634588456711232659));
            // 
            // c1Sizer1
            // 
            this.c1Sizer1.Controls.Add(this.trackBar4);
            this.c1Sizer1.Controls.Add(this.trackBar3);
            this.c1Sizer1.Controls.Add(this.c1Gauge1);
            this.c1Sizer1.Controls.Add(this.c1Gauge3);
            this.c1Sizer1.Controls.Add(this.c1Gauge4);
            this.c1Sizer1.Controls.Add(this.trackBar2);
            this.c1Sizer1.Controls.Add(this.c1Gauge2);
            this.c1Sizer1.Controls.Add(this.trackBar1);
            this.c1Sizer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Sizer1.GridDefinition = resources.GetString("c1Sizer1.GridDefinition");
            this.c1Sizer1.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer1.Name = "c1Sizer1";
            this.c1Sizer1.Size = new System.Drawing.Size(787, 589);
            this.c1Sizer1.TabIndex = 8;
            this.c1Sizer1.Text = "c1Sizer1";
            // 
            // trackBar4
            // 
            this.trackBar4.AutoSize = false;
            this.trackBar4.Location = new System.Drawing.Point(364, 341);
            this.trackBar4.Maximum = 100;
            this.trackBar4.Name = "trackBar4";
            this.trackBar4.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar4.Size = new System.Drawing.Size(22, 244);
            this.trackBar4.TabIndex = 9;
            this.trackBar4.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar4.Value = 5;
            this.trackBar4.Scroll += new System.EventHandler(this.trackBar4_Scroll);
            // 
            // trackBar3
            // 
            this.trackBar3.AutoSize = false;
            this.trackBar3.Location = new System.Drawing.Point(390, 560);
            this.trackBar3.Maximum = 100;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Size = new System.Drawing.Size(393, 25);
            this.trackBar3.TabIndex = 8;
            this.trackBar3.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar3.Value = 100;
            this.trackBar3.Scroll += new System.EventHandler(this.trackBar3_Scroll);
            // 
            // Advanced
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(787, 589);
            this.Controls.Add(this.c1Sizer1);
            this.Name = "Advanced";
            this.Text = "Advanced";
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer1)).EndInit();
            this.c1Sizer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1Gauge.C1Gauge c1Gauge1;
        private C1.Win.C1Gauge.C1RadialGauge c1RadialGauge1;
        private C1.Win.C1Gauge.C1Gauge c1Gauge2;
        private C1.Win.C1Gauge.C1RadialGauge c1RadialGauge2;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TrackBar trackBar1;
        private C1.Win.C1Gauge.C1Gauge c1Gauge3;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge1;
        private C1.Win.C1Gauge.C1Gauge c1Gauge4;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge2;
        private C1.Win.C1Sizer.C1Sizer c1Sizer1;
        private System.Windows.Forms.TrackBar trackBar4;
        private System.Windows.Forms.TrackBar trackBar3;
    }
}