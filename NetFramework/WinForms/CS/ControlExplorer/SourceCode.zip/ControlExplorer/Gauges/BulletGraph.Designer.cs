﻿namespace ControlExplorer.Gauges
{
    partial class BulletGraph
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption7 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption8 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption9 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption10 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption11 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption12 = new C1.Win.C1Gauge.C1GaugeCaption();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.c1BulletGraph10 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph9 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph8 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph7 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph6 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph1 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph2 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph3 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph4 = new C1.Win.C1Gauge.C1BulletGraph();
            this.c1BulletGraph5 = new C1.Win.C1Gauge.C1BulletGraph();
            this.label1 = new System.Windows.Forms.Label();
            this.c1LinearGauge1 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1LinearGauge2 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1LinearGauge3 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1LinearGauge4 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1LinearGauge5 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1LinearGauge6 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1LinearGauge7 = new C1.Win.C1Gauge.C1LinearGauge();
            this.c1LinearGauge8 = new C1.Win.C1Gauge.C1LinearGauge();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph5)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph10, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph9, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph8, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph7, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph6, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.c1BulletGraph5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1033, 567);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.label2, 5);
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(390, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(640, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "2018 YTD";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // c1BulletGraph10
            // 
            this.c1BulletGraph10.Bad.To = 3D;
            this.c1BulletGraph10.Caption.Position = C1.Win.C1Gauge.BulletGraphCaptionPosition.Left;
            this.c1BulletGraph10.Caption.Text = "Customer Satisfaction";
            this.c1BulletGraph10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph10.Good.To = 4D;
            this.c1BulletGraph10.GraphScale.LabelsInterval = 1D;
            this.c1BulletGraph10.GraphScale.MarksInterval = 1D;
            this.c1BulletGraph10.IsReversed = true;
            this.c1BulletGraph10.Location = new System.Drawing.Point(913, 28);
            this.c1BulletGraph10.Margin = new System.Windows.Forms.Padding(10, 3, 5, 3);
            this.c1BulletGraph10.Maximum = 5D;
            this.c1BulletGraph10.Name = "c1BulletGraph10";
            this.c1BulletGraph10.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1BulletGraph10.Origin = double.NaN;
            this.tableLayoutPanel1.SetRowSpan(this.c1BulletGraph10, 5);
            this.c1BulletGraph10.Size = new System.Drawing.Size(115, 536);
            this.c1BulletGraph10.TabIndex = 9;
            this.c1BulletGraph10.Target = 3.5D;
            this.c1BulletGraph10.Text = "c1BulletGraph10";
            this.c1BulletGraph10.Value = 1D;
            // 
            // c1BulletGraph9
            // 
            this.c1BulletGraph9.Bad.To = 320D;
            this.c1BulletGraph9.Caption.Position = C1.Win.C1Gauge.BulletGraphCaptionPosition.Left;
            this.c1BulletGraph9.Caption.Text = "Avg Order Size, $";
            this.c1BulletGraph9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph9.Good.To = 500D;
            this.c1BulletGraph9.GraphScale.Format = "#$";
            this.c1BulletGraph9.GraphScale.LabelsInterval = 100D;
            this.c1BulletGraph9.GraphScale.MarksInterval = 100D;
            this.c1BulletGraph9.IsReversed = true;
            this.c1BulletGraph9.Location = new System.Drawing.Point(784, 28);
            this.c1BulletGraph9.Margin = new System.Windows.Forms.Padding(10, 3, 5, 3);
            this.c1BulletGraph9.Maximum = 600D;
            this.c1BulletGraph9.Name = "c1BulletGraph9";
            this.c1BulletGraph9.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1BulletGraph9.Origin = double.NaN;
            this.tableLayoutPanel1.SetRowSpan(this.c1BulletGraph9, 5);
            this.c1BulletGraph9.Size = new System.Drawing.Size(114, 536);
            this.c1BulletGraph9.TabIndex = 8;
            this.c1BulletGraph9.Target = 520D;
            this.c1BulletGraph9.Text = "c1BulletGraph9";
            this.c1BulletGraph9.Value = 120D;
            // 
            // c1BulletGraph8
            // 
            this.c1BulletGraph8.Bad.To = 120D;
            this.c1BulletGraph8.Caption.Alignment = System.Drawing.StringAlignment.Center;
            this.c1BulletGraph8.Caption.Height = 51D;
            this.c1BulletGraph8.Caption.Text = "Profit (1000%)";
            this.c1BulletGraph8.Caption.Width = 70D;
            this.c1BulletGraph8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph8.Good.To = 200D;
            this.c1BulletGraph8.GraphScale.LabelsInterval = 50D;
            this.c1BulletGraph8.GraphScale.MarksInterval = 50D;
            this.c1BulletGraph8.IsReversed = true;
            this.c1BulletGraph8.Location = new System.Drawing.Point(655, 28);
            this.c1BulletGraph8.Margin = new System.Windows.Forms.Padding(10, 3, 5, 3);
            this.c1BulletGraph8.Maximum = 250D;
            this.c1BulletGraph8.Minimum = -50D;
            this.c1BulletGraph8.Name = "c1BulletGraph8";
            this.c1BulletGraph8.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1BulletGraph8.Origin = 0D;
            this.tableLayoutPanel1.SetRowSpan(this.c1BulletGraph8, 5);
            this.c1BulletGraph8.Size = new System.Drawing.Size(114, 536);
            this.c1BulletGraph8.TabIndex = 7;
            this.c1BulletGraph8.Target = 190D;
            this.c1BulletGraph8.Text = "c1BulletGraph8";
            this.c1BulletGraph8.Value = -25D;
            // 
            // c1BulletGraph7
            // 
            this.c1BulletGraph7.Bad.From = 80D;
            this.c1BulletGraph7.Bad.To = 120D;
            this.c1BulletGraph7.Caption.Alignment = System.Drawing.StringAlignment.Center;
            this.c1BulletGraph7.Caption.Height = 51D;
            this.c1BulletGraph7.Caption.Text = "Expenses (1000$)";
            this.c1BulletGraph7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph7.Good.From = 40D;
            this.c1BulletGraph7.Location = new System.Drawing.Point(526, 28);
            this.c1BulletGraph7.Margin = new System.Windows.Forms.Padding(10, 3, 5, 3);
            this.c1BulletGraph7.Maximum = 120D;
            this.c1BulletGraph7.Name = "c1BulletGraph7";
            this.c1BulletGraph7.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1BulletGraph7.Origin = double.NaN;
            this.tableLayoutPanel1.SetRowSpan(this.c1BulletGraph7, 5);
            this.c1BulletGraph7.Size = new System.Drawing.Size(114, 536);
            this.c1BulletGraph7.TabIndex = 6;
            this.c1BulletGraph7.Text = "c1BulletGraph7";
            this.c1BulletGraph7.Value = 107D;
            // 
            // c1BulletGraph6
            // 
            this.c1BulletGraph6.Bad.To = 180D;
            this.c1BulletGraph6.Caption.Alignment = System.Drawing.StringAlignment.Center;
            this.c1BulletGraph6.Caption.Height = 51D;
            this.c1BulletGraph6.Caption.Text = "Revenue (1000$)";
            this.c1BulletGraph6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph6.Good.To = 250D;
            this.c1BulletGraph6.GraphScale.LabelsInterval = 50D;
            this.c1BulletGraph6.GraphScale.MarksInterval = 50D;
            this.c1BulletGraph6.IsReversed = true;
            this.c1BulletGraph6.Location = new System.Drawing.Point(397, 28);
            this.c1BulletGraph6.Margin = new System.Windows.Forms.Padding(10, 3, 5, 3);
            this.c1BulletGraph6.Maximum = 300D;
            this.c1BulletGraph6.Name = "c1BulletGraph6";
            this.c1BulletGraph6.Orientation = C1.Win.C1Gauge.C1GaugeOrientation.Vertical;
            this.c1BulletGraph6.Origin = double.NaN;
            this.tableLayoutPanel1.SetRowSpan(this.c1BulletGraph6, 5);
            this.c1BulletGraph6.Size = new System.Drawing.Size(114, 536);
            this.c1BulletGraph6.TabIndex = 5;
            this.c1BulletGraph6.Target = 225D;
            this.c1BulletGraph6.Text = "c1BulletGraph6";
            this.c1BulletGraph6.Value = 95D;
            // 
            // c1BulletGraph1
            // 
            this.c1BulletGraph1.Bad.To = 180D;
            this.c1BulletGraph1.Caption.Alignment = System.Drawing.StringAlignment.Far;
            this.c1BulletGraph1.Caption.Position = C1.Win.C1Gauge.BulletGraphCaptionPosition.Left;
            this.c1BulletGraph1.Caption.Text = "Revenue (1000$)";
            this.c1BulletGraph1.Caption.Width = 60D;
            this.c1BulletGraph1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph1.Good.To = 250D;
            this.c1BulletGraph1.GraphScale.LabelsInterval = 50D;
            this.c1BulletGraph1.GraphScale.MarksInterval = 50D;
            this.c1BulletGraph1.Location = new System.Drawing.Point(3, 35);
            this.c1BulletGraph1.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.c1BulletGraph1.Maximum = 300D;
            this.c1BulletGraph1.Name = "c1BulletGraph1";
            this.c1BulletGraph1.Origin = double.NaN;
            this.c1BulletGraph1.Size = new System.Drawing.Size(381, 88);
            this.c1BulletGraph1.TabIndex = 0;
            this.c1BulletGraph1.Target = 225D;
            this.c1BulletGraph1.Text = "c1BulletGraph1";
            this.c1BulletGraph1.Value = 280D;
            // 
            // c1BulletGraph2
            // 
            this.c1BulletGraph2.Bad.From = 80D;
            this.c1BulletGraph2.Bad.To = 120D;
            this.c1BulletGraph2.Caption.Alignment = System.Drawing.StringAlignment.Far;
            this.c1BulletGraph2.Caption.Position = C1.Win.C1Gauge.BulletGraphCaptionPosition.Left;
            this.c1BulletGraph2.Caption.Text = "Expenses (1000$)";
            this.c1BulletGraph2.Caption.Width = 60D;
            this.c1BulletGraph2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph2.Good.From = 40D;
            this.c1BulletGraph2.GraphScale.LabelsInterval = 20D;
            this.c1BulletGraph2.GraphScale.MarksInterval = 20D;
            this.c1BulletGraph2.Location = new System.Drawing.Point(3, 143);
            this.c1BulletGraph2.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.c1BulletGraph2.Maximum = 120D;
            this.c1BulletGraph2.Name = "c1BulletGraph2";
            this.c1BulletGraph2.Origin = double.NaN;
            this.c1BulletGraph2.Size = new System.Drawing.Size(381, 88);
            this.c1BulletGraph2.TabIndex = 1;
            this.c1BulletGraph2.Text = "c1BulletGraph2";
            this.c1BulletGraph2.Value = 58D;
            // 
            // c1BulletGraph3
            // 
            this.c1BulletGraph3.Bad.To = 0.15D;
            this.c1BulletGraph3.Caption.Alignment = System.Drawing.StringAlignment.Far;
            this.c1BulletGraph3.Caption.Position = C1.Win.C1Gauge.BulletGraphCaptionPosition.Left;
            this.c1BulletGraph3.Caption.Text = "Profit";
            this.c1BulletGraph3.Caption.Width = 60D;
            this.c1BulletGraph3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph3.Good.To = 0.25D;
            this.c1BulletGraph3.GraphScale.Format = "#%";
            this.c1BulletGraph3.GraphScale.LabelsInterval = 0.05D;
            this.c1BulletGraph3.GraphScale.MarksInterval = 0.05D;
            this.c1BulletGraph3.Location = new System.Drawing.Point(3, 251);
            this.c1BulletGraph3.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.c1BulletGraph3.Maximum = 0.3D;
            this.c1BulletGraph3.Name = "c1BulletGraph3";
            this.c1BulletGraph3.Origin = double.NaN;
            this.c1BulletGraph3.Size = new System.Drawing.Size(381, 88);
            this.c1BulletGraph3.TabIndex = 2;
            this.c1BulletGraph3.Target = 0.27D;
            this.c1BulletGraph3.Text = "c1BulletGraph3";
            this.c1BulletGraph3.Value = 0.23D;
            // 
            // c1BulletGraph4
            // 
            this.c1BulletGraph4.Bad.To = 320D;
            this.c1BulletGraph4.Caption.Text = "Avg Order Size, $";
            this.c1BulletGraph4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph4.Good.To = 500D;
            this.c1BulletGraph4.GraphScale.Format = "#$";
            this.c1BulletGraph4.GraphScale.LabelsInterval = 100D;
            this.c1BulletGraph4.GraphScale.MarksInterval = 100D;
            this.c1BulletGraph4.Location = new System.Drawing.Point(3, 359);
            this.c1BulletGraph4.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.c1BulletGraph4.Maximum = 600D;
            this.c1BulletGraph4.Name = "c1BulletGraph4";
            this.c1BulletGraph4.Origin = double.NaN;
            this.c1BulletGraph4.Size = new System.Drawing.Size(381, 88);
            this.c1BulletGraph4.TabIndex = 3;
            this.c1BulletGraph4.Target = 520D;
            this.c1BulletGraph4.Text = "c1BulletGraph4";
            this.c1BulletGraph4.Value = 380D;
            // 
            // c1BulletGraph5
            // 
            this.c1BulletGraph5.Bad.To = 3D;
            this.c1BulletGraph5.Caption.Text = "Customer Satisfaction";
            this.c1BulletGraph5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1BulletGraph5.Good.To = 4D;
            this.c1BulletGraph5.GraphScale.LabelsInterval = 1D;
            this.c1BulletGraph5.GraphScale.MarksInterval = 1D;
            this.c1BulletGraph5.Location = new System.Drawing.Point(3, 467);
            this.c1BulletGraph5.Margin = new System.Windows.Forms.Padding(3, 10, 3, 10);
            this.c1BulletGraph5.Maximum = 5D;
            this.c1BulletGraph5.Name = "c1BulletGraph5";
            this.c1BulletGraph5.Origin = double.NaN;
            this.c1BulletGraph5.Size = new System.Drawing.Size(381, 90);
            this.c1BulletGraph5.TabIndex = 4;
            this.c1BulletGraph5.Target = 3.5D;
            this.c1BulletGraph5.Text = "c1BulletGraph5";
            this.c1BulletGraph5.Value = 3.3D;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(381, 25);
            this.label1.TabIndex = 10;
            this.label1.Text = "2017 YTD";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // c1LinearGauge1
            // 
            c1GaugeCaption7.Alignment = System.Drawing.StringAlignment.Far;
            c1GaugeCaption7.Height = 108.33333333333334D;
            c1GaugeCaption7.Text = "Revenue (1000$)";
            c1GaugeCaption7.Width = 102.56410256410256D;
            this.c1LinearGauge1.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption7});
            this.c1LinearGauge1.Name = "c1LinearGauge1";
            this.c1LinearGauge1.Pointer.Visible = false;
            this.c1LinearGauge1.Viewport.Width = 60;
            this.c1LinearGauge1.ViewTag = ((long)(637957196821945733));
            // 
            // c1LinearGauge2
            // 
            c1GaugeCaption8.Alignment = System.Drawing.StringAlignment.Far;
            c1GaugeCaption8.Height = 108.33333333333334D;
            c1GaugeCaption8.Text = "Expenses (1000$)";
            c1GaugeCaption8.Width = 102.56410256410256D;
            this.c1LinearGauge2.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption8});
            this.c1LinearGauge2.Name = "c1LinearGauge2";
            this.c1LinearGauge2.Pointer.Visible = false;
            this.c1LinearGauge2.Viewport.Width = 60;
            this.c1LinearGauge2.ViewTag = ((long)(645838497918669873));
            // 
            // c1LinearGauge3
            // 
            this.c1LinearGauge3.Name = "c1LinearGauge3";
            this.c1LinearGauge3.Pointer.Visible = false;
            this.c1LinearGauge3.Viewport.Width = 50;
            this.c1LinearGauge3.ViewTag = ((long)(657660447078250826));
            // 
            // c1LinearGauge4
            // 
            c1GaugeCaption9.Alignment = System.Drawing.StringAlignment.Far;
            c1GaugeCaption9.Height = 108.33333333333334D;
            c1GaugeCaption9.Text = "Profit, %";
            c1GaugeCaption9.Width = 102.56410256410256D;
            this.c1LinearGauge4.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption9});
            this.c1LinearGauge4.Name = "c1LinearGauge4";
            this.c1LinearGauge4.Pointer.Visible = false;
            this.c1LinearGauge4.Viewport.Width = 60;
            this.c1LinearGauge4.ViewTag = ((long)(649779147700915709));
            // 
            // c1LinearGauge5
            // 
            c1GaugeCaption10.Height = 66.666666666666671D;
            c1GaugeCaption10.Text = "Revenue (1000$)";
            c1GaugeCaption10.Width = 166.66666666666666D;
            this.c1LinearGauge5.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption10});
            this.c1LinearGauge5.Name = "c1LinearGauge5";
            this.c1LinearGauge5.Pointer.Visible = false;
            this.c1LinearGauge5.Viewport.Height = 51;
            this.c1LinearGauge5.ViewTag = ((long)(681304345361391835));
            // 
            // c1LinearGauge6
            // 
            c1GaugeCaption11.Height = 66.666666666666671D;
            c1GaugeCaption11.Text = "Expenses (1000$)";
            c1GaugeCaption11.Width = 166.66666666666666D;
            this.c1LinearGauge6.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption11});
            this.c1LinearGauge6.Name = "c1LinearGauge6";
            this.c1LinearGauge6.Pointer.Visible = false;
            this.c1LinearGauge6.Viewport.Height = 51;
            this.c1LinearGauge6.ViewTag = ((long)(685244995541512653));
            // 
            // c1LinearGauge7
            // 
            c1GaugeCaption12.Height = 66.666666666666671D;
            c1GaugeCaption12.Text = "Profit (1000%)";
            c1GaugeCaption12.Width = 137.25490196078431D;
            this.c1LinearGauge7.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeCaption12});
            this.c1LinearGauge7.Name = "c1LinearGauge7";
            this.c1LinearGauge7.Pointer.Visible = false;
            this.c1LinearGauge7.Viewport.Height = 51;
            this.c1LinearGauge7.ViewTag = ((long)(689185645235463347));
            // 
            // c1LinearGauge8
            // 
            this.c1LinearGauge8.Name = "c1LinearGauge8";
            this.c1LinearGauge8.Pointer.Visible = false;
            this.c1LinearGauge8.Viewport.Height = 26;
            this.c1LinearGauge8.ViewTag = ((long)(693126294914197477));
            // 
            // BulletGraph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 567);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "BulletGraph";
            this.Text = "BulletGraph";
            this.Load += new System.EventHandler(this.BulletGraph_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1BulletGraph5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph1;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph10;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph9;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph8;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph7;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph6;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph2;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph3;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph4;
        private C1.Win.C1Gauge.C1BulletGraph c1BulletGraph5;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge1;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge2;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge3;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge4;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge5;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge6;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge7;
        private C1.Win.C1Gauge.C1LinearGauge c1LinearGauge8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}