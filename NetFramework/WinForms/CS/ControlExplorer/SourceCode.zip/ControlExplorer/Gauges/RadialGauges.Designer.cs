﻿namespace ControlExplorer.Gauges
{
    partial class RadialGauges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            C1.Win.C1Gauge.C1GaugeCapCircle c1GaugeCapCircle3 = new C1.Win.C1Gauge.C1GaugeCapCircle();
            C1.Win.C1Gauge.C1GaugeCapCircle c1GaugeCapCircle4 = new C1.Win.C1Gauge.C1GaugeCapCircle();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment6 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment7 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse4 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange7 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange8 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange9 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange10 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks9 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks10 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels5 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSingleMark c1GaugeSingleMark1 = new C1.Win.C1Gauge.C1GaugeSingleMark();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse5 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse6 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse7 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse8 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse9 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse10 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment1 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment2 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange1 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks3 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks4 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels2 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector1 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector2 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector3 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector4 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment3 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels3 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange2 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks5 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks6 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeSingleLabel c1GaugeSingleLabel1 = new C1.Win.C1Gauge.C1GaugeSingleLabel();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse1 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse2 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeEllipse c1GaugeEllipse3 = new C1.Win.C1Gauge.C1GaugeEllipse();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle5 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle6 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle7 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeCapCircle c1GaugeCapCircle1 = new C1.Win.C1Gauge.C1GaugeCapCircle();
            C1.Win.C1Gauge.C1GaugeCapCircle c1GaugeCapCircle2 = new C1.Win.C1Gauge.C1GaugeCapCircle();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment4 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeSegment c1GaugeSegment5 = new C1.Win.C1Gauge.C1GaugeSegment();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange3 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange4 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange5 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeRange c1GaugeRange6 = new C1.Win.C1Gauge.C1GaugeRange();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks7 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks8 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels4 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector5 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector6 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector7 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector8 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeSector c1GaugeSector9 = new C1.Win.C1Gauge.C1GaugeSector();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle1 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle2 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle3 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption1 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeCaption c1GaugeCaption2 = new C1.Win.C1Gauge.C1GaugeCaption();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks1 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeMarks c1GaugeMarks2 = new C1.Win.C1Gauge.C1GaugeMarks();
            C1.Win.C1Gauge.C1GaugeLabels c1GaugeLabels1 = new C1.Win.C1Gauge.C1GaugeLabels();
            C1.Win.C1Gauge.C1GaugeRectangle c1GaugeRectangle4 = new C1.Win.C1Gauge.C1GaugeRectangle();
            C1.Win.C1Gauge.C1GaugeImage c1GaugeImage1 = new C1.Win.C1Gauge.C1GaugeImage();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RadialGauges));
            this.c1Gauge1 = new C1.Win.C1Gauge.C1Gauge();
            this.c1RadialGauge1 = new C1.Win.C1Gauge.C1RadialGauge();
            this.c1Gauge2 = new C1.Win.C1Gauge.C1Gauge();
            this.c1RadialGauge2 = new C1.Win.C1Gauge.C1RadialGauge();
            this.c1Gauge3 = new C1.Win.C1Gauge.C1Gauge();
            this.c1RadialGauge4 = new C1.Win.C1Gauge.C1RadialGauge();
            this.c1Gauge4 = new C1.Win.C1Gauge.C1Gauge();
            this.c1RadialGauge3 = new C1.Win.C1Gauge.C1RadialGauge();
            this.c1Gauge5 = new C1.Win.C1Gauge.C1Gauge();
            this.c1RadialGauge5 = new C1.Win.C1Gauge.C1RadialGauge();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // c1Gauge1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge1, 2);
            this.c1Gauge1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge1.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1RadialGauge1});
            this.c1Gauge1.Location = new System.Drawing.Point(3, 3);
            this.c1Gauge1.Name = "c1Gauge1";
            this.c1Gauge1.Size = new System.Drawing.Size(336, 367);
            this.c1Gauge1.TabIndex = 0;
            this.c1Gauge1.ViewTag = ((long)(650344890318900608));
            // 
            // c1RadialGauge1
            // 
            this.c1RadialGauge1.Cap.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(189)))), ((int)(((byte)(215)))));
            this.c1RadialGauge1.Cap.Border.Thickness = 0.5D;
            this.c1RadialGauge1.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1RadialGauge1.Cap.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(231)))), ((int)(((byte)(244)))));
            this.c1RadialGauge1.Cap.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(189)))), ((int)(((byte)(215)))));
            this.c1RadialGauge1.Cap.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeCapCircle3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeCapCircle3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(189)))), ((int)(((byte)(215)))));
            c1GaugeCapCircle3.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(236)))), ((int)(((byte)(245)))));
            c1GaugeCapCircle3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeCapCircle3.Radius = 8D;
            c1GaugeCapCircle4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeCapCircle4.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(231)))), ((int)(((byte)(244)))));
            c1GaugeCapCircle4.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(240)))));
            c1GaugeCapCircle4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeCapCircle4.Radius = 7.5D;
            this.c1RadialGauge1.Cap.MoreCircles.AddRange(new C1.Win.C1Gauge.C1GaugeCapCircle[] {
            c1GaugeCapCircle3,
            c1GaugeCapCircle4});
            this.c1RadialGauge1.Cap.Radius = 14D;
            this.c1RadialGauge1.Cap.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(70)))), ((int)(((byte)(154)))));
            this.c1RadialGauge1.Cap.Shadow.OffsetX = 1D;
            this.c1RadialGauge1.Cap.Shadow.Opacity = 0.4D;
            this.c1RadialGauge1.Cap.Shadow.Visible = true;
            c1GaugeSegment6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment6.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment6.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment6.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment6.Filling.Opacity = 0D;
            c1GaugeSegment6.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment6.InnerRadius = 150D;
            c1GaugeSegment6.OuterRadius = 97D;
            c1GaugeSegment6.StartAngle = -110D;
            c1GaugeSegment6.SweepAngle = 180D;
            c1GaugeSegment7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment7.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment7.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment7.Filling.HatchStyle = C1.Win.C1Gauge.C1GaugeHatchStyle.Horizontal;
            c1GaugeSegment7.Filling.Opacity = 0.3D;
            c1GaugeSegment7.Filling.Opacity2 = 0.1D;
            c1GaugeSegment7.InnerRadius = 15D;
            c1GaugeSegment7.OuterRadius = 7.5D;
            c1GaugeSegment7.StartAngle = -110D;
            c1GaugeSegment7.SweepAngle = 180D;
            c1GaugeEllipse4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse4.CenterPointY = 0.885D;
            c1GaugeEllipse4.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse4.Filling.Opacity = 0.3D;
            c1GaugeEllipse4.Height = 10D;
            c1GaugeEllipse4.Width = 10D;
            this.c1RadialGauge1.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment6,
            c1GaugeSegment7,
            c1GaugeEllipse4});
            c1GaugeRange7.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange7.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange7.Location = 97D;
            c1GaugeRange7.To = 60D;
            c1GaugeRange7.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(228)))), ((int)(((byte)(241))))), 1D, ((long)(652315215156005213))),
            new C1.Win.C1Gauge.C1GaugeValueColor(30D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(184)))), ((int)(((byte)(216))))), 1D, ((long)(652878165109426525)))});
            c1GaugeRange7.ViewTag = ((long)(651752265202583901));
            c1GaugeRange8.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange8.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange8.From = 60D;
            c1GaugeRange8.Location = 97D;
            c1GaugeRange8.To = 80D;
            c1GaugeRange8.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(60D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(133)))), ((int)(((byte)(62))))), 1D, ((long)(654004065016269149))),
            new C1.Win.C1Gauge.C1GaugeValueColor(70D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(99)))), ((int)(((byte)(42))))), 1D, ((long)(654567014969690461)))});
            c1GaugeRange8.ViewTag = ((long)(653441115062847837));
            c1GaugeRange9.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange9.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange9.From = 80D;
            c1GaugeRange9.Location = 97D;
            c1GaugeRange9.To = 100D;
            c1GaugeRange9.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(80D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(230)))), ((int)(((byte)(156))))), 1D, ((long)(655692914876533085))),
            new C1.Win.C1Gauge.C1GaugeValueColor(90D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(164)))), ((int)(((byte)(32))))), 1D, ((long)(656255864829954397)))});
            c1GaugeRange9.ViewTag = ((long)(655129964923111773));
            c1GaugeRange10.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange10.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange10.From = 100D;
            c1GaugeRange10.Location = 97D;
            c1GaugeRange10.To = 120D;
            c1GaugeRange10.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(100D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(100)))), ((int)(((byte)(62))))), 1D, ((long)(657381764736797021))),
            new C1.Win.C1Gauge.C1GaugeValueColor(110D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(38)))), ((int)(((byte)(32))))), 1D, ((long)(657944714690218333)))});
            c1GaugeRange10.ViewTag = ((long)(656818814783375709));
            c1GaugeMarks9.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks9.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks9.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(136)))), ((int)(((byte)(190)))));
            c1GaugeMarks9.Interval = 10D;
            c1GaugeMarks9.Length = 15D;
            c1GaugeMarks9.Location = 97D;
            c1GaugeMarks9.ViewTag = ((long)(658507664643639645));
            c1GaugeMarks9.Width = 2D;
            c1GaugeMarks10.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks10.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks10.Filling.Color = System.Drawing.Color.White;
            c1GaugeMarks10.Interval = 2.5D;
            c1GaugeMarks10.Length = 12D;
            c1GaugeMarks10.Location = 97D;
            c1GaugeMarks10.ViewTag = ((long)(659070614597060957));
            c1GaugeMarks10.Width = 1D;
            c1GaugeLabels5.AllowFlip = true;
            c1GaugeLabels5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(106)))), ((int)(((byte)(170)))));
            c1GaugeLabels5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            c1GaugeLabels5.FontSize = 12D;
            c1GaugeLabels5.Interval = 10D;
            c1GaugeLabels5.Location = 70D;
            c1GaugeLabels5.ViewTag = ((long)(659633564550482269));
            c1GaugeSingleMark1.Angle = 180D;
            c1GaugeSingleMark1.Border.Color = System.Drawing.Color.White;
            c1GaugeSingleMark1.Length = 18D;
            c1GaugeSingleMark1.Location = 80D;
            c1GaugeSingleMark1.PointerIndex = 100;
            c1GaugeSingleMark1.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark1.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(228)))), ((int)(((byte)(241))))), 1D, ((long)(660759464457344895))),
            new C1.Win.C1Gauge.C1GaugeValueColor(60D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(184)))), ((int)(((byte)(216))))), 1D, ((long)(661322414410766207))),
            new C1.Win.C1Gauge.C1GaugeValueColor(60D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(133)))), ((int)(((byte)(62))))), 1D, ((long)(661885364364187519))),
            new C1.Win.C1Gauge.C1GaugeValueColor(80D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(99)))), ((int)(((byte)(42))))), 1D, ((long)(662448314317608831))),
            new C1.Win.C1Gauge.C1GaugeValueColor(80D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(230)))), ((int)(((byte)(156))))), 1D, ((long)(663011264271030143))),
            new C1.Win.C1Gauge.C1GaugeValueColor(100D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(164)))), ((int)(((byte)(32))))), 1D, ((long)(663574214224451455))),
            new C1.Win.C1Gauge.C1GaugeValueColor(100D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(100)))), ((int)(((byte)(62))))), 1D, ((long)(664137164177872767))),
            new C1.Win.C1Gauge.C1GaugeValueColor(120D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(38)))), ((int)(((byte)(32))))), 1D, ((long)(664700114131294079)))});
            c1GaugeSingleMark1.ViewTag = ((long)(660196514503913582));
            c1GaugeSingleMark1.Width = 18D;
            this.c1RadialGauge1.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange7,
            c1GaugeRange8,
            c1GaugeRange9,
            c1GaugeRange10,
            c1GaugeMarks9,
            c1GaugeMarks10,
            c1GaugeLabels5,
            c1GaugeSingleMark1});
            c1GaugeEllipse5.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(178)))), ((int)(((byte)(227)))));
            c1GaugeEllipse5.Border.Thickness = 0.5D;
            c1GaugeEllipse5.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            c1GaugeEllipse5.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(145)))), ((int)(((byte)(205)))));
            c1GaugeEllipse5.Filling.HatchStyle = C1.Win.C1Gauge.C1GaugeHatchStyle.Horizontal;
            c1GaugeEllipse5.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse5.Height = -1.08D;
            c1GaugeEllipse5.Width = -1.08D;
            c1GaugeEllipse6.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(178)))), ((int)(((byte)(227)))));
            c1GaugeEllipse6.Border.Thickness = 0.5D;
            c1GaugeEllipse6.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse6.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(50)))), ((int)(((byte)(88)))));
            c1GaugeEllipse6.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(178)))), ((int)(((byte)(227)))));
            c1GaugeEllipse6.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse6.Height = -1.05D;
            c1GaugeEllipse6.Width = -1.05D;
            c1GaugeEllipse7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse7.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse7.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(184)))), ((int)(((byte)(216)))));
            c1GaugeEllipse7.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(228)))), ((int)(((byte)(241)))));
            c1GaugeEllipse7.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse7.Height = -1.02D;
            c1GaugeEllipse7.Width = -1.02D;
            c1GaugeEllipse8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse8.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse8.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(136)))), ((int)(((byte)(190)))));
            c1GaugeEllipse8.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(228)))), ((int)(((byte)(241)))));
            c1GaugeEllipse8.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse8.Height = -0.98D;
            c1GaugeEllipse8.Width = -0.98D;
            c1GaugeEllipse9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse9.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse9.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse9.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(228)))), ((int)(((byte)(241)))));
            c1GaugeEllipse9.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeEllipse9.Height = -0.97D;
            c1GaugeEllipse9.Width = -0.97D;
            c1GaugeEllipse10.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse10.CenterPointY = 0.9D;
            c1GaugeEllipse10.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse10.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(184)))), ((int)(((byte)(216)))));
            c1GaugeEllipse10.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(228)))), ((int)(((byte)(241)))));
            c1GaugeEllipse10.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse10.Height = 21D;
            c1GaugeEllipse10.Width = 21D;
            this.c1RadialGauge1.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse5,
            c1GaugeEllipse6,
            c1GaugeEllipse7,
            c1GaugeEllipse8,
            c1GaugeEllipse9,
            c1GaugeEllipse10});
            this.c1RadialGauge1.Maximum = 120D;
            this.c1RadialGauge1.Name = "c1RadialGauge1";
            this.c1RadialGauge1.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1RadialGauge1.Pointer.CustomShape.EndRadius = 1D;
            this.c1RadialGauge1.Pointer.CustomShape.EndWidth = 2D;
            this.c1RadialGauge1.Pointer.CustomShape.StartRadius = 3D;
            this.c1RadialGauge1.Pointer.CustomShape.StartWidth = 12D;
            this.c1RadialGauge1.Pointer.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1RadialGauge1.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1RadialGauge1.Pointer.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(207)))), ((int)(((byte)(153)))));
            this.c1RadialGauge1.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.BackwardDiagonal;
            this.c1RadialGauge1.Pointer.Length = 115D;
            this.c1RadialGauge1.Pointer.Offset = -25D;
            this.c1RadialGauge1.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(70)))), ((int)(((byte)(154)))));
            this.c1RadialGauge1.Pointer.Shadow.OffsetX = 1D;
            this.c1RadialGauge1.Pointer.Shadow.OffsetY = 1D;
            this.c1RadialGauge1.Pointer.Shadow.Opacity = 0.4D;
            this.c1RadialGauge1.Pointer.Shadow.Visible = true;
            this.c1RadialGauge1.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge1.Pointer.SweepTime = 3D;
            this.c1RadialGauge1.Pointer.Value = 70D;
            this.c1RadialGauge1.Radius = 0.45D;
            this.c1RadialGauge1.StartAngle = -130D;
            this.c1RadialGauge1.SweepAngle = 260D;
            this.c1RadialGauge1.ViewTag = ((long)(651189315249162589));
            // 
            // c1Gauge2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge2, 3);
            this.c1Gauge2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge2.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1RadialGauge2});
            this.c1Gauge2.Location = new System.Drawing.Point(345, 3);
            this.c1Gauge2.Name = "c1Gauge2";
            this.c1Gauge2.Size = new System.Drawing.Size(633, 367);
            this.c1Gauge2.TabIndex = 1;
            this.c1Gauge2.ViewTag = ((long)(638804372879744744));
            // 
            // c1RadialGauge2
            // 
            this.c1RadialGauge2.Cap.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(189)))), ((int)(((byte)(215)))));
            this.c1RadialGauge2.Cap.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.c1RadialGauge2.Cap.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1RadialGauge2.Cap.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            this.c1RadialGauge2.Cap.Radius = 6D;
            this.c1RadialGauge2.Cap.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1RadialGauge2.Cap.Shadow.Opacity = 0.15D;
            this.c1RadialGauge2.Cap.Shadow.Visible = true;
            c1GaugeSegment1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment1.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment1.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment1.Filling.Opacity = 0.2D;
            c1GaugeSegment1.Filling.Opacity2 = 0.8D;
            c1GaugeSegment1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment1.InnerRadius = 150D;
            c1GaugeSegment1.OuterRadius = 93D;
            c1GaugeSegment1.StartAngle = -90D;
            c1GaugeSegment1.SweepAngle = 150D;
            c1GaugeSegment2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment2.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment2.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment2.Filling.Opacity = 0.05D;
            c1GaugeSegment2.Filling.Opacity2 = 0.2D;
            c1GaugeSegment2.InnerRadius = 9D;
            c1GaugeSegment2.OuterRadius = 5D;
            c1GaugeSegment2.StartAngle = -110D;
            c1GaugeSegment2.SweepAngle = 180D;
            this.c1RadialGauge2.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment1,
            c1GaugeSegment2});
            c1GaugeRange1.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange1.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange1.From = 50D;
            c1GaugeRange1.Location = 62D;
            c1GaugeRange1.To = 100D;
            c1GaugeRange1.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(100D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(232)))), ((int)(((byte)(247))))), 1D, ((long)(645841247297811174))),
            new C1.Win.C1Gauge.C1GaugeValueColor(110D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(213)))), ((int)(((byte)(240))))), 1D, ((long)(646404197251232486)))});
            c1GaugeRange1.ViewTag = ((long)(645278297344389862));
            c1GaugeRange1.Width = 0D;
            c1GaugeRange1.Width2 = 12D;
            c1GaugeMarks3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeMarks3.Interval = 10D;
            c1GaugeMarks3.Length = 13D;
            c1GaugeMarks3.Location = 80D;
            c1GaugeMarks3.ViewTag = ((long)(646967147204663799));
            c1GaugeMarks3.Width = 1.5D;
            c1GaugeMarks4.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks4.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeMarks4.Filling.Opacity = 0.5D;
            c1GaugeMarks4.Interval = 1D;
            c1GaugeMarks4.Length = 8D;
            c1GaugeMarks4.Location = 80D;
            c1GaugeMarks4.ViewTag = ((long)(647530097158095112));
            c1GaugeMarks4.Width = 0.5D;
            c1GaugeLabels2.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeLabels2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            c1GaugeLabels2.FontSize = 8D;
            c1GaugeLabels2.Interval = 10D;
            c1GaugeLabels2.IsRotated = true;
            c1GaugeLabels2.Location = 81.5D;
            c1GaugeLabels2.ViewTag = ((long)(648093047111526425));
            this.c1RadialGauge2.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange1,
            c1GaugeMarks3,
            c1GaugeMarks4,
            c1GaugeLabels2});
            c1GaugeSector1.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(217)))), ((int)(((byte)(241)))));
            c1GaugeSector1.CenterRadius = 15D;
            c1GaugeSector1.CornerRadius = 3D;
            c1GaugeSector1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            c1GaugeSector1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(217)))), ((int)(((byte)(241)))));
            c1GaugeSector1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSector1.InnerRadius = -1D;
            c1GaugeSector1.OuterRadius = 102D;
            c1GaugeSector1.StartAngle = -90D;
            c1GaugeSector1.SweepAngle = 180D;
            c1GaugeSector2.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(189)))), ((int)(((byte)(215)))));
            c1GaugeSector2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector2.Border.Thickness = 0.5D;
            c1GaugeSector2.CenterRadius = 11D;
            c1GaugeSector2.CornerRadius = 2D;
            c1GaugeSector2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(154)))), ((int)(((byte)(171)))));
            c1GaugeSector2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(160)))), ((int)(((byte)(204)))));
            c1GaugeSector2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSector2.InnerRadius = -1D;
            c1GaugeSector2.OuterRadius = 98D;
            c1GaugeSector2.StartAngle = -90D;
            c1GaugeSector2.SweepAngle = 180D;
            c1GaugeSector3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector3.CornerRadius = 1D;
            c1GaugeSector3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector3.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            c1GaugeSector3.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(239)))), ((int)(((byte)(248)))));
            c1GaugeSector3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSector3.InnerRadius = -1D;
            c1GaugeSector3.OuterRadius = 97D;
            c1GaugeSector3.StartAngle = -90D;
            c1GaugeSector3.SweepAngle = 180D;
            c1GaugeSector4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector4.CenterRadius = 7D;
            c1GaugeSector4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector4.Filling.Color = System.Drawing.Color.White;
            c1GaugeSector4.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(227)))), ((int)(((byte)(240)))));
            c1GaugeSector4.Gradient.CenterPointX = 0.8D;
            c1GaugeSector4.Gradient.CenterPointY = 0.8D;
            c1GaugeSector4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialOuter;
            c1GaugeSector4.InnerRadius = -1D;
            c1GaugeSector4.OuterRadius = 94D;
            c1GaugeSector4.StartAngle = -90D;
            c1GaugeSector4.SweepAngle = 180D;
            this.c1RadialGauge2.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSector1,
            c1GaugeSector2,
            c1GaugeSector3,
            c1GaugeSector4});
            this.c1RadialGauge2.Name = "c1RadialGauge2";
            this.c1RadialGauge2.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1RadialGauge2.Pointer.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.c1RadialGauge2.Pointer.CustomShape.EndWidth = 4D;
            this.c1RadialGauge2.Pointer.CustomShape.StartWidth = 4D;
            this.c1RadialGauge2.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1RadialGauge2.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.BackwardDiagonal;
            this.c1RadialGauge2.Pointer.Length = 76D;
            this.c1RadialGauge2.Pointer.Offset = 0D;
            this.c1RadialGauge2.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(57)))), ((int)(((byte)(91)))));
            this.c1RadialGauge2.Pointer.Shadow.Opacity = 0.15D;
            this.c1RadialGauge2.Pointer.Shadow.Visible = true;
            this.c1RadialGauge2.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge2.Pointer.SweepTime = 2D;
            this.c1RadialGauge2.Pointer.Value = 88D;
            this.c1RadialGauge2.PointerOriginY = 0.8D;
            this.c1RadialGauge2.Radius = 0.7D;
            this.c1RadialGauge2.StartAngle = -90D;
            this.c1RadialGauge2.SweepAngle = 180D;
            this.c1RadialGauge2.Viewport.AspectRatio = 1.5D;
            this.c1RadialGauge2.ViewTag = ((long)(639648797810046729));
            // 
            // c1Gauge3
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge3, 2);
            this.c1Gauge3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge3.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1RadialGauge4});
            this.c1Gauge3.Location = new System.Drawing.Point(345, 376);
            this.c1Gauge3.Name = "c1Gauge3";
            this.c1Gauge3.Size = new System.Drawing.Size(336, 367);
            this.c1Gauge3.TabIndex = 2;
            this.c1Gauge3.ViewTag = ((long)(644999700835737836));
            // 
            // c1RadialGauge4
            // 
            this.c1RadialGauge4.Cap.Border.Color = System.Drawing.Color.DimGray;
            this.c1RadialGauge4.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1RadialGauge4.Cap.Filling.Color = System.Drawing.Color.White;
            this.c1RadialGauge4.Cap.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c1RadialGauge4.Cap.Radius = 15D;
            this.c1RadialGauge4.Cap.Shadow.Visible = true;
            c1GaugeSegment3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment3.Filling.Color = System.Drawing.Color.White;
            c1GaugeSegment3.Filling.Color2 = System.Drawing.Color.CornflowerBlue;
            c1GaugeSegment3.Filling.Opacity = 0.6D;
            c1GaugeSegment3.Filling.Opacity2 = 0.1D;
            c1GaugeSegment3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment3.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeSegment3.InnerRadius = 130D;
            c1GaugeSegment3.SweepAngle = 190D;
            this.c1RadialGauge4.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment3});
            c1GaugeLabels3.AllowFlip = true;
            c1GaugeLabels3.FontSize = 10D;
            c1GaugeLabels3.Interval = 10D;
            c1GaugeLabels3.Location = 90D;
            c1GaugeLabels3.ViewTag = ((long)(646407075719291116));
            c1GaugeRange2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange2.Location = 70D;
            c1GaugeRange2.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, -1, System.Drawing.Color.Firebrick, 1D, ((long)(647532975626133740))),
            new C1.Win.C1Gauge.C1GaugeValueColor(30D, -1, System.Drawing.Color.Yellow, 1D, ((long)(648095925579555052))),
            new C1.Win.C1Gauge.C1GaugeValueColor(70D, -1, System.Drawing.Color.LimeGreen, 1D, ((long)(648658875532976364)))});
            c1GaugeRange2.ViewTag = ((long)(646970025672712428));
            c1GaugeRange2.Width = 20D;
            c1GaugeMarks5.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks5.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks5.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks5.Interval = 10D;
            c1GaugeMarks5.Length = 20D;
            c1GaugeMarks5.Location = 60D;
            c1GaugeMarks5.ViewTag = ((long)(649221825486397676));
            c1GaugeMarks5.Width = 1D;
            c1GaugeMarks6.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks6.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks6.Filling.Color = System.Drawing.Color.Black;
            c1GaugeMarks6.Interval = 2.5D;
            c1GaugeMarks6.Length = 10D;
            c1GaugeMarks6.Location = 70D;
            c1GaugeMarks6.ViewTag = ((long)(649784775439818988));
            c1GaugeMarks6.Width = 1D;
            c1GaugeSingleLabel1.Angle = 180D;
            c1GaugeSingleLabel1.Font = new System.Drawing.Font("Courier New", 8.25F);
            c1GaugeSingleLabel1.FontSize = 20D;
            c1GaugeSingleLabel1.Format = "0##";
            c1GaugeSingleLabel1.PointerIndex = 1;
            c1GaugeSingleLabel1.ViewTag = ((long)(650347725393240300));
            this.c1RadialGauge4.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeLabels3,
            c1GaugeRange2,
            c1GaugeMarks5,
            c1GaugeMarks6,
            c1GaugeSingleLabel1});
            c1GaugeEllipse1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse1.Filling.Color = System.Drawing.Color.DimGray;
            c1GaugeEllipse1.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeEllipse1.Filling.SwapColors = true;
            c1GaugeEllipse1.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeEllipse1.Height = -1.08D;
            c1GaugeEllipse1.Width = -1.08D;
            c1GaugeEllipse2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse2.Filling.Color = System.Drawing.Color.White;
            c1GaugeEllipse2.Filling.Color2 = System.Drawing.Color.DimGray;
            c1GaugeEllipse2.Filling.SwapColors = true;
            c1GaugeEllipse2.Height = -1.02D;
            c1GaugeEllipse2.Width = -1.02D;
            c1GaugeEllipse3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeEllipse3.Filling.Color = System.Drawing.Color.Silver;
            c1GaugeEllipse3.Filling.Color2 = System.Drawing.Color.Gray;
            c1GaugeEllipse3.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeEllipse3.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeEllipse3.Gradient.Focus = 0.08D;
            c1GaugeRectangle5.Border.Color = System.Drawing.Color.DimGray;
            c1GaugeRectangle5.CenterPointX = 0.435D;
            c1GaugeRectangle5.CenterPointY = 0.815D;
            c1GaugeRectangle5.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle5.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeRectangle5.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeRectangle5.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle5.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRectangle5.Height = 20D;
            c1GaugeRectangle5.Width = 13D;
            c1GaugeRectangle6.Border.Color = System.Drawing.Color.DimGray;
            c1GaugeRectangle6.CenterPointY = 0.815D;
            c1GaugeRectangle6.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle6.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeRectangle6.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeRectangle6.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle6.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRectangle6.Height = 20D;
            c1GaugeRectangle6.Width = 13D;
            c1GaugeRectangle7.Border.Color = System.Drawing.Color.DimGray;
            c1GaugeRectangle7.CenterPointX = 0.565D;
            c1GaugeRectangle7.CenterPointY = 0.815D;
            c1GaugeRectangle7.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle7.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeRectangle7.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeRectangle7.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeRectangle7.Gradient.Falloff = C1.Win.C1Gauge.C1GaugeGradientFalloff.Triangular;
            c1GaugeRectangle7.Height = 20D;
            c1GaugeRectangle7.Width = 13D;
            this.c1RadialGauge4.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeEllipse1,
            c1GaugeEllipse2,
            c1GaugeEllipse3,
            c1GaugeRectangle5,
            c1GaugeRectangle6,
            c1GaugeRectangle7});
            this.c1RadialGauge4.Name = "c1RadialGauge4";
            this.c1RadialGauge4.Pointer.Border.Color = System.Drawing.Color.DimGray;
            this.c1RadialGauge4.Pointer.Filling.Color = System.Drawing.Color.Gainsboro;
            this.c1RadialGauge4.Pointer.Filling.HatchStyle = C1.Win.C1Gauge.C1GaugeHatchStyle.Wave;
            this.c1RadialGauge4.Pointer.Length = 80D;
            this.c1RadialGauge4.Pointer.Offset = 0D;
            this.c1RadialGauge4.Pointer.Shadow.Visible = true;
            this.c1RadialGauge4.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Triangle;
            this.c1RadialGauge4.Pointer.SweepTime = 4D;
            this.c1RadialGauge4.Pointer.Value = 45D;
            this.c1RadialGauge4.Pointer.Width = 10D;
            this.c1RadialGauge4.Radius = 0.45D;
            this.c1RadialGauge4.StartAngle = -120D;
            this.c1RadialGauge4.SweepAngle = 240D;
            this.c1RadialGauge4.ViewTag = ((long)(645844125765869804));
            // 
            // c1Gauge4
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge4, 2);
            this.c1Gauge4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge4.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1RadialGauge3});
            this.c1Gauge4.Location = new System.Drawing.Point(3, 376);
            this.c1Gauge4.Name = "c1Gauge4";
            this.c1Gauge4.Size = new System.Drawing.Size(336, 367);
            this.c1Gauge4.TabIndex = 3;
            this.c1Gauge4.ViewTag = ((long)(683840423864400252));
            // 
            // c1RadialGauge3
            // 
            this.c1RadialGauge3.Cap.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(117)))), ((int)(((byte)(117)))));
            this.c1RadialGauge3.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1RadialGauge3.Cap.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(84)))), ((int)(((byte)(83)))));
            this.c1RadialGauge3.Cap.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(80)))), ((int)(((byte)(89)))));
            this.c1RadialGauge3.Cap.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeCapCircle1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeCapCircle1.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeCapCircle1.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(170)))), ((int)(((byte)(171)))));
            c1GaugeCapCircle1.Radius = 4.5D;
            c1GaugeCapCircle2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeCapCircle2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(80)))), ((int)(((byte)(89)))));
            c1GaugeCapCircle2.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeCapCircle2.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeCapCircle2.Radius = 4.25D;
            this.c1RadialGauge3.Cap.MoreCircles.AddRange(new C1.Win.C1Gauge.C1GaugeCapCircle[] {
            c1GaugeCapCircle1,
            c1GaugeCapCircle2});
            this.c1RadialGauge3.Cap.Radius = 8D;
            this.c1RadialGauge3.Cap.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(89)))));
            this.c1RadialGauge3.Cap.Shadow.Opacity = 0.4D;
            this.c1RadialGauge3.Cap.Shadow.Visible = true;
            c1GaugeSegment4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment4.Clippings.AddRange(new C1.Win.C1Gauge.C1GaugeClipping[] {
            new C1.Win.C1Gauge.C1GaugeClipping("Face", C1.Win.C1Gauge.C1GaugeClipOperation.Intersect, 1D)});
            c1GaugeSegment4.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment4.Filling.Color = System.Drawing.Color.Transparent;
            c1GaugeSegment4.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment4.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment4.InnerRadius = 140D;
            c1GaugeSegment4.StartAngle = -90D;
            c1GaugeSegment4.SweepAngle = 150D;
            c1GaugeSegment5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSegment5.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSegment5.Filling.Color = System.Drawing.Color.Transparent;
            c1GaugeSegment5.Filling.Color2 = System.Drawing.Color.White;
            c1GaugeSegment5.Filling.Opacity = 0.1D;
            c1GaugeSegment5.Filling.Opacity2 = 0.1D;
            c1GaugeSegment5.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSegment5.InnerRadius = 15D;
            c1GaugeSegment5.OuterRadius = 4D;
            c1GaugeSegment5.StartAngle = -110D;
            c1GaugeSegment5.SweepAngle = 180D;
            this.c1RadialGauge3.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSegment4,
            c1GaugeSegment5});
            c1GaugeRange3.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange3.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange3.Location = 80D;
            c1GaugeRange3.To = 60D;
            c1GaugeRange3.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(0D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(191)))), ((int)(((byte)(200))))), 1D, ((long)(685810748701544861))),
            new C1.Win.C1Gauge.C1GaugeValueColor(30D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(170)))), ((int)(((byte)(171))))), 1D, ((long)(686373698654966173)))});
            c1GaugeRange3.ViewTag = ((long)(685247798748123549));
            c1GaugeRange3.Width = 8D;
            c1GaugeRange4.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange4.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange4.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange4.From = 60D;
            c1GaugeRange4.Location = 80D;
            c1GaugeRange4.To = 80D;
            c1GaugeRange4.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(60D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(133)))), ((int)(((byte)(62))))), 1D, ((long)(687499598561808797))),
            new C1.Win.C1Gauge.C1GaugeValueColor(70D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(99)))), ((int)(((byte)(42))))), 1D, ((long)(688062548515230109)))});
            c1GaugeRange4.ViewTag = ((long)(686936648608387485));
            c1GaugeRange4.Width = 8D;
            c1GaugeRange5.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange5.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange5.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange5.From = 80D;
            c1GaugeRange5.Location = 80D;
            c1GaugeRange5.To = 100D;
            c1GaugeRange5.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(80D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(230)))), ((int)(((byte)(156))))), 1D, ((long)(689188448422072733))),
            new C1.Win.C1Gauge.C1GaugeValueColor(90D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(164)))), ((int)(((byte)(32))))), 1D, ((long)(689751398375494045)))});
            c1GaugeRange5.ViewTag = ((long)(688625498468651421));
            c1GaugeRange5.Width = 8D;
            c1GaugeRange6.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeRange6.AntiAliasing = C1.Win.C1Gauge.C1GaugeRangeAntiAliasing.HighQuality;
            c1GaugeRange6.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange6.From = 100D;
            c1GaugeRange6.Location = 80D;
            c1GaugeRange6.ValueColors.AddRange(new C1.Win.C1Gauge.C1GaugeValueColor[] {
            new C1.Win.C1Gauge.C1GaugeValueColor(100D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(100)))), ((int)(((byte)(62))))), 1D, ((long)(690877298282336669))),
            new C1.Win.C1Gauge.C1GaugeValueColor(110D, 100, System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(38)))), ((int)(((byte)(32))))), 1D, ((long)(691440248235757981)))});
            c1GaugeRange6.ViewTag = ((long)(690314348328915357));
            c1GaugeRange6.Width = 8D;
            c1GaugeMarks7.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks7.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(83)))), ((int)(((byte)(83)))));
            c1GaugeMarks7.Interval = 20D;
            c1GaugeMarks7.Length = 10D;
            c1GaugeMarks7.Location = 82D;
            c1GaugeMarks7.ViewTag = ((long)(692003198189179293));
            c1GaugeMarks7.Width = 1.5D;
            c1GaugeMarks8.Alignment = C1.Win.C1Gauge.C1GaugeAlignment.In;
            c1GaugeMarks8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks8.Interval = 5D;
            c1GaugeMarks8.Length = 8D;
            c1GaugeMarks8.Location = 80D;
            c1GaugeMarks8.ViewTag = ((long)(692566148142600605));
            c1GaugeMarks8.Width = 1D;
            c1GaugeLabels4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(89)))));
            c1GaugeLabels4.FontSize = 7D;
            c1GaugeLabels4.Interval = 20D;
            c1GaugeLabels4.Location = 88D;
            c1GaugeLabels4.ViewTag = ((long)(693129098096021917));
            this.c1RadialGauge3.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeRange3,
            c1GaugeRange4,
            c1GaugeRange5,
            c1GaugeRange6,
            c1GaugeMarks7,
            c1GaugeMarks8,
            c1GaugeLabels4});
            c1GaugeSector5.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeSector5.CenterRadius = 17D;
            c1GaugeSector5.CornerRadius = 14D;
            c1GaugeSector5.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(84)))), ((int)(((byte)(83)))));
            c1GaugeSector5.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeSector5.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSector5.InnerRadius = -22D;
            c1GaugeSector5.OuterRadius = 102D;
            c1GaugeSector5.StartAngle = -90D;
            c1GaugeSector5.SweepAngle = 90D;
            c1GaugeSector6.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(84)))), ((int)(((byte)(83)))));
            c1GaugeSector6.Border.Thickness = 0.5D;
            c1GaugeSector6.CenterRadius = 15D;
            c1GaugeSector6.CornerRadius = 12D;
            c1GaugeSector6.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector6.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(45)))));
            c1GaugeSector6.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(80)))), ((int)(((byte)(89)))));
            c1GaugeSector6.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSector6.StartAngle = -90D;
            c1GaugeSector6.SweepAngle = 90D;
            c1GaugeSector7.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector7.CenterRadius = 13.5D;
            c1GaugeSector7.CornerRadius = 10D;
            c1GaugeSector7.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector7.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(191)))), ((int)(((byte)(200)))));
            c1GaugeSector7.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(211)))), ((int)(((byte)(218)))));
            c1GaugeSector7.InnerRadius = -18.5D;
            c1GaugeSector7.OuterRadius = 98.5D;
            c1GaugeSector7.StartAngle = -90D;
            c1GaugeSector7.SweepAngle = 90D;
            c1GaugeSector8.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector8.CenterRadius = 11D;
            c1GaugeSector8.CornerRadius = 8D;
            c1GaugeSector8.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector8.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(84)))), ((int)(((byte)(83)))));
            c1GaugeSector8.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            c1GaugeSector8.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.Vertical;
            c1GaugeSector8.InnerRadius = -16D;
            c1GaugeSector8.OuterRadius = 96D;
            c1GaugeSector8.StartAngle = -90D;
            c1GaugeSector8.SweepAngle = 90D;
            c1GaugeSector9.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeSector9.CenterRadius = 10.5D;
            c1GaugeSector9.CornerRadius = 7.5D;
            c1GaugeSector9.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeSector9.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(245)))));
            c1GaugeSector9.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(191)))), ((int)(((byte)(200)))));
            c1GaugeSector9.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeSector9.InnerRadius = -15.5D;
            c1GaugeSector9.Name = "Face";
            c1GaugeSector9.OuterRadius = 95.5D;
            c1GaugeSector9.StartAngle = -90D;
            c1GaugeSector9.SweepAngle = 90D;
            this.c1RadialGauge3.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeSector5,
            c1GaugeSector6,
            c1GaugeSector7,
            c1GaugeSector8,
            c1GaugeSector9});
            this.c1RadialGauge3.Maximum = 120D;
            this.c1RadialGauge3.Name = "c1RadialGauge3";
            this.c1RadialGauge3.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1RadialGauge3.Pointer.CustomShape.EndRadius = 1D;
            this.c1RadialGauge3.Pointer.CustomShape.EndWidth = 2D;
            this.c1RadialGauge3.Pointer.CustomShape.StartRadius = 2D;
            this.c1RadialGauge3.Pointer.CustomShape.StartWidth = 7D;
            this.c1RadialGauge3.Pointer.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1RadialGauge3.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(90)))), ((int)(((byte)(40)))));
            this.c1RadialGauge3.Pointer.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(207)))), ((int)(((byte)(153)))));
            this.c1RadialGauge3.Pointer.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.BackwardDiagonal;
            this.c1RadialGauge3.Pointer.Offset = -13D;
            this.c1RadialGauge3.Pointer.Shadow.Color = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(80)))), ((int)(((byte)(89)))));
            this.c1RadialGauge3.Pointer.Shadow.Opacity = 0.4D;
            this.c1RadialGauge3.Pointer.Shadow.Visible = true;
            this.c1RadialGauge3.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge3.Pointer.Value = 25D;
            this.c1RadialGauge3.PointerOriginX = 0.8D;
            this.c1RadialGauge3.PointerOriginY = 0.8D;
            this.c1RadialGauge3.Radius = 0.76D;
            this.c1RadialGauge3.StartAngle = -90D;
            this.c1RadialGauge3.SweepAngle = 90D;
            this.c1RadialGauge3.Viewport.AspectRatio = 1D;
            this.c1RadialGauge3.ViewTag = ((long)(684684848794702237));
            // 
            // c1Gauge5
            // 
            this.c1Gauge5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge5.Gauges.AddRange(new C1.Win.C1Gauge.C1GaugeBase[] {
            this.c1RadialGauge5});
            this.c1Gauge5.Location = new System.Drawing.Point(687, 376);
            this.c1Gauge5.Name = "c1Gauge5";
            this.c1Gauge5.Size = new System.Drawing.Size(291, 367);
            this.c1Gauge5.TabIndex = 4;
            this.c1Gauge5.ViewTag = ((long)(750552744159329021));
            // 
            // c1RadialGauge5
            // 
            this.c1RadialGauge5.Cap.BehindPointers = true;
            this.c1RadialGauge5.Cap.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            this.c1RadialGauge5.Cap.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            this.c1RadialGauge5.Cap.Filling.Color = System.Drawing.Color.Silver;
            this.c1RadialGauge5.Cap.Filling.Color2 = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c1RadialGauge5.Cap.Gradient.Direction = C1.Win.C1Gauge.C1GaugeGradientDirection.RadialInner;
            c1GaugeRectangle1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle1.CenterPointX = 0.7D;
            c1GaugeRectangle1.CornerRadius = 5D;
            c1GaugeRectangle1.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle1.Filling.Color = System.Drawing.Color.White;
            c1GaugeRectangle1.Filling.Color2 = System.Drawing.Color.Transparent;
            c1GaugeRectangle1.Filling.Opacity = 0.2D;
            c1GaugeRectangle1.Filling.Opacity2 = 0D;
            c1GaugeRectangle1.Gradient.ScaleX = 0.4D;
            c1GaugeRectangle1.Gradient.ScaleY = 0.5D;
            c1GaugeRectangle1.Height = -0.99D;
            c1GaugeRectangle1.Width = -0.7D;
            c1GaugeRectangle2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle2.CenterPointX = 0.7D;
            c1GaugeRectangle2.CornerRadius = 5D;
            c1GaugeRectangle2.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle2.Filling.Color = System.Drawing.Color.White;
            c1GaugeRectangle2.Filling.Color2 = System.Drawing.Color.Transparent;
            c1GaugeRectangle2.Filling.Opacity = 0.2D;
            c1GaugeRectangle2.Filling.Opacity2 = 0D;
            c1GaugeRectangle2.Gradient.ScaleX = 0.8D;
            c1GaugeRectangle2.Gradient.TranslateX = -0.1D;
            c1GaugeRectangle2.Height = -0.99D;
            c1GaugeRectangle2.Width = -0.7D;
            c1GaugeRectangle3.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeRectangle3.CenterPointX = 0.7D;
            c1GaugeRectangle3.CornerRadius = 5D;
            c1GaugeRectangle3.Filling.BrushType = C1.Win.C1Gauge.C1GaugeBrushType.Gradient;
            c1GaugeRectangle3.Filling.Color = System.Drawing.Color.White;
            c1GaugeRectangle3.Filling.Color2 = System.Drawing.Color.Transparent;
            c1GaugeRectangle3.Filling.Opacity = 0.2D;
            c1GaugeRectangle3.Filling.Opacity2 = 0D;
            c1GaugeRectangle3.Gradient.ScaleX = 0.3D;
            c1GaugeRectangle3.Gradient.ScaleY = 0.35D;
            c1GaugeRectangle3.Gradient.TranslateX = 0.6D;
            c1GaugeRectangle3.Height = -0.99D;
            c1GaugeRectangle3.Visible = false;
            c1GaugeRectangle3.Width = -0.7D;
            c1GaugeCaption1.CenterPointX = 0.45D;
            c1GaugeCaption1.CenterPointY = 0.1D;
            c1GaugeCaption1.Color = System.Drawing.Color.Gray;
            c1GaugeCaption1.FontSize = 14D;
            c1GaugeCaption1.Text = "F";
            c1GaugeCaption2.CenterPointX = 0.45D;
            c1GaugeCaption2.CenterPointY = 0.9D;
            c1GaugeCaption2.Color = System.Drawing.Color.Gray;
            c1GaugeCaption2.FontSize = 14D;
            c1GaugeCaption2.Text = "E";
            this.c1RadialGauge5.CoverShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle1,
            c1GaugeRectangle2,
            c1GaugeRectangle3,
            c1GaugeCaption1,
            c1GaugeCaption2});
            c1GaugeMarks1.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks1.CustomShape.StartWidth = 2D;
            c1GaugeMarks1.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeMarks1.Interval = 20D;
            c1GaugeMarks1.Location = 78D;
            c1GaugeMarks1.Shape = C1.Win.C1Gauge.C1GaugeMarkShape.Custom;
            c1GaugeMarks1.ViewTag = ((long)(751960119043012314));
            c1GaugeMarks2.Border.LineStyle = C1.Win.C1Gauge.C1GaugeBorderStyle.None;
            c1GaugeMarks2.Filling.Color = System.Drawing.Color.Gray;
            c1GaugeMarks2.Interval = 5D;
            c1GaugeMarks2.Length = 3D;
            c1GaugeMarks2.Location = 78D;
            c1GaugeMarks2.ViewTag = ((long)(752523068996433626));
            c1GaugeMarks2.Width = 3D;
            c1GaugeLabels1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeLabels1.FontSize = 8D;
            c1GaugeLabels1.Interval = 20D;
            c1GaugeLabels1.Location = 92D;
            c1GaugeLabels1.ViewTag = ((long)(753086018949854938));
            this.c1RadialGauge5.Decorators.AddRange(new C1.Win.C1Gauge.C1GaugeDecorator[] {
            c1GaugeMarks1,
            c1GaugeMarks2,
            c1GaugeLabels1});
            c1GaugeRectangle4.Border.Color = System.Drawing.Color.DarkGray;
            c1GaugeRectangle4.Border.Thickness = 3D;
            c1GaugeRectangle4.CenterPointX = 0.7D;
            c1GaugeRectangle4.CornerRadius = 5D;
            c1GaugeRectangle4.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            c1GaugeRectangle4.Width = -0.7D;
            c1GaugeImage1.CenterPointX = 0.69D;
            c1GaugeImage1.Height = -0.15D;
            c1GaugeImage1.Image = ((System.Drawing.Image)(resources.GetObject("c1GaugeImage1.Image")));
            this.c1RadialGauge5.FaceShapes.AddRange(new C1.Win.C1Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle4,
            c1GaugeImage1});
            this.c1RadialGauge5.IsReversed = true;
            this.c1RadialGauge5.Name = "c1RadialGauge5";
            this.c1RadialGauge5.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.c1RadialGauge5.Pointer.CustomShape.EndWidth = 2D;
            this.c1RadialGauge5.Pointer.CustomShape.StartWidth = 6D;
            this.c1RadialGauge5.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.c1RadialGauge5.Pointer.Length = 100D;
            this.c1RadialGauge5.Pointer.Shadow.Visible = true;
            this.c1RadialGauge5.Pointer.Shape = C1.Win.C1Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge5.Pointer.SweepTime = 3D;
            this.c1RadialGauge5.Pointer.Value = 78D;
            this.c1RadialGauge5.PointerOriginX = 0.2D;
            this.c1RadialGauge5.Radius = 0.75D;
            this.c1RadialGauge5.StartAngle = 5D;
            this.c1RadialGauge5.SweepAngle = 170D;
            this.c1RadialGauge5.Viewport.AspectRatio = 0.6D;
            this.c1RadialGauge5.Viewport.MarginX = 5;
            this.c1RadialGauge5.ViewTag = ((long)(751397169089591002));
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge5, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge4, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(981, 746);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // RadialGauges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 746);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "RadialGauges";
            this.Text = "RadialGauges";
            this.Load += new System.EventHandler(this.RadialGauges_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1Gauge.C1Gauge c1Gauge1;
        private C1.Win.C1Gauge.C1Gauge c1Gauge2;
        private C1.Win.C1Gauge.C1RadialGauge c1RadialGauge2;
        private C1.Win.C1Gauge.C1Gauge c1Gauge3;
        private C1.Win.C1Gauge.C1RadialGauge c1RadialGauge4;
        private C1.Win.C1Gauge.C1Gauge c1Gauge4;
        private C1.Win.C1Gauge.C1RadialGauge c1RadialGauge3;
        private C1.Win.C1Gauge.C1Gauge c1Gauge5;
        private C1.Win.C1Gauge.C1RadialGauge c1RadialGauge5;
        private System.Windows.Forms.Timer timer1;
        private C1.Win.C1Gauge.C1RadialGauge c1RadialGauge1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}