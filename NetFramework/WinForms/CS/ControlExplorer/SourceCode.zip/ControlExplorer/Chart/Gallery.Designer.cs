﻿namespace ControlExplorer.Chart
{
    partial class Gallery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Gallery));
            C1.Win.C1Command.C1TopicPage c1TopicPage1 = new C1.Win.C1Command.C1TopicPage();
            C1.Win.C1Command.C1TopicLink c1TopicLink1 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink2 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink3 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink4 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink5 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink6 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink7 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink8 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink9 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink10 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink11 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink12 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicPage c1TopicPage2 = new C1.Win.C1Command.C1TopicPage();
            C1.Win.C1Command.C1TopicLink c1TopicLink13 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink14 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink15 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink16 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink17 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink18 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicPage c1TopicPage3 = new C1.Win.C1Command.C1TopicPage();
            C1.Win.C1Command.C1TopicLink c1TopicLink19 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink20 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink21 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink22 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink23 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink24 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink25 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink26 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink27 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicPage c1TopicPage4 = new C1.Win.C1Command.C1TopicPage();
            C1.Win.C1Command.C1TopicLink c1TopicLink28 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink29 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink30 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink31 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink32 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink33 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink34 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink35 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink36 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink37 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicPage c1TopicPage5 = new C1.Win.C1Command.C1TopicPage();
            C1.Win.C1Command.C1TopicLink c1TopicLink38 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink39 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink40 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink41 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink42 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink43 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink44 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink45 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink46 = new C1.Win.C1Command.C1TopicLink();
            C1.Win.C1Command.C1TopicLink c1TopicLink47 = new C1.Win.C1Command.C1TopicLink();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.categorySales1 = new ControlExplorer.Chart.CategorySales();
            this.c1Chart1 = new C1.Win.C1Chart.C1Chart();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.c1TopicBar1 = new C1.Win.C1Command.C1TopicBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboPalette = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.categorySales1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1TopicBar1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "ChartLine.png");
            this.imageList1.Images.SetKeyName(1, "ChartArea.png");
            this.imageList1.Images.SetKeyName(2, "ChartBar.png");
            this.imageList1.Images.SetKeyName(3, "Chart.png");
            this.imageList1.Images.SetKeyName(4, "ChartPie.png");
            this.imageList1.Images.SetKeyName(5, "XYScatter.png");
            // 
            // categorySales1
            // 
            this.categorySales1.Position = 0;
            // 
            // c1Chart1
            // 
            this.c1Chart1.BackColor = System.Drawing.SystemColors.Control;
            this.c1Chart1.DataSource = this.categorySales1;
            this.c1Chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Chart1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.c1Chart1.Interaction.Enabled = true;
            this.c1Chart1.Location = new System.Drawing.Point(0, 0);
            this.c1Chart1.Name = "c1Chart1";
            this.c1Chart1.PropBag = resources.GetString("c1Chart1.PropBag");
            this.c1Chart1.Size = new System.Drawing.Size(426, 446);
            this.c1Chart1.TabIndex = 1;
            this.c1Chart1.ToolTip.Enabled = true;
            this.c1Chart1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.c1Chart1_MouseMove);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.c1TopicBar1);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.c1Chart1);
            this.splitContainer1.Size = new System.Drawing.Size(592, 446);
            this.splitContainer1.SplitterDistance = 162;
            this.splitContainer1.TabIndex = 2;
            // 
            // c1TopicBar1
            // 
            this.c1TopicBar1.Animation = C1.Win.C1Command.C1AnimationEnum.On;
            this.c1TopicBar1.AutoScrollMinSize = new System.Drawing.Size(0, 170);
            this.c1TopicBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1TopicBar1.ImageList = this.imageList1;
            this.c1TopicBar1.Location = new System.Drawing.Point(0, 34);
            this.c1TopicBar1.Name = "c1TopicBar1";
            this.c1TopicBar1.Padding = new System.Windows.Forms.Padding(5);
            this.c1TopicBar1.PageOffset = 10;
            this.c1TopicBar1.PagePadding = new System.Windows.Forms.Padding(15, 5, 5, 5);
            c1TopicPage1.Collapsed = true;
            c1TopicPage1.ImageIndex = 0;
            c1TopicLink1.Tag = "line.default";
            c1TopicLink1.Text = "Default";
            c1TopicLink2.Tag = "line.stacked";
            c1TopicLink2.Text = "Stacked";
            c1TopicLink3.Tag = "line.bezier";
            c1TopicLink3.Text = "Bezier";
            c1TopicLink4.Tag = "line.spline";
            c1TopicLink4.Text = "Spline";
            c1TopicLink5.Tag = "line.splinestacked";
            c1TopicLink5.Text = "Spline Stacked";
            c1TopicLink6.Tag = "line.3d";
            c1TopicLink6.Text = "3D";
            c1TopicLink7.Tag = "line.3dstacked";
            c1TopicLink7.Text = "3D Stacked";
            c1TopicLink8.Tag = "line.linesandsymbols";
            c1TopicLink8.Text = "Lines and Symbols";
            c1TopicLink9.Tag = "line.symbolsonly";
            c1TopicLink9.Text = "Symbols Only";
            c1TopicLink10.Tag = "line.step";
            c1TopicLink10.Text = "Step";
            c1TopicLink11.Tag = "line.stepandsymbols";
            c1TopicLink11.Text = "Step and Symbols";
            c1TopicLink12.Tag = "line.3dstep";
            c1TopicLink12.Text = "3D Step";
            c1TopicPage1.Links.Add(c1TopicLink1);
            c1TopicPage1.Links.Add(c1TopicLink2);
            c1TopicPage1.Links.Add(c1TopicLink3);
            c1TopicPage1.Links.Add(c1TopicLink4);
            c1TopicPage1.Links.Add(c1TopicLink5);
            c1TopicPage1.Links.Add(c1TopicLink6);
            c1TopicPage1.Links.Add(c1TopicLink7);
            c1TopicPage1.Links.Add(c1TopicLink8);
            c1TopicPage1.Links.Add(c1TopicLink9);
            c1TopicPage1.Links.Add(c1TopicLink10);
            c1TopicPage1.Links.Add(c1TopicLink11);
            c1TopicPage1.Links.Add(c1TopicLink12);
            c1TopicPage1.Tag = "";
            c1TopicPage1.Text = "Line Charts";
            c1TopicPage2.Collapsed = true;
            c1TopicPage2.ImageIndex = 1;
            c1TopicLink13.Tag = "area.default";
            c1TopicLink13.Text = "Default";
            c1TopicLink14.Tag = "area.stacked";
            c1TopicLink14.Text = "Stacked";
            c1TopicLink15.Tag = "area.stacked100pc";
            c1TopicLink15.Text = "Stacked 100%";
            c1TopicLink16.Tag = "area.3d";
            c1TopicLink16.Text = "3D";
            c1TopicLink17.Tag = "area.3dstacked";
            c1TopicLink17.Text = "3D Stacked";
            c1TopicLink18.Tag = "area.3dstacked100pc";
            c1TopicLink18.Text = "3D Stacked 100%";
            c1TopicPage2.Links.Add(c1TopicLink13);
            c1TopicPage2.Links.Add(c1TopicLink14);
            c1TopicPage2.Links.Add(c1TopicLink15);
            c1TopicPage2.Links.Add(c1TopicLink16);
            c1TopicPage2.Links.Add(c1TopicLink17);
            c1TopicPage2.Links.Add(c1TopicLink18);
            c1TopicPage2.Text = "Area Charts";
            c1TopicPage3.Collapsed = true;
            c1TopicPage3.ImageIndex = 2;
            c1TopicLink19.Tag = "bar.default";
            c1TopicLink19.Text = "Default";
            c1TopicLink20.Tag = "bar.stacked";
            c1TopicLink20.Text = "Stacked";
            c1TopicLink21.Tag = "bar.stacked100pc";
            c1TopicLink21.Text = "Stacked 100%";
            c1TopicLink22.Tag = "bar.3d";
            c1TopicLink22.Text = "3D";
            c1TopicLink23.Tag = "bar.3dstacked";
            c1TopicLink23.Text = "3D Stacked";
            c1TopicLink24.Tag = "bar.3dstacked100pc";
            c1TopicLink24.Text = "3D Stacked 100%";
            c1TopicLink25.Tag = "bar.cylinder";
            c1TopicLink25.Text = "Cylinder";
            c1TopicLink26.Tag = "bar.cone";
            c1TopicLink26.Text = "Cone";
            c1TopicLink27.Tag = "bar.pyramid";
            c1TopicLink27.Text = "Pyramid";
            c1TopicPage3.Links.Add(c1TopicLink19);
            c1TopicPage3.Links.Add(c1TopicLink20);
            c1TopicPage3.Links.Add(c1TopicLink21);
            c1TopicPage3.Links.Add(c1TopicLink22);
            c1TopicPage3.Links.Add(c1TopicLink23);
            c1TopicPage3.Links.Add(c1TopicLink24);
            c1TopicPage3.Links.Add(c1TopicLink25);
            c1TopicPage3.Links.Add(c1TopicLink26);
            c1TopicPage3.Links.Add(c1TopicLink27);
            c1TopicPage3.Text = "Bar Charts";
            c1TopicPage4.Collapsed = true;
            c1TopicPage4.ImageIndex = 3;
            c1TopicLink28.Tag = "column.default";
            c1TopicLink28.Text = "Default";
            c1TopicLink29.Tag = "column.stacked";
            c1TopicLink29.Text = "Stacked";
            c1TopicLink30.Tag = "column.stacked100pc";
            c1TopicLink30.Text = "Stacked 100%";
            c1TopicLink31.Tag = "column.3d";
            c1TopicLink31.Text = "3D";
            c1TopicLink32.Tag = "column.3dstacked";
            c1TopicLink32.Text = "3D Stacked";
            c1TopicLink33.Tag = "column.3dstacked100pc";
            c1TopicLink33.Text = "3D Stacked 100%";
            c1TopicLink34.Tag = "column.3dmultirow";
            c1TopicLink34.Text = "3D Multi Row";
            c1TopicLink35.Tag = "column.cylinder";
            c1TopicLink35.Text = "Cylinder";
            c1TopicLink36.Tag = "column.cone";
            c1TopicLink36.Text = "Cone";
            c1TopicLink37.Tag = "column.pyramid";
            c1TopicLink37.Text = "Pyramid";
            c1TopicPage4.Links.Add(c1TopicLink28);
            c1TopicPage4.Links.Add(c1TopicLink29);
            c1TopicPage4.Links.Add(c1TopicLink30);
            c1TopicPage4.Links.Add(c1TopicLink31);
            c1TopicPage4.Links.Add(c1TopicLink32);
            c1TopicPage4.Links.Add(c1TopicLink33);
            c1TopicPage4.Links.Add(c1TopicLink34);
            c1TopicPage4.Links.Add(c1TopicLink35);
            c1TopicPage4.Links.Add(c1TopicLink36);
            c1TopicPage4.Links.Add(c1TopicLink37);
            c1TopicPage4.Text = "Column Charts";
            c1TopicPage5.Collapsed = true;
            c1TopicPage5.ImageIndex = 4;
            c1TopicLink38.Tag = "pie.default";
            c1TopicLink38.Text = "Default";
            c1TopicLink39.Tag = "pie.stacked";
            c1TopicLink39.Text = "Stacked";
            c1TopicLink40.Tag = "pie.sliced";
            c1TopicLink40.Text = "Sliced";
            c1TopicLink41.Tag = "pie.doughnut";
            c1TopicLink41.Text = "Doughnut";
            c1TopicLink42.Tag = "pie.sliceddoughnut";
            c1TopicLink42.Text = "Sliced Doughnut";
            c1TopicLink43.Tag = "pie.3d";
            c1TopicLink43.Text = "3D";
            c1TopicLink44.Tag = "pie.3dstacked";
            c1TopicLink44.Text = "3D Stacked";
            c1TopicLink45.Tag = "pie.3dsliced";
            c1TopicLink45.Text = "3D Sliced";
            c1TopicLink46.Tag = "pie.3ddoughnut";
            c1TopicLink46.Text = "3D Doughnut";
            c1TopicLink47.Tag = "pie.3dsliceddoughnut";
            c1TopicLink47.Text = "3D Sliced Doughnut";
            c1TopicPage5.Links.Add(c1TopicLink38);
            c1TopicPage5.Links.Add(c1TopicLink39);
            c1TopicPage5.Links.Add(c1TopicLink40);
            c1TopicPage5.Links.Add(c1TopicLink41);
            c1TopicPage5.Links.Add(c1TopicLink42);
            c1TopicPage5.Links.Add(c1TopicLink43);
            c1TopicPage5.Links.Add(c1TopicLink44);
            c1TopicPage5.Links.Add(c1TopicLink45);
            c1TopicPage5.Links.Add(c1TopicLink46);
            c1TopicPage5.Links.Add(c1TopicLink47);
            c1TopicPage5.Text = "Pie Charts";
            this.c1TopicBar1.Pages.Add(c1TopicPage1);
            this.c1TopicBar1.Pages.Add(c1TopicPage2);
            this.c1TopicBar1.Pages.Add(c1TopicPage3);
            this.c1TopicBar1.Pages.Add(c1TopicPage4);
            this.c1TopicBar1.Pages.Add(c1TopicPage5);
            this.c1TopicBar1.Size = new System.Drawing.Size(162, 412);
            this.c1TopicBar1.VisualStyle = C1.Win.C1Command.VisualStyle.System;
            this.c1TopicBar1.VisualStyleBase = C1.Win.C1Command.VisualStyle.System;
            this.c1TopicBar1.LinkClick += new C1.Win.C1Command.C1TopicBarClickEventHandler(this.c1TopicBar1_LinkClick);
            this.c1TopicBar1.PageExpanded += new C1.Win.C1Command.C1TopicBarPageEventHandler(this.c1TopicBar1_PageExpanded);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(212)))), ((int)(((byte)(221)))));
            this.panel1.Controls.Add(this.comboPalette);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(162, 34);
            this.panel1.TabIndex = 2;
            // 
            // comboPalette
            // 
            this.comboPalette.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboPalette.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPalette.FormattingEnabled = true;
            this.comboPalette.Location = new System.Drawing.Point(52, 5);
            this.comboPalette.Name = "comboPalette";
            this.comboPalette.Size = new System.Drawing.Size(106, 21);
            this.comboPalette.TabIndex = 8;
            this.comboPalette.SelectedIndexChanged += new System.EventHandler(this.comboStyle_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Palette:";
            // 
            // Gallery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 446);
            this.Controls.Add(this.splitContainer1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Gallery";
            this.Text = "Gallery";
            this.Load += new System.EventHandler(this.Gallery_Load);
            this.Resize += new System.EventHandler(this.Gallery_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.categorySales1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Chart1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1TopicBar1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private CategorySales categorySales1;
        private C1.Win.C1Chart.C1Chart c1Chart1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboPalette;
        private System.Windows.Forms.Label label2;
        private C1.Win.C1Command.C1TopicBar c1TopicBar1;
    }
}