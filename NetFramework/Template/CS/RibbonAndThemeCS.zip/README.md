## <SampleName>
#### [Download as zip](https://grapecity.github.io/DownGit/#/home?url=https://github.com/GrapeCity/ComponentOne-WinForms-Samples/tree/master/NetFramework\Template\CS\RibbonAndTheme)
____
#### <SampleTitle>
____
<SampleDescription>
