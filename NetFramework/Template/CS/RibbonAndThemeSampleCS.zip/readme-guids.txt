﻿<GUID>		Common Guid shared by sample with multiple languages.
<GUID>		Unique Guid for each sample regardless of language.