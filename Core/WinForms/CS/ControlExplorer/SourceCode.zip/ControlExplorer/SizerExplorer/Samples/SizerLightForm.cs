﻿using System.Windows.Forms;

namespace SizerExplorer.Samples
{
    public partial class SizerLightForm : Form
    {
        public SizerLightForm()
        {
            InitializeComponent();
        }
    }
}