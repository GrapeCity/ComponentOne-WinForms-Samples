namespace SizerExplorer.Samples
{
    partial class PresentationFeatures
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Drawing.Drawing2D.Blend blend5 = new System.Drawing.Drawing2D.Blend();
            System.Drawing.Drawing2D.Blend blend1 = new System.Drawing.Drawing2D.Blend();
            System.Drawing.Drawing2D.Blend blend2 = new System.Drawing.Drawing2D.Blend();
            System.Drawing.Drawing2D.Blend blend3 = new System.Drawing.Drawing2D.Blend();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PresentationFeatures));
            System.Drawing.Drawing2D.Blend blend4 = new System.Drawing.Drawing2D.Blend();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.c1Sizer1 = new C1.Win.Sizer.C1Sizer();
            this.c1Sizer9 = new C1.Win.Sizer.C1Sizer();
            this.c1Sizer4 = new C1.Win.Sizer.C1Sizer();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.c1Sizer6 = new C1.Win.Sizer.C1Sizer();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.c1Sizer2 = new C1.Win.Sizer.C1Sizer();
            this.c1Sizer3 = new C1.Win.Sizer.C1Sizer();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.c1Sizer5 = new C1.Win.Sizer.C1Sizer();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer1)).BeginInit();
            this.c1Sizer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer9)).BeginInit();
            this.c1Sizer9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer4)).BeginInit();
            this.c1Sizer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer6)).BeginInit();
            this.c1Sizer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer2)).BeginInit();
            this.c1Sizer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer3)).BeginInit();
            this.c1Sizer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer5)).BeginInit();
            this.c1Sizer5.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // c1Sizer1
            // 
            this.c1Sizer1.Controls.Add(this.c1Sizer9);
            this.c1Sizer1.Controls.Add(this.c1Sizer2);
            this.c1Sizer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Sizer1.Gradient.BackColor2 = System.Drawing.Color.Yellow;
            blend5.Factors = new float[] {
        0F,
        1F};
            blend5.Positions = new float[] {
        0F,
        1F};
            this.c1Sizer1.Gradient.Blend = blend5;
            this.c1Sizer1.GridDefinition = "60.20942408376963:True:False;39.09249563699826:False:False;\t100:False:False;";
            this.c1Sizer1.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer1.Name = "c1Sizer1";
            this.c1Sizer1.Padding = new System.Windows.Forms.Padding(0);
            this.c1Sizer1.Size = new System.Drawing.Size(892, 573);
            this.c1Sizer1.TabIndex = 2;
            this.c1Sizer1.Text = "c1Sizer1";
            this.c1Sizer1.SplitterMoved += new C1.Win.Sizer.C1SizerEventHandler(this.c1Sizer1_SplitterMoved);
            // 
            // c1Sizer9
            // 
            this.c1Sizer9.Controls.Add(this.c1Sizer4);
            this.c1Sizer9.Controls.Add(this.c1Sizer6);
            this.c1Sizer9.GridDefinition = "100:False:False;\t64.23766816143498:True:False;35.31390134529148:False:False;";
            this.c1Sizer9.Location = new System.Drawing.Point(0, 349);
            this.c1Sizer9.Name = "c1Sizer9";
            this.c1Sizer9.Padding = new System.Windows.Forms.Padding(0);
            this.c1Sizer9.Size = new System.Drawing.Size(892, 224);
            this.c1Sizer9.TabIndex = 6;
            this.c1Sizer9.Text = "c1Sizer9";
            this.c1Sizer9.SplitterMoved += new C1.Win.Sizer.C1SizerEventHandler(this.c1Sizer9_SplitterMoved);
            // 
            // c1Sizer4
            // 
            this.c1Sizer4.BackColor = System.Drawing.Color.Black;
            this.c1Sizer4.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer4.Border.Corners = new C1.Framework.Corners(20, 20, 0, 0);
            this.c1Sizer4.Border.Thickness = new System.Windows.Forms.Padding(5);
            this.c1Sizer4.Controls.Add(this.button13);
            this.c1Sizer4.Controls.Add(this.button12);
            this.c1Sizer4.Controls.Add(this.button11);
            this.c1Sizer4.Controls.Add(this.button10);
            this.c1Sizer4.Controls.Add(this.button9);
            this.c1Sizer4.Controls.Add(this.button8);
            this.c1Sizer4.Gradient.BackColor2 = System.Drawing.Color.LimeGreen;
            blend1.Factors = new float[] {
        0F,
        1F};
            blend1.Positions = new float[] {
        0F,
        1F};
            this.c1Sizer4.Gradient.Blend = blend1;
            this.c1Sizer4.Gradient.Mode = C1.Framework.GradientMode.Radial;
            this.c1Sizer4.GridDefinition = "15.625:False:False;40.625:False:False;13.392857142857142:False:True;13.3928571428" +
    "57142:False:True;\t18.848167539267017:False:True;40.31413612565445:False:False;34" +
    ".904013961605585:False:True;";
            this.c1Sizer4.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer4.Name = "c1Sizer4";
            this.c1Sizer4.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer4.Size = new System.Drawing.Size(573, 224);
            this.c1Sizer4.TabIndex = 2;
            this.c1Sizer4.Text = "c1Sizer4";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(13, 13);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(108, 35);
            this.button13.TabIndex = 5;
            this.button13.Text = "Fixed Width";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(13, 52);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(547, 91);
            this.button12.TabIndex = 4;
            this.button12.Text = "Free";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(13, 147);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(343, 64);
            this.button11.TabIndex = 3;
            this.button11.Text = "Fixed Height";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(125, 13);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(435, 35);
            this.button10.TabIndex = 2;
            this.button10.Text = "Free";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(360, 147);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(200, 30);
            this.button9.TabIndex = 1;
            this.button9.Text = "Fixed Width && Height";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(360, 181);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(200, 30);
            this.button8.TabIndex = 0;
            this.button8.Text = "Fixed Width && Height";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // c1Sizer6
            // 
            this.c1Sizer6.BackColor = System.Drawing.Color.LavenderBlush;
            this.c1Sizer6.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer6.Border.Corners = new C1.Framework.Corners(20, 20, 0, 0);
            this.c1Sizer6.Border.Thickness = new System.Windows.Forms.Padding(5);
            this.c1Sizer6.Controls.Add(this.button7);
            this.c1Sizer6.Controls.Add(this.button6);
            this.c1Sizer6.Controls.Add(this.button5);
            this.c1Sizer6.Controls.Add(this.button4);
            this.c1Sizer6.Gradient.BackColor2 = System.Drawing.Color.Orchid;
            blend2.Factors = new float[] {
        1F,
        0.4345982F,
        0.1888756F,
        0.082085F,
        0.03567399F,
        0.01550385F,
        0.006737947F};
            blend2.Positions = new float[] {
        0F,
        0.1666667F,
        0.3333333F,
        0.5F,
        0.6666667F,
        0.8333333F,
        1F};
            this.c1Sizer6.Gradient.Blend = blend2;
            this.c1Sizer6.Gradient.Center = new System.Drawing.Point(51, 55);
            this.c1Sizer6.Gradient.Mode = C1.Framework.GradientMode.Radial;
            this.c1Sizer6.GridDefinition = "16.964285714285715:False:True;50.892857142857146:False:False;16.964285714285715:F" +
    "alse:True;\t33.01587301587302:False:True;57.46031746031746:False:False;";
            this.c1Sizer6.Location = new System.Drawing.Point(577, 0);
            this.c1Sizer6.Name = "c1Sizer6";
            this.c1Sizer6.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer6.Size = new System.Drawing.Size(315, 224);
            this.c1Sizer6.TabIndex = 4;
            this.c1Sizer6.Text = "c1Sizer6";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(13, 13);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(289, 38);
            this.button7.TabIndex = 3;
            this.button7.Text = "Fixed Height";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(121, 55);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(181, 114);
            this.button6.TabIndex = 2;
            this.button6.Text = "Free";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(13, 173);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(289, 38);
            this.button5.TabIndex = 1;
            this.button5.Text = "Fixed Height";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(13, 55);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 114);
            this.button4.TabIndex = 0;
            this.button4.Text = "Fixed Width";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // c1Sizer2
            // 
            this.c1Sizer2.Controls.Add(this.c1Sizer3);
            this.c1Sizer2.Controls.Add(this.c1Sizer5);
            this.c1Sizer2.GridDefinition = "100:False:False;\t28.923766816143498:True:False;70.62780269058295:False:False;";
            this.c1Sizer2.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer2.Name = "c1Sizer2";
            this.c1Sizer2.Padding = new System.Windows.Forms.Padding(0);
            this.c1Sizer2.Size = new System.Drawing.Size(892, 345);
            this.c1Sizer2.TabIndex = 5;
            this.c1Sizer2.Text = "c1Sizer2";
            this.c1Sizer2.SplitterMoved += new C1.Win.Sizer.C1SizerEventHandler(this.c1Sizer2_SplitterMoved);
            // 
            // c1Sizer3
            // 
            this.c1Sizer3.BackColor = System.Drawing.Color.OrangeRed;
            this.c1Sizer3.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer3.Border.Corners = new C1.Framework.Corners(10, 10, 10, 10);
            this.c1Sizer3.Border.Thickness = new System.Windows.Forms.Padding(5);
            this.c1Sizer3.Controls.Add(this.button25);
            this.c1Sizer3.Controls.Add(this.button24);
            this.c1Sizer3.Controls.Add(this.button23);
            this.c1Sizer3.Controls.Add(this.button22);
            this.c1Sizer3.Controls.Add(this.button3);
            this.c1Sizer3.Controls.Add(this.button2);
            this.c1Sizer3.Gradient.BackColor2 = System.Drawing.Color.Yellow;
            blend3.Factors = new float[] {
        0F,
        1F};
            blend3.Positions = new float[] {
        0F,
        1F};
            this.c1Sizer3.Gradient.Blend = blend3;
            this.c1Sizer3.Gradient.Mode = C1.Framework.GradientMode.DiagonalUp;
            this.c1Sizer3.GridDefinition = resources.GetString("c1Sizer3.GridDefinition");
            this.c1Sizer3.Location = new System.Drawing.Point(0, 0);
            this.c1Sizer3.Name = "c1Sizer3";
            this.c1Sizer3.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer3.Size = new System.Drawing.Size(258, 345);
            this.c1Sizer3.TabIndex = 1;
            this.c1Sizer3.Text = "c1Sizer3";
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(13, 193);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(148, 36);
            this.button25.TabIndex = 10;
            this.button25.Text = "Fixed Height";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(165, 167);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(80, 62);
            this.button24.TabIndex = 9;
            this.button24.Text = "Fixed Width && Height";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(13, 233);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(232, 99);
            this.button23.TabIndex = 8;
            this.button23.Text = "Free";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(13, 123);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(148, 66);
            this.button22.TabIndex = 7;
            this.button22.Text = "Free";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(165, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 150);
            this.button3.TabIndex = 6;
            this.button3.Text = "Fixed Width";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(13, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(148, 106);
            this.button2.TabIndex = 5;
            this.button2.Text = "Fixed Height";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // c1Sizer5
            // 
            this.c1Sizer5.BackColor = System.Drawing.Color.LightCyan;
            this.c1Sizer5.Border.Color = System.Drawing.Color.SteelBlue;
            this.c1Sizer5.Border.Corners = new C1.Framework.Corners(0, 30, 30, 0);
            this.c1Sizer5.Border.Thickness = new System.Windows.Forms.Padding(6);
            this.c1Sizer5.Controls.Add(this.button21);
            this.c1Sizer5.Controls.Add(this.button20);
            this.c1Sizer5.Controls.Add(this.button19);
            this.c1Sizer5.Controls.Add(this.button18);
            this.c1Sizer5.Controls.Add(this.button17);
            this.c1Sizer5.Controls.Add(this.button16);
            this.c1Sizer5.Controls.Add(this.button15);
            this.c1Sizer5.Controls.Add(this.button14);
            this.c1Sizer5.Gradient.BackColor2 = System.Drawing.Color.DeepSkyBlue;
            blend4.Factors = new float[] {
        0F,
        0.75F,
        0.25F,
        0F,
        0.59F,
        1F};
            blend4.Positions = new float[] {
        0F,
        0.25F,
        0.49F,
        0.51F,
        0.75F,
        1F};
            this.c1Sizer5.Gradient.Blend = blend4;
            this.c1Sizer5.Gradient.Mode = C1.Framework.GradientMode.DiagonalDown;
            this.c1Sizer5.GridDefinition = resources.GetString("c1Sizer5.GridDefinition");
            this.c1Sizer5.Location = new System.Drawing.Point(262, 0);
            this.c1Sizer5.Name = "c1Sizer5";
            this.c1Sizer5.Padding = new System.Windows.Forms.Padding(8);
            this.c1Sizer5.Size = new System.Drawing.Size(630, 345);
            this.c1Sizer5.TabIndex = 3;
            this.c1Sizer5.Text = "c1Sizer5";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(416, 291);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(200, 40);
            this.button21.TabIndex = 7;
            this.button21.Text = "Fixed Width && Height";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(212, 291);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(200, 40);
            this.button20.TabIndex = 6;
            this.button20.Text = "Fixed Width && Height";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(96, 291);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(112, 40);
            this.button19.TabIndex = 5;
            this.button19.Text = "Fixed Height";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(96, 222);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(520, 65);
            this.button18.TabIndex = 4;
            this.button18.Text = "Fixed Height";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(96, 50);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(520, 168);
            this.button17.TabIndex = 3;
            this.button17.Text = "Free";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(14, 222);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(78, 109);
            this.button16.TabIndex = 2;
            this.button16.Text = "Fixed Width && Height";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(14, 50);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(78, 168);
            this.button15.TabIndex = 1;
            this.button15.Text = "Fixed Width";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(14, 14);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(602, 32);
            this.button14.TabIndex = 0;
            this.button14.Text = "Fixed Height";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // PresentationFeatures
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.c1Sizer1);
            this.Name = "PresentationFeatures";
            this.Size = new System.Drawing.Size(892, 573);
            this.Load += new System.EventHandler(this.SizerNewFeatures_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer1)).EndInit();
            this.c1Sizer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer9)).EndInit();
            this.c1Sizer9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer4)).EndInit();
            this.c1Sizer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer6)).EndInit();
            this.c1Sizer6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer2)).EndInit();
            this.c1Sizer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer3)).EndInit();
            this.c1Sizer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Sizer5)).EndInit();
            this.c1Sizer5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private C1.Win.Sizer.C1Sizer c1Sizer1;
        private C1.Win.Sizer.C1Sizer c1Sizer9;
        private C1.Win.Sizer.C1Sizer c1Sizer4;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private C1.Win.Sizer.C1Sizer c1Sizer6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private C1.Win.Sizer.C1Sizer c1Sizer2;
        private C1.Win.Sizer.C1Sizer c1Sizer3;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private C1.Win.Sizer.C1Sizer c1Sizer5;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
    }
}
