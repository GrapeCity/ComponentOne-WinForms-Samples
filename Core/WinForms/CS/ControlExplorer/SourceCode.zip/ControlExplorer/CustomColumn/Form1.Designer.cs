﻿namespace CustomColumn
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C1.Win.GanttView.BarStyle barStyle1 = new C1.Win.GanttView.BarStyle();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn1 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn2 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.CustomFieldColumn customFieldColumn1 = new C1.Win.GanttView.CustomFieldColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn3 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn4 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn5 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn6 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn7 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn8 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn9 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn10 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn11 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn12 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn13 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.TaskPropertyColumn taskPropertyColumn14 = new C1.Win.GanttView.TaskPropertyColumn();
            C1.Win.GanttView.Resource resource1 = new C1.Win.GanttView.Resource();
            C1.Win.GanttView.Resource resource2 = new C1.Win.GanttView.Resource();
            C1.Win.GanttView.Resource resource3 = new C1.Win.GanttView.Resource();
            C1.Win.GanttView.Resource resource4 = new C1.Win.GanttView.Resource();
            C1.Win.GanttView.Task task1 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task2 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.ResourceRef resourceRef1 = new C1.Win.GanttView.ResourceRef();
            C1.Win.GanttView.ResourceRef resourceRef2 = new C1.Win.GanttView.ResourceRef();
            C1.Win.GanttView.Task task3 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Predecessor predecessor1 = new C1.Win.GanttView.Predecessor();
            C1.Win.GanttView.ResourceRef resourceRef3 = new C1.Win.GanttView.ResourceRef();
            C1.Win.GanttView.Task task4 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task5 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Predecessor predecessor2 = new C1.Win.GanttView.Predecessor();
            C1.Win.GanttView.ResourceRef resourceRef4 = new C1.Win.GanttView.ResourceRef();
            C1.Win.GanttView.ResourceRef resourceRef5 = new C1.Win.GanttView.ResourceRef();
            C1.Win.GanttView.Task task6 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Predecessor predecessor3 = new C1.Win.GanttView.Predecessor();
            C1.Win.GanttView.ResourceRef resourceRef6 = new C1.Win.GanttView.ResourceRef();
            C1.Win.GanttView.Task task7 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Predecessor predecessor4 = new C1.Win.GanttView.Predecessor();
            C1.Win.GanttView.ResourceRef resourceRef7 = new C1.Win.GanttView.ResourceRef();
            C1.Win.GanttView.Task task8 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task9 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task10 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task11 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task12 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task13 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task14 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task15 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task16 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task17 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task18 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task19 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task20 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task21 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task22 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task23 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task24 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task25 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task26 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task27 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task28 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task29 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task30 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task31 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task32 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task33 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task34 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task35 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task36 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task37 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task38 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task39 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task40 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task41 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task42 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task43 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task44 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task45 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task46 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task47 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task48 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task49 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task50 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task51 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task52 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task53 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task54 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task55 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task56 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task57 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task58 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task59 = new C1.Win.GanttView.Task();
            C1.Win.GanttView.Task task60 = new C1.Win.GanttView.Task();
            this.gv = new C1.Win.GanttView.C1GanttView();
            ((System.ComponentModel.ISupportInitialize)(this.gv)).BeginInit();
            this.SuspendLayout();
            // 
            // gv
            // 
            this.gv.BackColor = System.Drawing.SystemColors.Window;
            barStyle1.BarColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(135)))), ((int)(((byte)(220)))));
            barStyle1.BarShape = C1.Win.GanttView.BarShape.ThickBar;
            barStyle1.BarType = C1.Win.GanttView.BarType.AutoTask;
            barStyle1.TopText1_ID = 287759160;
            this.gv.BarStyles.Add(barStyle1);
            taskPropertyColumn1.Caption = "Task Mode";
            taskPropertyColumn1.ID = 1680832599;
            taskPropertyColumn1.Property = C1.Win.GanttView.TaskProperty.Mode;
            taskPropertyColumn1.Visible = false;
            taskPropertyColumn1.Width = 61;
            taskPropertyColumn2.Caption = "Task Name";
            taskPropertyColumn2.ID = 375059526;
            taskPropertyColumn2.Property = C1.Win.GanttView.TaskProperty.Name;
            taskPropertyColumn2.Width = 93;
            customFieldColumn1.Caption = "Actual Cost";
            customFieldColumn1.DataType = typeof(decimal);
            customFieldColumn1.Format = "$#0";
            customFieldColumn1.ID = 79583976;
            customFieldColumn1.Name = "ActualCost";
            customFieldColumn1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            customFieldColumn1.Width = 65;
            taskPropertyColumn3.Caption = "Duration";
            taskPropertyColumn3.ID = 1572034233;
            taskPropertyColumn3.Property = C1.Win.GanttView.TaskProperty.Duration;
            taskPropertyColumn3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            taskPropertyColumn3.Width = 34;
            taskPropertyColumn4.Caption = "Duration Units";
            taskPropertyColumn4.ID = 688893641;
            taskPropertyColumn4.Property = C1.Win.GanttView.TaskProperty.DurationUnits;
            taskPropertyColumn4.Width = 60;
            taskPropertyColumn5.Caption = "Start";
            taskPropertyColumn5.ID = 1056085932;
            taskPropertyColumn5.Property = C1.Win.GanttView.TaskProperty.Start;
            taskPropertyColumn5.Visible = false;
            taskPropertyColumn6.Caption = "Finish";
            taskPropertyColumn6.ID = 536482953;
            taskPropertyColumn6.Property = C1.Win.GanttView.TaskProperty.Finish;
            taskPropertyColumn6.Visible = false;
            taskPropertyColumn7.Caption = "% Complete";
            taskPropertyColumn7.ID = 241887850;
            taskPropertyColumn7.Property = C1.Win.GanttView.TaskProperty.PercentComplete;
            taskPropertyColumn7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            taskPropertyColumn7.Visible = false;
            taskPropertyColumn8.Caption = "Constraint Type";
            taskPropertyColumn8.ID = 1492723839;
            taskPropertyColumn8.Property = C1.Win.GanttView.TaskProperty.ConstraintType;
            taskPropertyColumn8.Visible = false;
            taskPropertyColumn9.Caption = "Constraint Date";
            taskPropertyColumn9.ID = 497084593;
            taskPropertyColumn9.Property = C1.Win.GanttView.TaskProperty.ConstraintDate;
            taskPropertyColumn9.Visible = false;
            taskPropertyColumn10.Caption = "Predecessors";
            taskPropertyColumn10.ID = 1887751057;
            taskPropertyColumn10.Property = C1.Win.GanttView.TaskProperty.Predecessors;
            taskPropertyColumn10.Visible = false;
            taskPropertyColumn11.Caption = "Deadline";
            taskPropertyColumn11.ID = 1454974103;
            taskPropertyColumn11.Property = C1.Win.GanttView.TaskProperty.Deadline;
            taskPropertyColumn11.Visible = false;
            taskPropertyColumn12.Caption = "Calendar";
            taskPropertyColumn12.ID = 365231808;
            taskPropertyColumn12.Property = C1.Win.GanttView.TaskProperty.Calendar;
            taskPropertyColumn12.Visible = false;
            taskPropertyColumn13.Caption = "Resource Names";
            taskPropertyColumn13.ID = 287759160;
            taskPropertyColumn13.Property = C1.Win.GanttView.TaskProperty.ResourceNames;
            taskPropertyColumn13.Visible = false;
            taskPropertyColumn14.Caption = "Notes";
            taskPropertyColumn14.ID = 1372220778;
            taskPropertyColumn14.Property = C1.Win.GanttView.TaskProperty.Notes;
            taskPropertyColumn14.Visible = false;
            this.gv.Columns.Add(taskPropertyColumn1);
            this.gv.Columns.Add(taskPropertyColumn2);
            this.gv.Columns.Add(customFieldColumn1);
            this.gv.Columns.Add(taskPropertyColumn3);
            this.gv.Columns.Add(taskPropertyColumn4);
            this.gv.Columns.Add(taskPropertyColumn5);
            this.gv.Columns.Add(taskPropertyColumn6);
            this.gv.Columns.Add(taskPropertyColumn7);
            this.gv.Columns.Add(taskPropertyColumn8);
            this.gv.Columns.Add(taskPropertyColumn9);
            this.gv.Columns.Add(taskPropertyColumn10);
            this.gv.Columns.Add(taskPropertyColumn11);
            this.gv.Columns.Add(taskPropertyColumn12);
            this.gv.Columns.Add(taskPropertyColumn13);
            this.gv.Columns.Add(taskPropertyColumn14);
            this.gv.DefaultWorkingTimes.Interval_1.Empty = false;
            this.gv.DefaultWorkingTimes.Interval_1.From = new System.DateTime(1, 1, 1, 9, 0, 0, 0);
            this.gv.DefaultWorkingTimes.Interval_1.To = new System.DateTime(1, 1, 1, 13, 0, 0, 0);
            this.gv.DefaultWorkingTimes.Interval_2.Empty = false;
            this.gv.DefaultWorkingTimes.Interval_2.From = new System.DateTime(1, 1, 1, 14, 0, 0, 0);
            this.gv.DefaultWorkingTimes.Interval_2.To = new System.DateTime(1, 1, 1, 18, 0, 0, 0);
            this.gv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv.GridWidth = 286;
            this.gv.Location = new System.Drawing.Point(0, 0);
            this.gv.Name = "gv";
            resource1.Cost = new decimal(new int[] {
            20000,
            0,
            0,
            131072});
            resource1.ID = 457479171;
            resource1.Name = "Adam Miller";
            resource2.Cost = new decimal(new int[] {
            50000,
            0,
            0,
            131072});
            resource2.ID = 574928631;
            resource2.Name = "Ruth Radelet";
            resource3.Cost = new decimal(new int[] {
            25000,
            0,
            0,
            131072});
            resource3.ID = 1258408175;
            resource3.Name = "Johnny Jewel";
            resource4.Cost = new decimal(new int[] {
            40000,
            0,
            0,
            131072});
            resource4.ID = 187715318;
            resource4.Name = "Nat Walker";
            this.gv.Resources.Add(resource1);
            this.gv.Resources.Add(resource2);
            this.gv.Resources.Add(resource3);
            this.gv.Resources.Add(resource4);
            this.gv.Size = new System.Drawing.Size(649, 350);
            this.gv.StartDate = new System.DateTime(2015, 4, 1, 0, 0, 0, 0);
            this.gv.TabIndex = 0;
            task1.ID = 1428331781;
            task2.ConstraintDate = new System.DateTime(2012, 6, 22, 0, 0, 0, 0);
            task2.ConstraintType = C1.Win.GanttView.ConstraintType.StartNoEarlierThan;
            task2.Duration = 3;
            task2.ID = 656460240;
            task2.Mode = C1.Win.GanttView.TaskMode.Automatic;
            task2.Name = "Pursue a hare";
            resourceRef1.Amount = 1;
            resourceRef1.ResourceID = 457479171;
            resourceRef2.ResourceID = 1258408175;
            task2.ResourceRefs.Add(resourceRef1);
            task2.ResourceRefs.Add(resourceRef2);
            task2.Start = new System.DateTime(2015, 4, 1, 0, 0, 0, 0);
            task3.ConstraintDate = new System.DateTime(2012, 6, 26, 0, 0, 0, 0);
            task3.ConstraintType = C1.Win.GanttView.ConstraintType.StartNoEarlierThan;
            task3.Duration = 12;
            task3.DurationUnits = C1.Win.GanttView.DurationUnits.Minutes;
            task3.ID = 132267904;
            task3.Mode = C1.Win.GanttView.TaskMode.Automatic;
            task3.Name = "Hit the hare";
            predecessor1.PredecessorTaskID = 656460240;
            task3.Predecessors.Add(predecessor1);
            resourceRef3.Amount = 1;
            resourceRef3.ResourceID = 187715318;
            task3.ResourceRefs.Add(resourceRef3);
            task3.Start = new System.DateTime(2015, 4, 4, 0, 0, 0, 0);
            task4.ID = 704109188;
            task5.ConstraintDate = new System.DateTime(2012, 6, 28, 0, 0, 0, 0);
            task5.ConstraintType = C1.Win.GanttView.ConstraintType.StartNoEarlierThan;
            task5.Duration = 2;
            task5.ID = 1639616200;
            task5.Mode = C1.Win.GanttView.TaskMode.Automatic;
            task5.Name = "Skin that hare";
            predecessor2.PredecessorTaskID = 132267904;
            task5.Predecessors.Add(predecessor2);
            resourceRef4.Amount = 1;
            resourceRef4.ResourceID = 187715318;
            resourceRef5.Amount = 1;
            resourceRef5.ResourceID = 1258408175;
            task5.ResourceRefs.Add(resourceRef4);
            task5.ResourceRefs.Add(resourceRef5);
            task5.Start = new System.DateTime(2015, 4, 6, 9, 12, 0, 0);
            task6.ConstraintDate = new System.DateTime(2012, 6, 29, 0, 0, 0, 0);
            task6.ConstraintType = C1.Win.GanttView.ConstraintType.StartNoEarlierThan;
            task6.Duration = 3;
            task6.ID = 1784420689;
            task6.Mode = C1.Win.GanttView.TaskMode.Automatic;
            task6.Name = "Cook the hare";
            predecessor3.PredecessorTaskID = 1639616200;
            task6.Predecessors.Add(predecessor3);
            resourceRef6.Amount = 1;
            resourceRef6.ResourceID = 574928631;
            task6.ResourceRefs.Add(resourceRef6);
            task6.Start = new System.DateTime(2015, 4, 8, 9, 12, 0, 0);
            task7.ConstraintDate = new System.DateTime(2012, 6, 30, 0, 0, 0, 0);
            task7.ConstraintType = C1.Win.GanttView.ConstraintType.StartNoEarlierThan;
            task7.Duration = 1;
            task7.ID = 1296539678;
            task7.Mode = C1.Win.GanttView.TaskMode.Automatic;
            task7.Name = "Eat the hare";
            predecessor4.PredecessorTaskID = 1784420689;
            task7.Predecessors.Add(predecessor4);
            resourceRef7.Amount = 1;
            resourceRef7.ResourceID = 457479171;
            task7.ResourceRefs.Add(resourceRef7);
            task7.Start = new System.DateTime(2015, 4, 13, 9, 12, 0, 0);
            task8.ID = 1444841716;
            task9.ID = 1292198183;
            task10.ID = 194872062;
            task11.ID = 1084382609;
            task12.ID = 185961251;
            task13.ID = 393559994;
            task14.ID = 92150478;
            task15.ID = 20990948;
            task16.ID = 1623847046;
            task17.ID = 1884750761;
            task18.ID = 1112867871;
            task19.ID = 43920728;
            task20.ID = 149186310;
            task21.ID = 1021263795;
            task22.ID = 242707790;
            task23.ID = 1748838715;
            task24.ID = 506851181;
            task25.ID = 791484787;
            task26.ID = 572119585;
            task27.ID = 2026106759;
            task28.ID = 39792468;
            task29.ID = 86367301;
            task30.ID = 1099725135;
            task31.ID = 454310966;
            task32.ID = 604586163;
            task33.ID = 1249515592;
            task34.ID = 1587165775;
            task35.ID = 82220786;
            task36.ID = 1611700704;
            task37.ID = 833779805;
            task38.ID = 77200479;
            task39.ID = 1549556208;
            task40.ID = 1589311134;
            task41.ID = 825958818;
            task42.ID = 235990884;
            task43.ID = 1230344991;
            task44.ID = 1377162172;
            task45.ID = 1751994680;
            task46.ID = 870124682;
            task47.ID = 142922960;
            task48.ID = 149737373;
            task49.ID = 1471732892;
            task50.ID = 1020721195;
            task51.ID = 3000297;
            task52.ID = 342106233;
            task53.ID = 321311081;
            task54.ID = 138572851;
            task55.ID = 350956984;
            task56.ID = 413752451;
            task57.ID = 530912837;
            task58.ID = 921480601;
            task59.ID = 848131414;
            task60.ID = 1212301105;
            this.gv.Tasks.Add(task1);
            this.gv.Tasks.Add(task2);
            this.gv.Tasks.Add(task3);
            this.gv.Tasks.Add(task4);
            this.gv.Tasks.Add(task5);
            this.gv.Tasks.Add(task6);
            this.gv.Tasks.Add(task7);
            this.gv.Tasks.Add(task8);
            this.gv.Tasks.Add(task9);
            this.gv.Tasks.Add(task10);
            this.gv.Tasks.Add(task11);
            this.gv.Tasks.Add(task12);
            this.gv.Tasks.Add(task13);
            this.gv.Tasks.Add(task14);
            this.gv.Tasks.Add(task15);
            this.gv.Tasks.Add(task16);
            this.gv.Tasks.Add(task17);
            this.gv.Tasks.Add(task18);
            this.gv.Tasks.Add(task19);
            this.gv.Tasks.Add(task20);
            this.gv.Tasks.Add(task21);
            this.gv.Tasks.Add(task22);
            this.gv.Tasks.Add(task23);
            this.gv.Tasks.Add(task24);
            this.gv.Tasks.Add(task25);
            this.gv.Tasks.Add(task26);
            this.gv.Tasks.Add(task27);
            this.gv.Tasks.Add(task28);
            this.gv.Tasks.Add(task29);
            this.gv.Tasks.Add(task30);
            this.gv.Tasks.Add(task31);
            this.gv.Tasks.Add(task32);
            this.gv.Tasks.Add(task33);
            this.gv.Tasks.Add(task34);
            this.gv.Tasks.Add(task35);
            this.gv.Tasks.Add(task36);
            this.gv.Tasks.Add(task37);
            this.gv.Tasks.Add(task38);
            this.gv.Tasks.Add(task39);
            this.gv.Tasks.Add(task40);
            this.gv.Tasks.Add(task41);
            this.gv.Tasks.Add(task42);
            this.gv.Tasks.Add(task43);
            this.gv.Tasks.Add(task44);
            this.gv.Tasks.Add(task45);
            this.gv.Tasks.Add(task46);
            this.gv.Tasks.Add(task47);
            this.gv.Tasks.Add(task48);
            this.gv.Tasks.Add(task49);
            this.gv.Tasks.Add(task50);
            this.gv.Tasks.Add(task51);
            this.gv.Tasks.Add(task52);
            this.gv.Tasks.Add(task53);
            this.gv.Tasks.Add(task54);
            this.gv.Tasks.Add(task55);
            this.gv.Tasks.Add(task56);
            this.gv.Tasks.Add(task57);
            this.gv.Tasks.Add(task58);
            this.gv.Tasks.Add(task59);
            this.gv.Tasks.Add(task60);
            this.gv.Timescale.BottomTier.Align = C1.Win.GanttView.ScaleLabelAlignment.Center;
            this.gv.Timescale.BottomTier.Format = "w";
            this.gv.Timescale.BottomTier.Visible = true;
            this.gv.Timescale.MiddleTier.Format = "nnnn d";
            this.gv.Timescale.MiddleTier.Units = C1.Win.GanttView.TimescaleUnits.Weeks;
            this.gv.Timescale.MiddleTier.Visible = true;
            this.gv.VisualStyle = C1.Win.GanttView.VisualStyle.Office2010Silver;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 350);
            this.Controls.Add(this.gv);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Name = "Form1";
            this.Text = "Custom Column Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.GanttView.C1GanttView gv;
    }
}

