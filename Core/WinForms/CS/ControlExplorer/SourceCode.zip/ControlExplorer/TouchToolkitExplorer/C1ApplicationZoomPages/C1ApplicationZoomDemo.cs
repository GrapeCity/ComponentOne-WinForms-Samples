﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using C1.Win.TouchToolKit;

namespace TouchToolkitExplorer.C1ApplicationZoomPages
{
    public partial class C1ApplicationZoomDemo : DemoBase
    {
        public C1ApplicationZoomDemo()
        {
            InitializeComponent();

            this.Description = "User can add a component to MainForm (startup form),  then it add touch-zoom capability to all Forms. " +
                               "It will be a simplest way for most Windows Forms Application.";

            InitializeDemo();
            this._gcZoom.ZoomPolicies.Add(new MyImageButtonZoomPolicy());
            this._gcZoom.C1ZoomAttaching += C1ApplicationZoom1_C1ZoomAttaching;
        }

        void C1ApplicationZoom1_C1ZoomAttaching(object sender, C1ZoomAttachingEventArgs e)
        {
            if ((e.Form is AppZoom_Main)
                || (e.Form is AppZoom_Child1)
                || (e.Form is AppZoom_Child2)
                || (e.Form is AppZoom_Child3))
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }

        C1ApplicationZoom _gcZoom = new C1ApplicationZoom();

        private void InitializeDemo()
        {
            this.Title = "C1Zoom Basic (Zoom and Scroll)";
            this.Description = @"This page is used to try basic features of C1Zoom. 
  - Click the Show Form Button to show a test application. And test the Gestrue zoom/scroll.
  - Try to change the settings to knows how to config the C1ApplicationZoom.";

            AddEnumItemsToComboBox(ZoomPreviewModeComboBox, typeof(ZoomPreviewMode));
            AddEnumItemsToComboBox(scrollIndicatorCombo, typeof(ScrollIndicatorMode));
            formatComboBox.Items.Add("Zooming {Percentage}%");
            formatComboBox.Items.Add("Zooming x{ZoomFactor}");

            scrollIndicatorCombo.SelectedItem = _gcZoom.ScrollIndicatorMode;
            ZoomPreviewModeComboBox.SelectedItem = _gcZoom.ZoomPreviewMode;
            formatComboBox.SelectedIndex = 0;
            displayLabel.Font = _gcZoom.AlternativeContentSettings.Font;
            displayLabel.ForeColor = _gcZoom.AlternativeContentSettings.ForeColor;
            HorizontalRailEnableCheckBox.DataBindings.Add("Checked", _gcZoom, "IsHorizontalRailEnabled");
            VerticalRailEnableCheckBox.DataBindings.Add("Checked", _gcZoom, "IsVerticalRailEnabled");
            AllowDoubleTapZoomCheckBox.DataBindings.Add("Checked", _gcZoom, "AllowDoubleTapZoom");
            KeepAspectRatioCheckBox.DataBindings.Add("Checked", _gcZoom, "KeepAspectRatio");
            scrollIndicatorCombo.DataBindings.Add("SelectedItem", _gcZoom, "ScrollIndicatorMode");
            boundaryFeedbackUI1.DataBindings.Add("BoundaryFeedbackMode", _gcZoom, "BoundaryFeedbackMode");

            ZoomPreviewModeComboBox.SelectedIndexChanged += ZoomPreviewModeComboBox_SelectedIndexChanged;
            formatComboBox.TextChanged += formatComboBox_TextChanged;
            FontButton.Click += FontButton_Click;
            ForeColorButton.Click += ForeColorButton_Click;
            formButton.Click += formButton_Click;
            _gcZoom.C1ZoomAttached += _gcZoom_C1ZoomAttached;
            boundaryFeedbackUI1.BoundaryFeedbackModeChanged += boundaryFeedbackUI1_BoundaryFeedbackModeChanged;
        }

        void _gcZoom_C1ZoomAttached(object sender, C1ZoomAttachedEventArgs e)
        {
            if (e.Form is AppZoom_Child3)
            {
                e.GcZoom.InnerPanelLayoutMode = InnerPanelLayoutMode.MiddleCenter;
                e.GcZoom.AllowResizeByZoom = true;
            }
        }

        void formButton_Click(object sender, EventArgs e)
        {
            using (AppZoom_Main form = new AppZoom_Main())
            {
                form.ShowDialog(this);
            }
        }

        void ZoomPreviewModeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            _gcZoom.ZoomPreviewMode = (ZoomPreviewMode)ZoomPreviewModeComboBox.SelectedItem;

            this.alternativeContentGroup.Visible = false;
            this.NoPreivewInfoPanel.Visible = false;
            this.boundaryFeedbackUI1.Visible = false;
            switch (_gcZoom.ZoomPreviewMode)
            {
                case ZoomPreviewMode.Bitmap:
                    this.boundaryFeedbackUI1.Visible = true;
                    break;
                case ZoomPreviewMode.NoPreview:
                    this.NoPreivewInfoPanel.Visible = true;
                    break;
                case ZoomPreviewMode.AlternativeContent:
                    this.alternativeContentGroup.Visible = true;
                    break;
                default:
                    break;
            }
        }

        void formatComboBox_TextChanged(object sender, EventArgs e)
        {
            if (formatComboBox.Text != null)
            {
                _gcZoom.AlternativeContentSettings.Format = formatComboBox.Text;
                displayLabel.Text = formatComboBox.Text.Replace("{Percentage}", "100").Replace("{ZoomFactor}", "1.00"); ;
            }
        }

        void ForeColorButton_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();
            if (DialogResult.OK == dialog.ShowDialog())
            {
                _gcZoom.AlternativeContentSettings.ForeColor = dialog.Color;
                displayLabel.ForeColor = dialog.Color;
            }
        }

        void FontButton_Click(object sender, EventArgs e)
        {
            FontDialog dialog = new FontDialog();
            if (DialogResult.OK == dialog.ShowDialog())
            {
                _gcZoom.AlternativeContentSettings.Font = dialog.Font;
                displayLabel.Font = dialog.Font;
            }
        }

        void boundaryFeedbackUI1_BoundaryFeedbackModeChanged(object sender, EventArgs e)
        {
            _gcZoom.BoundaryFeedbackMode = boundaryFeedbackUI1.BoundaryFeedbackMode;
        }

        private void AddEnumItemsToComboBox(ComboBox comboBox, Type enumType)
        {
            Array enumArray = Enum.GetValues(enumType);
            for (int i = 0; i < enumArray.Length; i++)
            {
                comboBox.Items.Add(enumArray.GetValue(i));
            }
        }
    }
}
