﻿namespace SampleExplorer
{
    partial class LinearGauges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange13 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks5 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks6 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels7 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange14 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange15 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange16 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange17 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange18 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel6 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels8 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels9 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange24 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks7 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks8 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels12 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer7 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer8 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange19 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange20 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange21 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange22 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel7 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel8 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel9 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer5 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer6 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels10 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels11 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange23 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel10 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeSector c1GaugeSector2 = new C1.Win.Gauge.C1GaugeSector();
            C1.Win.Gauge.C1GaugeEllipse c1GaugeEllipse2 = new C1.Win.Gauge.C1GaugeEllipse();
            C1.Win.Gauge.C1GaugeCaption c1GaugeCaption3 = new C1.Win.Gauge.C1GaugeCaption();
            C1.Win.Gauge.C1GaugeCaption c1GaugeCaption4 = new C1.Win.Gauge.C1GaugeCaption();
            this.c1Gauge1 = new C1.Win.Gauge.C1Gauge();
            this.c1LinearGauge1 = new C1.Win.Gauge.C1LinearGauge();
            this.c1Gauge2 = new C1.Win.Gauge.C1Gauge();
            this.c1LinearGauge3 = new C1.Win.Gauge.C1LinearGauge();
            this.c1Gauge3 = new C1.Win.Gauge.C1Gauge();
            this.c1LinearGauge2 = new C1.Win.Gauge.C1LinearGauge();
            this.c1Gauge5 = new C1.Win.Gauge.C1Gauge();
            this.c1LinearGauge5 = new C1.Win.Gauge.C1LinearGauge();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.c1Gauge4 = new C1.Win.Gauge.C1Gauge();
            this.c1LinearGauge4 = new C1.Win.Gauge.C1LinearGauge();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).BeginInit();
            this.SuspendLayout();
            // 
            // c1Gauge1
            // 
            this.c1Gauge1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge1.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1LinearGauge1});
            this.c1Gauge1.Location = new System.Drawing.Point(4, 4);
            this.c1Gauge1.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge1.Name = "c1Gauge1";
            this.tableLayoutPanel1.SetRowSpan(this.c1Gauge1, 2);
            this.c1Gauge1.Size = new System.Drawing.Size(345, 743);
            this.c1Gauge1.TabIndex = 0;
            this.c1Gauge1.ViewTag = ((long)(650345882961079712));
            // 
            // c1LinearGauge1
            // 
            this.c1LinearGauge1.AxisLength = 0.88D;
            c1GaugeRange13.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeRange13.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeRange13.ViewTag = ((long)(717286292691556980));
            c1GaugeRange13.Width = 0.5D;
            c1GaugeMarks5.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks5.Interval = 25D;
            c1GaugeMarks5.Length = 10D;
            c1GaugeMarks5.Location = 40D;
            c1GaugeMarks5.ViewTag = ((long)(736708070189897828));
            c1GaugeMarks5.Width = 0.1D;
            c1GaugeMarks6.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks6.Interval = 5D;
            c1GaugeMarks6.Length = 4D;
            c1GaugeMarks6.Location = 42D;
            c1GaugeMarks6.ViewTag = ((long)(740648722200817145));
            c1GaugeMarks6.Width = 0.1D;
            c1GaugeLabels7.Alignment = C1.Win.Gauge.C1GaugeAlignment.In;
            c1GaugeLabels7.FontSize = 12D;
            c1GaugeLabels7.Interval = 25D;
            c1GaugeLabels7.Location = 28D;
            c1GaugeLabels7.ViewTag = ((long)(740930198312349440));
            c1GaugeRange14.Border.Color = System.Drawing.Color.Transparent;
            c1GaugeRange14.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            c1GaugeRange14.Location = 62D;
            c1GaugeRange14.Location2 = 62D;
            c1GaugeRange14.To = 49D;
            c1GaugeRange14.ViewTag = ((long)(741211674624702052));
            c1GaugeRange14.Width = 20D;
            c1GaugeRange14.Width2 = 20D;
            c1GaugeRange15.Border.Color = System.Drawing.Color.Transparent;
            c1GaugeRange15.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            c1GaugeRange15.From = 51D;
            c1GaugeRange15.Location = 62D;
            c1GaugeRange15.Location2 = 62D;
            c1GaugeRange15.To = 99D;
            c1GaugeRange15.ViewTag = ((long)(741493151396224170));
            c1GaugeRange15.Width = 20D;
            c1GaugeRange15.Width2 = 20D;
            c1GaugeRange16.Border.Color = System.Drawing.Color.Transparent;
            c1GaugeRange16.Filling.Color = System.Drawing.Color.LightCoral;
            c1GaugeRange16.From = 101D;
            c1GaugeRange16.Location = 62D;
            c1GaugeRange16.Location2 = 62D;
            c1GaugeRange16.ViewTag = ((long)(741774628525849801));
            c1GaugeRange16.Width = 20D;
            c1GaugeRange16.Width2 = 20D;
            this.c1LinearGauge1.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeRange13,
            c1GaugeMarks5,
            c1GaugeMarks6,
            c1GaugeLabels7,
            c1GaugeRange14,
            c1GaugeRange15,
            c1GaugeRange16});
            this.c1LinearGauge1.IsReversed = true;
            this.c1LinearGauge1.Maximum = 150D;
            this.c1LinearGauge1.Name = "c1LinearGauge1";
            this.c1LinearGauge1.Orientation = C1.Win.Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge1.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c1LinearGauge1.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.c1LinearGauge1.Pointer.Length = 11D;
            this.c1LinearGauge1.Pointer.Offset = 40D;
            this.c1LinearGauge1.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Triangle;
            this.c1LinearGauge1.Pointer.SweepTime = 3D;
            this.c1LinearGauge1.Pointer.Value = 50D;
            this.c1LinearGauge1.Pointer.Width = 8D;
            this.c1LinearGauge1.Viewport.AspectRatio = 0.33D;
            this.c1LinearGauge1.ViewTag = ((long)(716441866908225388));
            // 
            // c1Gauge2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge2, 3);
            this.c1Gauge2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge2.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1LinearGauge3});
            this.c1Gauge2.Location = new System.Drawing.Point(357, 492);
            this.c1Gauge2.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge2.Name = "c1Gauge2";
            this.c1Gauge2.Size = new System.Drawing.Size(1052, 255);
            this.c1Gauge2.TabIndex = 1;
            this.c1Gauge2.ViewTag = ((long)(682997085326371631));
            // 
            // c1LinearGauge3
            // 
            c1GaugeRange17.Border.Color = System.Drawing.SystemColors.ControlDark;
            c1GaugeRange17.Filling.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeRange17.Location = 50D;
            c1GaugeRange17.ViewTag = ((long)(669734115192623138));
            c1GaugeRange17.Width = 50D;
            c1GaugeRange18.Border.Color = System.Drawing.SystemColors.HotTrack;
            c1GaugeRange18.Filling.Color = System.Drawing.SystemColors.Highlight;
            c1GaugeRange18.Location = 50D;
            c1GaugeRange18.ToPointerIndex = 10;
            c1GaugeRange18.ViewTag = ((long)(669452639794046327));
            c1GaugeRange18.Width = 50D;
            c1GaugeSingleLabel6.Color = System.Drawing.Color.White;
            c1GaugeSingleLabel6.FontSize = 36D;
            c1GaugeSingleLabel6.Format = "####";
            c1GaugeSingleLabel6.Location = 55D;
            c1GaugeSingleLabel6.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.In;
            c1GaugeSingleLabel6.PointerIndex = 100;
            c1GaugeSingleLabel6.ViewTag = ((long)(648343123971847526));
            c1GaugeLabels8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeLabels8.FontSize = 30D;
            c1GaugeLabels8.Location = 52D;
            c1GaugeLabels8.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.In;
            c1GaugeLabels8.ShowIrregularFrom = true;
            c1GaugeLabels8.ViewTag = ((long)(741319027881637179));
            c1GaugeLabels9.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeLabels9.FontSize = 30D;
            c1GaugeLabels9.Location = 52D;
            c1GaugeLabels9.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeLabels9.ShowIrregularTo = true;
            c1GaugeLabels9.ViewTag = ((long)(741600503539762633));
            this.c1LinearGauge3.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeRange17,
            c1GaugeRange18,
            c1GaugeSingleLabel6,
            c1GaugeLabels8,
            c1GaugeLabels9});
            this.c1LinearGauge3.Name = "c1LinearGauge3";
            this.c1LinearGauge3.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            this.c1LinearGauge3.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Rectangle;
            this.c1LinearGauge3.Pointer.SweepTime = 3D;
            this.c1LinearGauge3.Pointer.Value = 45D;
            this.c1LinearGauge3.Pointer.Visible = false;
            this.c1LinearGauge3.Viewport.AspectRatio = 10D;
            this.c1LinearGauge3.ViewTag = ((long)(716441866908225388));
            // 
            // c1Gauge3
            // 
            this.c1Gauge3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge3.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1LinearGauge2});
            this.c1Gauge3.Location = new System.Drawing.Point(710, 4);
            this.c1Gauge3.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge3.Name = "c1Gauge3";
            this.c1Gauge3.Size = new System.Drawing.Size(345, 480);
            this.c1Gauge3.TabIndex = 4;
            this.c1Gauge3.ViewTag = ((long)(650345882961079712));
            // 
            // c1LinearGauge2
            // 
            this.c1LinearGauge2.AxisLength = 0.88D;
            c1GaugeRange24.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeRange24.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeRange24.ViewTag = ((long)(717286292691556980));
            c1GaugeRange24.Width = 0.5D;
            c1GaugeMarks7.Alignment = C1.Win.Gauge.C1GaugeAlignment.In;
            c1GaugeMarks7.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks7.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks7.Interval = 10D;
            c1GaugeMarks7.Length = 15D;
            c1GaugeMarks7.Location = 45D;
            c1GaugeMarks7.ViewTag = ((long)(736708070189897828));
            c1GaugeMarks7.Width = 0.1D;
            c1GaugeMarks8.Alignment = C1.Win.Gauge.C1GaugeAlignment.In;
            c1GaugeMarks8.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks8.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeMarks8.Interval = 1D;
            c1GaugeMarks8.Length = 10D;
            c1GaugeMarks8.Location = 45D;
            c1GaugeMarks8.ViewTag = ((long)(740648722200817145));
            c1GaugeMarks8.Width = 0.1D;
            c1GaugeLabels12.Alignment = C1.Win.Gauge.C1GaugeAlignment.In;
            c1GaugeLabels12.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeLabels12.FontSize = 12D;
            c1GaugeLabels12.Interval = 10D;
            c1GaugeLabels12.Location = 28D;
            c1GaugeLabels12.ViewTag = ((long)(740930198312349440));
            this.c1LinearGauge2.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeRange24,
            c1GaugeMarks7,
            c1GaugeMarks8,
            c1GaugeLabels12});
            this.c1LinearGauge2.IsReversed = true;
            this.c1LinearGauge2.Maximum = 50D;
            c1GaugePointer7.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            c1GaugePointer7.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            c1GaugePointer7.FlipShape = true;
            c1GaugePointer7.Length = 15D;
            c1GaugePointer7.Offset = 40D;
            c1GaugePointer7.Shape = C1.Win.Gauge.C1GaugePointerShape.Triangle;
            c1GaugePointer7.SweepTime = 2D;
            c1GaugePointer7.Value = 15D;
            c1GaugePointer7.ViewTag = ((long)(845464713497643339));
            c1GaugePointer7.Width = 15D;
            c1GaugePointer8.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(196)))), ((int)(((byte)(146)))));
            c1GaugePointer8.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(196)))), ((int)(((byte)(146)))));
            c1GaugePointer8.FlipShape = true;
            c1GaugePointer8.Length = 15D;
            c1GaugePointer8.Offset = 40D;
            c1GaugePointer8.Shape = C1.Win.Gauge.C1GaugePointerShape.Triangle;
            c1GaugePointer8.SweepTime = 2D;
            c1GaugePointer8.Value = 26D;
            c1GaugePointer8.ViewTag = ((long)(845746188908663134));
            c1GaugePointer8.Width = 15D;
            this.c1LinearGauge2.MorePointers.AddRange(new C1.Win.Gauge.C1GaugePointer[] {
            c1GaugePointer7,
            c1GaugePointer8});
            this.c1LinearGauge2.Name = "c1LinearGauge2";
            this.c1LinearGauge2.Orientation = C1.Win.Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge2.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(249)))), ((int)(((byte)(147)))));
            this.c1LinearGauge2.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(249)))), ((int)(((byte)(147)))));
            this.c1LinearGauge2.Pointer.FlipShape = true;
            this.c1LinearGauge2.Pointer.Length = 15D;
            this.c1LinearGauge2.Pointer.Offset = 40D;
            this.c1LinearGauge2.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Triangle;
            this.c1LinearGauge2.Pointer.SweepTime = 2D;
            this.c1LinearGauge2.Pointer.Value = 35D;
            this.c1LinearGauge2.Pointer.Width = 15D;
            this.c1LinearGauge2.Viewport.AspectRatio = 0.3D;
            this.c1LinearGauge2.ViewTag = ((long)(716441866908225388));
            // 
            // c1Gauge5
            // 
            this.c1Gauge5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge5.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1LinearGauge5});
            this.c1Gauge5.Location = new System.Drawing.Point(1063, 4);
            this.c1Gauge5.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge5.Name = "c1Gauge5";
            this.c1Gauge5.Size = new System.Drawing.Size(346, 480);
            this.c1Gauge5.TabIndex = 5;
            this.c1Gauge5.ViewTag = ((long)(650345882961079712));
            // 
            // c1LinearGauge5
            // 
            c1GaugeRange19.Border.Color = System.Drawing.SystemColors.ControlDark;
            c1GaugeRange19.Filling.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeRange19.Location = 50D;
            c1GaugeRange19.ViewTag = ((long)(669734115192623138));
            c1GaugeRange19.Width = 66D;
            c1GaugeRange20.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange20.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            c1GaugeRange20.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            c1GaugeRange20.Location = 18D;
            c1GaugeRange20.ToPointerIndex = 100;
            c1GaugeRange20.ViewTag = ((long)(669452639794046327));
            c1GaugeRange20.Width = 20D;
            c1GaugeRange21.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange21.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugeRange21.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugeRange21.Location = 40D;
            c1GaugeRange21.ToPointerIndex = 0;
            c1GaugeRange21.ViewTag = ((long)(918085264919869555));
            c1GaugeRange21.Width = 20D;
            c1GaugeRange22.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange22.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(62)))));
            c1GaugeRange22.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(62)))));
            c1GaugeRange22.Location = 62D;
            c1GaugeRange22.ToPointerIndex = 1;
            c1GaugeRange22.ViewTag = ((long)(918366739912100796));
            c1GaugeRange22.Width = 20D;
            c1GaugeSingleLabel7.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel7.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeSingleLabel7.FontSize = 8D;
            c1GaugeSingleLabel7.Format = "####";
            c1GaugeSingleLabel7.Location = 22D;
            c1GaugeSingleLabel7.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel7.PointerIndex = 100;
            c1GaugeSingleLabel7.ViewTag = ((long)(919211168302661112));
            c1GaugeSingleLabel8.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeSingleLabel8.FontSize = 8D;
            c1GaugeSingleLabel8.Format = "####";
            c1GaugeSingleLabel8.Location = 44D;
            c1GaugeSingleLabel8.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel8.PointerIndex = 0;
            c1GaugeSingleLabel8.ViewTag = ((long)(919492644099592127));
            c1GaugeSingleLabel9.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel9.Color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            c1GaugeSingleLabel9.FontSize = 8D;
            c1GaugeSingleLabel9.Format = "####";
            c1GaugeSingleLabel9.Location = 66D;
            c1GaugeSingleLabel9.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel9.PointerIndex = 1;
            c1GaugeSingleLabel9.ViewTag = ((long)(919774119082139408));
            this.c1LinearGauge5.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeRange19,
            c1GaugeRange20,
            c1GaugeRange21,
            c1GaugeRange22,
            c1GaugeSingleLabel7,
            c1GaugeSingleLabel8,
            c1GaugeSingleLabel9});
            this.c1LinearGauge5.IsReversed = true;
            c1GaugePointer5.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugePointer5.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugePointer5.Offset = 40D;
            c1GaugePointer5.Shape = C1.Win.Gauge.C1GaugePointerShape.Round;
            c1GaugePointer5.SweepTime = 3D;
            c1GaugePointer5.Value = 75D;
            c1GaugePointer5.ViewTag = ((long)(918648215763211745));
            c1GaugePointer5.Visible = false;
            c1GaugePointer6.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(61)))));
            c1GaugePointer6.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(61)))));
            c1GaugePointer6.Offset = 62D;
            c1GaugePointer6.Shape = C1.Win.Gauge.C1GaugePointerShape.Round;
            c1GaugePointer6.SweepTime = 3D;
            c1GaugePointer6.Value = 60D;
            c1GaugePointer6.ViewTag = ((long)(918929691985530988));
            c1GaugePointer6.Visible = false;
            this.c1LinearGauge5.MorePointers.AddRange(new C1.Win.Gauge.C1GaugePointer[] {
            c1GaugePointer5,
            c1GaugePointer6});
            this.c1LinearGauge5.Name = "c1LinearGauge5";
            this.c1LinearGauge5.Orientation = C1.Win.Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge5.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.c1LinearGauge5.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.c1LinearGauge5.Pointer.Offset = 18D;
            this.c1LinearGauge5.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Round;
            this.c1LinearGauge5.Pointer.SweepTime = 3D;
            this.c1LinearGauge5.Pointer.Value = 45D;
            this.c1LinearGauge5.Pointer.Visible = false;
            this.c1LinearGauge5.ViewTag = ((long)(716441866908225388));
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge5, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge3, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1413, 751);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // c1Gauge4
            // 
            this.c1Gauge4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge4.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1LinearGauge4});
            this.c1Gauge4.Location = new System.Drawing.Point(357, 4);
            this.c1Gauge4.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge4.Name = "c1Gauge4";
            this.c1Gauge4.Size = new System.Drawing.Size(345, 480);
            this.c1Gauge4.TabIndex = 3;
            this.c1Gauge4.ViewTag = ((long)(761248883865943896));
            // 
            // c1LinearGauge4
            // 
            this.c1LinearGauge4.AxisLength = 0.77D;
            this.c1LinearGauge4.AxisStart = 0.08D;
            c1GaugeLabels10.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeLabels10.FontSize = 8D;
            c1GaugeLabels10.Format = "0";
            c1GaugeLabels10.Interval = 11.111111111D;
            c1GaugeLabels10.Location = 43D;
            c1GaugeLabels10.ScaleFrom = -28.888888889D;
            c1GaugeLabels10.SequenceNo = -1;
            c1GaugeLabels10.ValueFactor = 1.8D;
            c1GaugeLabels10.ValueOffset = 32D;
            c1GaugeLabels10.ViewTag = ((long)(636567332216930038));
            c1GaugeLabels11.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeLabels11.FontSize = 8D;
            c1GaugeLabels11.Interval = 10D;
            c1GaugeLabels11.Location = 88D;
            c1GaugeLabels11.ScaleFrom = -30D;
            c1GaugeLabels11.SequenceNo = -1;
            c1GaugeLabels11.ViewTag = ((long)(738731823729698891));
            c1GaugeRange23.Border.LineStyle = C1.Win.Gauge.C1GaugeBorderStyle.None;
            c1GaugeRange23.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeRange23.Location = 66D;
            c1GaugeRange23.ToPointerIndex = 1;
            c1GaugeRange23.ViewTag = ((long)(739294773683120203));
            c1GaugeRange23.Width = 10D;
            c1GaugeSingleLabel10.Color = System.Drawing.Color.White;
            c1GaugeSingleLabel10.FontSize = 10D;
            c1GaugeSingleLabel10.Format = "####";
            c1GaugeSingleLabel10.Location = 67D;
            c1GaugeSingleLabel10.OrthogonalOffset = -11D;
            c1GaugeSingleLabel10.PointerIndex = 100;
            c1GaugeSingleLabel10.Position = 0D;
            c1GaugeSingleLabel10.ViewTag = ((long)(652846689807763557));
            this.c1LinearGauge4.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeLabels10,
            c1GaugeLabels11,
            c1GaugeRange23,
            c1GaugeSingleLabel10});
            this.c1LinearGauge4.FaceAhead = true;
            c1GaugeSector2.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(171)))), ((int)(((byte)(171)))));
            c1GaugeSector2.Border.Thickness = 0.2D;
            c1GaugeSector2.CenterPointX = 0.66D;
            c1GaugeSector2.CenterPointY = 1.05D;
            c1GaugeSector2.CenterRadius = 12D;
            c1GaugeSector2.CornerRadius = 10D;
            c1GaugeSector2.Filling.Color = System.Drawing.Color.White;
            c1GaugeSector2.OuterRadius = 208.5D;
            c1GaugeSector2.SweepAngle = 0D;
            c1GaugeEllipse2.Border.LineStyle = C1.Win.Gauge.C1GaugeBorderStyle.None;
            c1GaugeEllipse2.CenterPointX = 0.66D;
            c1GaugeEllipse2.CenterPointY = 1.05D;
            c1GaugeEllipse2.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            c1GaugeEllipse2.Height = 25D;
            c1GaugeEllipse2.Width = 25D;
            c1GaugeCaption3.CenterPointX = 0.35D;
            c1GaugeCaption3.CenterPointY = 0.99D;
            c1GaugeCaption3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeCaption3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            c1GaugeCaption3.FontSize = 10D;
            c1GaugeCaption3.Text = "°F";
            c1GaugeCaption4.CenterPointX = 0.93D;
            c1GaugeCaption4.CenterPointY = -0.05D;
            c1GaugeCaption4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeCaption4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            c1GaugeCaption4.FontSize = 9D;
            c1GaugeCaption4.Text = "°C";
            this.c1LinearGauge4.FaceShapes.AddRange(new C1.Win.Gauge.C1GaugeBaseShape[] {
            c1GaugeSector2,
            c1GaugeEllipse2,
            c1GaugeCaption3,
            c1GaugeCaption4});
            this.c1LinearGauge4.IsReversed = true;
            this.c1LinearGauge4.Maximum = 50D;
            this.c1LinearGauge4.Minimum = -35D;
            this.c1LinearGauge4.Name = "c1LinearGauge4";
            this.c1LinearGauge4.Orientation = C1.Win.Gauge.C1GaugeOrientation.Vertical;
            this.c1LinearGauge4.Pointer.SweepTime = 3D;
            this.c1LinearGauge4.Pointer.Value = -13D;
            this.c1LinearGauge4.Pointer.Visible = false;
            this.c1LinearGauge4.Viewport.AspectRatio = 0.5D;
            this.c1LinearGauge4.ViewTag = ((long)(737042973869434955));
            // 
            // LinearGauges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1413, 751);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "LinearGauges";
            this.Text = "LinearGauges";
            this.Load += new System.EventHandler(this.LinearGauges_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.Gauge.C1Gauge c1Gauge1;
        private C1.Win.Gauge.C1Gauge c1Gauge2;
        private C1.Win.Gauge.C1Gauge c1Gauge3;
        private C1.Win.Gauge.C1Gauge c1Gauge5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private C1.Win.Gauge.C1Gauge c1Gauge4;
        private C1.Win.Gauge.C1LinearGauge c1LinearGauge4;
        private C1.Win.Gauge.C1LinearGauge c1LinearGauge1;
        private C1.Win.Gauge.C1LinearGauge c1LinearGauge3;
        private C1.Win.Gauge.C1LinearGauge c1LinearGauge2;
        private C1.Win.Gauge.C1LinearGauge c1LinearGauge5;
    }
}