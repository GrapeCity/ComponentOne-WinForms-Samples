﻿namespace SampleExplorer
{
    partial class RadialGauges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks9 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks10 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels6 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange17 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange18 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeSingleMark c1GaugeSingleMark8 = new C1.Win.Gauge.C1GaugeSingleMark();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer12 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer13 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer14 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange14 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange15 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel8 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeSingleMark c1GaugeSingleMark5 = new C1.Win.Gauge.C1GaugeSingleMark();
            C1.Win.Gauge.C1GaugeSingleMark c1GaugeSingleMark6 = new C1.Win.Gauge.C1GaugeSingleMark();
            C1.Win.Gauge.C1GaugeSingleMark c1GaugeSingleMark7 = new C1.Win.Gauge.C1GaugeSingleMark();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks6 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks7 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels4 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer10 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer11 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange16 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeMarks c1GaugeMarks8 = new C1.Win.Gauge.C1GaugeMarks();
            C1.Win.Gauge.C1GaugeLabels c1GaugeLabels5 = new C1.Win.Gauge.C1GaugeLabels();
            C1.Win.Gauge.C1GaugeSector c1GaugeSector2 = new C1.Win.Gauge.C1GaugeSector();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange10 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange11 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange12 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeRange c1GaugeRange13 = new C1.Win.Gauge.C1GaugeRange();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel5 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel6 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeSingleLabel c1GaugeSingleLabel7 = new C1.Win.Gauge.C1GaugeSingleLabel();
            C1.Win.Gauge.C1GaugeRectangle c1GaugeRectangle2 = new C1.Win.Gauge.C1GaugeRectangle();
            C1.Win.Gauge.C1GaugeImage c1GaugeImage2 = new C1.Win.Gauge.C1GaugeImage();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer8 = new C1.Win.Gauge.C1GaugePointer();
            C1.Win.Gauge.C1GaugePointer c1GaugePointer9 = new C1.Win.Gauge.C1GaugePointer();
            this.c1Gauge1 = new C1.Win.Gauge.C1Gauge();
            this.c1RadialGauge1 = new C1.Win.Gauge.C1RadialGauge();
            this.c1Gauge2 = new C1.Win.Gauge.C1Gauge();
            this.c1RadialGauge2 = new C1.Win.Gauge.C1RadialGauge();
            this.c1Gauge3 = new C1.Win.Gauge.C1Gauge();
            this.c1RadialGauge4 = new C1.Win.Gauge.C1RadialGauge();
            this.c1Gauge4 = new C1.Win.Gauge.C1Gauge();
            this.c1RadialGauge3 = new C1.Win.Gauge.C1RadialGauge();
            this.c1Gauge5 = new C1.Win.Gauge.C1Gauge();
            this.c1RadialGauge5 = new C1.Win.Gauge.C1RadialGauge();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // c1Gauge1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge1, 2);
            this.c1Gauge1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge1.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1RadialGauge1});
            this.c1Gauge1.Location = new System.Drawing.Point(4, 4);
            this.c1Gauge1.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge1.Name = "c1Gauge1";
            this.c1Gauge1.Size = new System.Drawing.Size(486, 367);
            this.c1Gauge1.TabIndex = 0;
            this.c1Gauge1.ViewTag = ((long)(650344890318900608));
            // 
            // c1RadialGauge1
            // 
            this.c1RadialGauge1.Cap.Border.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge1.Cap.Filling.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge1.Cap.Radius = 5D;
            c1GaugeMarks9.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks9.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeMarks9.Border.Thickness = 1D;
            c1GaugeMarks9.Interval = 20D;
            c1GaugeMarks9.Length = 10D;
            c1GaugeMarks9.Location = 70D;
            c1GaugeMarks9.ViewTag = ((long)(651719695147658837));
            c1GaugeMarks9.Width = 0.1D;
            c1GaugeMarks10.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks10.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeMarks10.Interval = 2D;
            c1GaugeMarks10.Length = 6D;
            c1GaugeMarks10.Location = 76D;
            c1GaugeMarks10.ViewTag = ((long)(742721980681543851));
            c1GaugeMarks10.Width = 0.1D;
            c1GaugeLabels6.FontSize = 8D;
            c1GaugeLabels6.Interval = 20D;
            c1GaugeLabels6.Location = 60D;
            c1GaugeLabels6.ViewTag = ((long)(652001172366915324));
            c1GaugeRange17.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeRange17.Location = 80D;
            c1GaugeRange17.ViewTag = ((long)(800987325146417284));
            c1GaugeRange17.Width = 1D;
            c1GaugeRange18.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange18.Border.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeRange18.Filling.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeRange18.Location = 80D;
            c1GaugeRange18.ValueColors.AddRange(new C1.Win.Gauge.C1GaugeValueColor[] {
            new C1.Win.Gauge.C1GaugeValueColor(double.NaN, 2, System.Drawing.SystemColors.ControlLight, 1D, ((long)(799016995318781684))),
            new C1.Win.Gauge.C1GaugeValueColor(double.NaN, 2, System.Drawing.Color.Yellow, 1D, ((long)(800142897784409926))),
            new C1.Win.Gauge.C1GaugeValueColor(double.NaN, 1, System.Drawing.Color.Yellow, 1D, ((long)(800705848278882926))),
            new C1.Win.Gauge.C1GaugeValueColor(double.NaN, 1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))), 1D, ((long)(799298471350207348))),
            new C1.Win.Gauge.C1GaugeValueColor(double.NaN, 0, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))), 1D, ((long)(796765191338784183))),
            new C1.Win.Gauge.C1GaugeValueColor(double.NaN, 0, System.Drawing.Color.Red, 1D, ((long)(799579946547480744)))});
            c1GaugeRange18.ViewTag = ((long)(794794860924988669));
            c1GaugeRange18.Width = 10D;
            c1GaugeSingleMark8.Angle = 180D;
            c1GaugeSingleMark8.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeSingleMark8.Length = 15D;
            c1GaugeSingleMark8.Location = 66D;
            c1GaugeSingleMark8.PointerIndex = 100;
            c1GaugeSingleMark8.Shape = C1.Win.Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark8.ValueColors.AddRange(new C1.Win.Gauge.C1GaugeValueColor[] {
            new C1.Win.Gauge.C1GaugeValueColor(0D, -1, System.Drawing.SystemColors.ControlLight, 1D, ((long)(712430657207558961))),
            new C1.Win.Gauge.C1GaugeValueColor(70D, -1, System.Drawing.SystemColors.ControlLight, 1D, ((long)(712712132385466623))),
            new C1.Win.Gauge.C1GaugeValueColor(70D, -1, System.Drawing.Color.Yellow, 1D, ((long)(712993608052096897))),
            new C1.Win.Gauge.C1GaugeValueColor(80D, -1, System.Drawing.Color.Yellow, 1D, ((long)(713275083271601713))),
            new C1.Win.Gauge.C1GaugeValueColor(80D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))), 1D, ((long)(713556558294324558))),
            new C1.Win.Gauge.C1GaugeValueColor(90D, -1, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))), 1D, ((long)(713838033305283033))),
            new C1.Win.Gauge.C1GaugeValueColor(90D, -1, System.Drawing.Color.Red, 1D, ((long)(714119508324939585)))});
            c1GaugeSingleMark8.ViewTag = ((long)(712149180858714082));
            c1GaugeSingleMark8.Width = 15D;
            this.c1RadialGauge1.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeMarks9,
            c1GaugeMarks10,
            c1GaugeLabels6,
            c1GaugeRange17,
            c1GaugeRange18,
            c1GaugeSingleMark8});
            c1GaugePointer12.Border.Color = System.Drawing.Color.Red;
            c1GaugePointer12.CustomShape.EndWidth = 0.15D;
            c1GaugePointer12.CustomShape.StartRadius = 2D;
            c1GaugePointer12.Filling.Color = System.Drawing.Color.Red;
            c1GaugePointer12.Length = 75D;
            c1GaugePointer12.Name = "Critical";
            c1GaugePointer12.Offset = 0D;
            c1GaugePointer12.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer12.Value = 90D;
            c1GaugePointer12.ViewTag = ((long)(795357813022111541));
            c1GaugePointer12.Visible = false;
            c1GaugePointer13.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            c1GaugePointer13.CustomShape.EndWidth = 0.15D;
            c1GaugePointer13.CustomShape.StartRadius = 2D;
            c1GaugePointer13.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            c1GaugePointer13.Length = 75D;
            c1GaugePointer13.Offset = 0D;
            c1GaugePointer13.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer13.Value = 80D;
            c1GaugePointer13.ViewTag = ((long)(797891092960737757));
            c1GaugePointer13.Visible = false;
            c1GaugePointer14.Border.Color = System.Drawing.Color.Yellow;
            c1GaugePointer14.CustomShape.EndWidth = 0.15D;
            c1GaugePointer14.CustomShape.StartRadius = 2D;
            c1GaugePointer14.Filling.Color = System.Drawing.Color.Yellow;
            c1GaugePointer14.Length = 75D;
            c1GaugePointer14.Offset = 0D;
            c1GaugePointer14.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer14.Value = 70D;
            c1GaugePointer14.ViewTag = ((long)(799861422288583524));
            c1GaugePointer14.Visible = false;
            this.c1RadialGauge1.MorePointers.AddRange(new C1.Win.Gauge.C1GaugePointer[] {
            c1GaugePointer12,
            c1GaugePointer13,
            c1GaugePointer14});
            this.c1RadialGauge1.Name = "c1RadialGauge1";
            this.c1RadialGauge1.Pointer.Border.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge1.Pointer.CustomShape.EndWidth = 0.15D;
            this.c1RadialGauge1.Pointer.Filling.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge1.Pointer.Length = 74D;
            this.c1RadialGauge1.Pointer.Offset = 0D;
            this.c1RadialGauge1.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge1.Pointer.SweepTime = 2D;
            this.c1RadialGauge1.Pointer.Value = 10.8D;
            this.c1RadialGauge1.ViewTag = ((long)(639317637171740509));
            // 
            // c1Gauge2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge2, 2);
            this.c1Gauge2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge2.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1RadialGauge2});
            this.c1Gauge2.Location = new System.Drawing.Point(498, 4);
            this.c1Gauge2.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge2.Name = "c1Gauge2";
            this.c1Gauge2.Size = new System.Drawing.Size(486, 367);
            this.c1Gauge2.TabIndex = 1;
            this.c1Gauge2.ViewTag = ((long)(638804372879744744));
            // 
            // c1RadialGauge2
            // 
            this.c1RadialGauge2.Cap.Border.Color = System.Drawing.Color.Black;
            this.c1RadialGauge2.Cap.Filling.Color = System.Drawing.Color.Black;
            this.c1RadialGauge2.Cap.Radius = 2.5D;
            this.c1RadialGauge2.Cap.Visible = false;
            c1GaugeRange14.Border.Color = System.Drawing.Color.Transparent;
            c1GaugeRange14.Filling.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeRange14.FromPointerIndex = 100;
            c1GaugeRange14.Location = 60D;
            c1GaugeRange14.ViewTag = ((long)(640162063073460990));
            c1GaugeRange14.Width = 5D;
            c1GaugeRange15.Border.Color = System.Drawing.Color.Transparent;
            c1GaugeRange15.Filling.Color = System.Drawing.SystemColors.Highlight;
            c1GaugeRange15.Location = 60D;
            c1GaugeRange15.Name = "Before";
            c1GaugeRange15.ToPointerIndex = 100;
            c1GaugeRange15.ViewTag = ((long)(640443538688254004));
            c1GaugeRange15.Width = 5D;
            c1GaugeSingleLabel8.Angle = 0D;
            c1GaugeSingleLabel8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeSingleLabel8.FontSize = 12D;
            c1GaugeSingleLabel8.Format = "####0";
            c1GaugeSingleLabel8.Location = 10D;
            c1GaugeSingleLabel8.PointerIndex = 100;
            c1GaugeSingleLabel8.ViewTag = ((long)(642976825261498990));
            c1GaugeSingleMark5.Angle = -90D;
            c1GaugeSingleMark5.Border.Color = System.Drawing.SystemColors.Highlight;
            c1GaugeSingleMark5.Filling.Color = System.Drawing.SystemColors.Highlight;
            c1GaugeSingleMark5.Length = 5D;
            c1GaugeSingleMark5.Location = 60.2D;
            c1GaugeSingleMark5.Name = "StartMark";
            c1GaugeSingleMark5.Shape = C1.Win.Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark5.ViewTag = ((long)(667285870679711091));
            c1GaugeSingleMark6.Border.Color = System.Drawing.SystemColors.Highlight;
            c1GaugeSingleMark6.Filling.Color = System.Drawing.SystemColors.Highlight;
            c1GaugeSingleMark6.Length = 5D;
            c1GaugeSingleMark6.Location = 60.2D;
            c1GaugeSingleMark6.Name = "ValueMark";
            c1GaugeSingleMark6.PointerIndex = 100;
            c1GaugeSingleMark6.Shape = C1.Win.Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark6.ViewTag = ((long)(667567348153846470));
            c1GaugeSingleMark7.Angle = 90D;
            c1GaugeSingleMark7.Border.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeSingleMark7.Filling.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeSingleMark7.Length = 5D;
            c1GaugeSingleMark7.Location = 60.2D;
            c1GaugeSingleMark7.Name = "EndMark";
            c1GaugeSingleMark7.Shape = C1.Win.Gauge.C1GaugeMarkShape.Round;
            c1GaugeSingleMark7.ViewTag = ((long)(667848823762714394));
            this.c1RadialGauge2.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeRange14,
            c1GaugeRange15,
            c1GaugeSingleLabel8,
            c1GaugeSingleMark5,
            c1GaugeSingleMark6,
            c1GaugeSingleMark7});
            this.c1RadialGauge2.Name = "c1RadialGauge2";
            this.c1RadialGauge2.Pointer.Border.Color = System.Drawing.Color.Black;
            this.c1RadialGauge2.Pointer.CustomShape.EndAngle = 60D;
            this.c1RadialGauge2.Pointer.CustomShape.EndWidth = 0.15D;
            this.c1RadialGauge2.Pointer.CustomShape.StartRadius = 1.999999999998D;
            this.c1RadialGauge2.Pointer.CustomShape.StartWidth = 1D;
            this.c1RadialGauge2.Pointer.Filling.Color = System.Drawing.Color.Black;
            this.c1RadialGauge2.Pointer.Length = 64D;
            this.c1RadialGauge2.Pointer.Offset = 0D;
            this.c1RadialGauge2.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge2.Pointer.SweepTime = 3D;
            this.c1RadialGauge2.Pointer.Value = 45D;
            this.c1RadialGauge2.Pointer.Visible = false;
            this.c1RadialGauge2.PointerOriginY = 0.7D;
            this.c1RadialGauge2.Radius = 0.6D;
            this.c1RadialGauge2.StartAngle = -90D;
            this.c1RadialGauge2.SweepAngle = 180D;
            this.c1RadialGauge2.ViewTag = ((long)(639317637171740509));
            // 
            // c1Gauge3
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge3, 2);
            this.c1Gauge3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge3.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1RadialGauge4});
            this.c1Gauge3.Location = new System.Drawing.Point(498, 379);
            this.c1Gauge3.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge3.Name = "c1Gauge3";
            this.c1Gauge3.Size = new System.Drawing.Size(486, 368);
            this.c1Gauge3.TabIndex = 2;
            this.c1Gauge3.ViewTag = ((long)(644999700835737836));
            // 
            // c1RadialGauge4
            // 
            this.c1RadialGauge4.Cap.Border.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge4.Cap.Filling.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge4.Cap.Radius = 5D;
            c1GaugeMarks6.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks6.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeMarks6.Border.Thickness = 1D;
            c1GaugeMarks6.Interval = 5D;
            c1GaugeMarks6.Length = 10D;
            c1GaugeMarks6.Location = 70D;
            c1GaugeMarks6.ViewTag = ((long)(651719695147658837));
            c1GaugeMarks6.Width = 0.1D;
            c1GaugeMarks7.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks7.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeMarks7.Interval = 1D;
            c1GaugeMarks7.Length = 6D;
            c1GaugeMarks7.Location = 74D;
            c1GaugeMarks7.ViewTag = ((long)(742721980681543851));
            c1GaugeMarks7.Width = 0.1D;
            c1GaugeLabels4.FontSize = 8D;
            c1GaugeLabels4.From = 5D;
            c1GaugeLabels4.Interval = 5D;
            c1GaugeLabels4.Location = 90D;
            c1GaugeLabels4.ValueFactor = 0.2D;
            c1GaugeLabels4.ViewTag = ((long)(652001172366915324));
            this.c1RadialGauge4.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeMarks6,
            c1GaugeMarks7,
            c1GaugeLabels4});
            this.c1RadialGauge4.Maximum = 60D;
            c1GaugePointer10.Border.Color = System.Drawing.SystemColors.Highlight;
            c1GaugePointer10.CustomShape.EndWidth = 0.15D;
            c1GaugePointer10.CustomShape.StartAngle = 80D;
            c1GaugePointer10.CustomShape.StartSwellAngle = -80D;
            c1GaugePointer10.Filling.Color = System.Drawing.SystemColors.Highlight;
            c1GaugePointer10.Length = 70D;
            c1GaugePointer10.Name = "Minutes";
            c1GaugePointer10.Offset = 0D;
            c1GaugePointer10.Shadow.Visible = true;
            c1GaugePointer10.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer10.Value = 24D;
            c1GaugePointer10.ViewTag = ((long)(691775049632620920));
            c1GaugePointer11.Border.Color = System.Drawing.SystemColors.ControlDark;
            c1GaugePointer11.CustomShape.EndWidth = 1D;
            c1GaugePointer11.CustomShape.StartWidth = 1D;
            c1GaugePointer11.Filling.Color = System.Drawing.SystemColors.ControlDark;
            c1GaugePointer11.Length = 70D;
            c1GaugePointer11.Name = "Seconds";
            c1GaugePointer11.Offset = 0D;
            c1GaugePointer11.Shadow.Visible = true;
            c1GaugePointer11.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            c1GaugePointer11.Value = 48D;
            c1GaugePointer11.ViewTag = ((long)(862067462180347451));
            this.c1RadialGauge4.MorePointers.AddRange(new C1.Win.Gauge.C1GaugePointer[] {
            c1GaugePointer10,
            c1GaugePointer11});
            this.c1RadialGauge4.Name = "c1RadialGauge4";
            this.c1RadialGauge4.Pointer.Border.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge4.Pointer.CustomShape.EndWidth = 0.15D;
            this.c1RadialGauge4.Pointer.CustomShape.StartAngle = 78D;
            this.c1RadialGauge4.Pointer.CustomShape.StartSwellAngle = -80D;
            this.c1RadialGauge4.Pointer.CustomShape.StartSwellLength = 2D;
            this.c1RadialGauge4.Pointer.CustomShape.StartSwellWidth = 1D;
            this.c1RadialGauge4.Pointer.Filling.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge4.Pointer.Length = 50D;
            this.c1RadialGauge4.Pointer.Offset = 0D;
            this.c1RadialGauge4.Pointer.Shadow.Visible = true;
            this.c1RadialGauge4.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge4.Pointer.Value = 1.5D;
            this.c1RadialGauge4.Pointer.ValueFactor = 5D;
            this.c1RadialGauge4.StartAngle = 0D;
            this.c1RadialGauge4.SweepAngle = 360D;
            this.c1RadialGauge4.ViewTag = ((long)(639317637171740509));
            // 
            // c1Gauge4
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.c1Gauge4, 2);
            this.c1Gauge4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge4.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1RadialGauge3});
            this.c1Gauge4.Location = new System.Drawing.Point(4, 379);
            this.c1Gauge4.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge4.Name = "c1Gauge4";
            this.c1Gauge4.Size = new System.Drawing.Size(486, 368);
            this.c1Gauge4.TabIndex = 3;
            this.c1Gauge4.ViewTag = ((long)(683840423864400252));
            // 
            // c1RadialGauge3
            // 
            this.c1RadialGauge3.Cap.Border.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge3.Cap.Filling.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge3.Cap.Radius = 2.5D;
            c1GaugeRange16.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange16.Border.Color = System.Drawing.Color.Transparent;
            c1GaugeRange16.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeRange16.Location = 72D;
            c1GaugeRange16.ViewTag = ((long)(640162063073460990));
            c1GaugeRange16.Width = 0.3D;
            c1GaugeMarks8.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeMarks8.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeMarks8.Border.Thickness = 1D;
            c1GaugeMarks8.Interval = 10D;
            c1GaugeMarks8.Length = 3D;
            c1GaugeMarks8.Location = 71D;
            c1GaugeMarks8.Shape = C1.Win.Gauge.C1GaugeMarkShape.Round;
            c1GaugeMarks8.ViewTag = ((long)(651719695147658837));
            c1GaugeMarks8.Width = 3D;
            c1GaugeLabels5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeLabels5.FontSize = 8D;
            c1GaugeLabels5.Location = 80D;
            c1GaugeLabels5.ShowIrregularFrom = true;
            c1GaugeLabels5.ShowIrregularTo = true;
            c1GaugeLabels5.ViewTag = ((long)(652001172366915324));
            this.c1RadialGauge3.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeRange16,
            c1GaugeMarks8,
            c1GaugeLabels5});
            c1GaugeSector2.Border.Color = System.Drawing.SystemColors.ControlDark;
            c1GaugeSector2.Filling.Color = System.Drawing.Color.WhiteSmoke;
            c1GaugeSector2.StartAngle = -90D;
            c1GaugeSector2.SweepAngle = 90D;
            this.c1RadialGauge3.FaceShapes.AddRange(new C1.Win.Gauge.C1GaugeBaseShape[] {
            c1GaugeSector2});
            this.c1RadialGauge3.Name = "c1RadialGauge3";
            this.c1RadialGauge3.Pointer.Border.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge3.Pointer.CustomShape.EndWidth = 0.15D;
            this.c1RadialGauge3.Pointer.CustomShape.StartWidth = 1D;
            this.c1RadialGauge3.Pointer.Filling.Color = System.Drawing.SystemColors.Highlight;
            this.c1RadialGauge3.Pointer.Length = 92D;
            this.c1RadialGauge3.Pointer.Offset = 0D;
            this.c1RadialGauge3.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Custom;
            this.c1RadialGauge3.Pointer.SweepTime = 3D;
            this.c1RadialGauge3.Pointer.Value = 10D;
            this.c1RadialGauge3.PointerOriginX = 0.8D;
            this.c1RadialGauge3.PointerOriginY = 0.8D;
            this.c1RadialGauge3.Radius = 0.76D;
            this.c1RadialGauge3.StartAngle = -90D;
            this.c1RadialGauge3.SweepAngle = 90D;
            this.c1RadialGauge3.ViewTag = ((long)(639317637171740509));
            // 
            // c1Gauge5
            // 
            this.c1Gauge5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1Gauge5.Gauges.AddRange(new C1.Win.Gauge.C1GaugeBase[] {
            this.c1RadialGauge5});
            this.c1Gauge5.Location = new System.Drawing.Point(992, 4);
            this.c1Gauge5.Margin = new System.Windows.Forms.Padding(4);
            this.c1Gauge5.Name = "c1Gauge5";
            this.tableLayoutPanel1.SetRowSpan(this.c1Gauge5, 2);
            this.c1Gauge5.Size = new System.Drawing.Size(417, 743);
            this.c1Gauge5.TabIndex = 4;
            this.c1Gauge5.ViewTag = ((long)(750552744159329021));
            // 
            // c1RadialGauge5
            // 
            this.c1RadialGauge5.Cap.Border.Color = System.Drawing.Color.Black;
            this.c1RadialGauge5.Cap.Filling.Color = System.Drawing.Color.Black;
            this.c1RadialGauge5.Cap.Radius = 2.5D;
            this.c1RadialGauge5.Cap.Visible = false;
            c1GaugeRange10.Border.Color = System.Drawing.SystemColors.ControlDark;
            c1GaugeRange10.Border.Thickness = 1D;
            c1GaugeRange10.Filling.Color = System.Drawing.SystemColors.ControlLight;
            c1GaugeRange10.Location = 60D;
            c1GaugeRange10.ViewTag = ((long)(640162063073460990));
            c1GaugeRange10.Width = 36D;
            c1GaugeRange11.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange11.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            c1GaugeRange11.Border.Thickness = 1D;
            c1GaugeRange11.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            c1GaugeRange11.Location = 68D;
            c1GaugeRange11.ToPointerIndex = 100;
            c1GaugeRange11.ViewTag = ((long)(821257826740026267));
            c1GaugeRange11.Width = 8D;
            c1GaugeRange12.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange12.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugeRange12.Border.Thickness = 1D;
            c1GaugeRange12.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugeRange12.Location = 56D;
            c1GaugeRange12.ToPointerIndex = 0;
            c1GaugeRange12.ViewTag = ((long)(640443538688254004));
            c1GaugeRange12.Width = 8D;
            c1GaugeRange13.Alignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeRange13.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(62)))));
            c1GaugeRange13.Border.Thickness = 1D;
            c1GaugeRange13.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(62)))));
            c1GaugeRange13.Location = 44D;
            c1GaugeRange13.ToPointerIndex = 1;
            c1GaugeRange13.ViewTag = ((long)(820976350520465157));
            c1GaugeRange13.Width = 8D;
            c1GaugeSingleLabel5.Angle = 0D;
            c1GaugeSingleLabel5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeSingleLabel5.FontSize = 10D;
            c1GaugeSingleLabel5.Format = "####0";
            c1GaugeSingleLabel5.IsRotated = true;
            c1GaugeSingleLabel5.Location = 70D;
            c1GaugeSingleLabel5.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel5.OrthogonalOffset = 2D;
            c1GaugeSingleLabel5.PointerIndex = 100;
            c1GaugeSingleLabel5.ViewTag = ((long)(642976825261498990));
            c1GaugeSingleLabel6.Angle = 0D;
            c1GaugeSingleLabel6.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeSingleLabel6.FontSize = 10D;
            c1GaugeSingleLabel6.Format = "####0";
            c1GaugeSingleLabel6.IsRotated = true;
            c1GaugeSingleLabel6.Location = 58D;
            c1GaugeSingleLabel6.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel6.OrthogonalOffset = 2D;
            c1GaugeSingleLabel6.PointerIndex = 0;
            c1GaugeSingleLabel6.ViewTag = ((long)(1074303919804627200));
            c1GaugeSingleLabel7.Angle = 0D;
            c1GaugeSingleLabel7.Color = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(68)))), ((int)(((byte)(68)))));
            c1GaugeSingleLabel7.FontSize = 10D;
            c1GaugeSingleLabel7.Format = "####0";
            c1GaugeSingleLabel7.IsRotated = true;
            c1GaugeSingleLabel7.Location = 46D;
            c1GaugeSingleLabel7.OrthogonalAlignment = C1.Win.Gauge.C1GaugeAlignment.Out;
            c1GaugeSingleLabel7.OrthogonalOffset = 2D;
            c1GaugeSingleLabel7.PointerIndex = 1;
            c1GaugeSingleLabel7.ViewTag = ((long)(1074585394787094121));
            this.c1RadialGauge5.Decorators.AddRange(new C1.Win.Gauge.C1GaugeDecorator[] {
            c1GaugeRange10,
            c1GaugeRange11,
            c1GaugeRange12,
            c1GaugeRange13,
            c1GaugeSingleLabel5,
            c1GaugeSingleLabel6,
            c1GaugeSingleLabel7});
            c1GaugeRectangle2.Border.Color = System.Drawing.SystemColors.ControlDark;
            c1GaugeRectangle2.CenterPointX = 0.66D;
            c1GaugeRectangle2.CornerRadius = 2D;
            c1GaugeRectangle2.Filling.Color = System.Drawing.Color.WhiteSmoke;
            c1GaugeRectangle2.Width = 120D;
            c1GaugeImage2.Height = 12D;
            c1GaugeImage2.RotateAngle = 90D;
            c1GaugeImage2.Width = 12D;
            this.c1RadialGauge5.FaceShapes.AddRange(new C1.Win.Gauge.C1GaugeBaseShape[] {
            c1GaugeRectangle2,
            c1GaugeImage2});
            this.c1RadialGauge5.IsReversed = true;
            c1GaugePointer8.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(62)))));
            c1GaugePointer8.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(185)))), ((int)(((byte)(62)))));
            c1GaugePointer8.Length = 8D;
            c1GaugePointer8.Offset = 44D;
            c1GaugePointer8.Shape = C1.Win.Gauge.C1GaugePointerShape.Round;
            c1GaugePointer8.SweepTime = 3D;
            c1GaugePointer8.Value = 66D;
            c1GaugePointer8.ViewTag = ((long)(820694871472120969));
            c1GaugePointer8.Visible = false;
            c1GaugePointer8.Width = 5D;
            c1GaugePointer9.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugePointer9.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(62)))), ((int)(((byte)(157)))));
            c1GaugePointer9.Length = 8D;
            c1GaugePointer9.Offset = 56D;
            c1GaugePointer9.Shape = C1.Win.Gauge.C1GaugePointerShape.Round;
            c1GaugePointer9.SweepTime = 3D;
            c1GaugePointer9.Value = 55D;
            c1GaugePointer9.ViewTag = ((long)(820131921288297450));
            c1GaugePointer9.Visible = false;
            c1GaugePointer9.Width = 5D;
            this.c1RadialGauge5.MorePointers.AddRange(new C1.Win.Gauge.C1GaugePointer[] {
            c1GaugePointer8,
            c1GaugePointer9});
            this.c1RadialGauge5.Name = "c1RadialGauge5";
            this.c1RadialGauge5.Pointer.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.c1RadialGauge5.Pointer.Filling.Color = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.c1RadialGauge5.Pointer.Length = 8D;
            this.c1RadialGauge5.Pointer.Offset = 68D;
            this.c1RadialGauge5.Pointer.Shape = C1.Win.Gauge.C1GaugePointerShape.Round;
            this.c1RadialGauge5.Pointer.SweepTime = 3D;
            this.c1RadialGauge5.Pointer.Value = 45D;
            this.c1RadialGauge5.Pointer.Visible = false;
            this.c1RadialGauge5.Pointer.Width = 5D;
            this.c1RadialGauge5.PointerOriginX = 0.3D;
            this.c1RadialGauge5.Radius = 0.7D;
            this.c1RadialGauge5.StartAngle = 0D;
            this.c1RadialGauge5.SweepAngle = 180D;
            this.c1RadialGauge5.ViewTag = ((long)(639317637171740509));
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge3, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.c1Gauge4, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1413, 751);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // RadialGauges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1413, 751);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "RadialGauges";
            this.Text = "RadialGauges";
            this.Load += new System.EventHandler(this.RadialGauges_Load);
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1Gauge5)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.Gauge.C1Gauge c1Gauge1;
        private C1.Win.Gauge.C1Gauge c1Gauge2;
        private C1.Win.Gauge.C1Gauge c1Gauge3;
        private C1.Win.Gauge.C1Gauge c1Gauge4;
        private C1.Win.Gauge.C1Gauge c1Gauge5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private C1.Win.Gauge.C1RadialGauge c1RadialGauge1;
        private C1.Win.Gauge.C1RadialGauge c1RadialGauge2;
        private C1.Win.Gauge.C1RadialGauge c1RadialGauge3;
        private C1.Win.Gauge.C1RadialGauge c1RadialGauge4;
        private C1.Win.Gauge.C1RadialGauge c1RadialGauge5;
    }
}