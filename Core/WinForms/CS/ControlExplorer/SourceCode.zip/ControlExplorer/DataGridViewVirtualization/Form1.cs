using C1.DataCollection.BindingList;

namespace DataGridViewVirtualization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            var collectionView = new VirtualModeDataCollection();
            dataGridView1.DataSource = new C1DataCollectionBindingList(collectionView);
            c1DbNavigator1.DataSource = dataGridView1.DataSource;
        }
    }
}
