﻿namespace CommandExplorer.Samples
{
    partial class ToolbarsOverview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.c1TextBox2 = new C1.Win.Input.C1TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.c1CommandDock4 = new C1.Win.Command.C1CommandDock();
            this.c1CommandDock3 = new C1.Win.Command.C1CommandDock();
            this.c1CommandDock2 = new C1.Win.Command.C1CommandDock();
            this.c1CommandDock1 = new C1.Win.Command.C1CommandDock();
            this.c1ToolBar_Tools = new C1.Win.Command.C1ToolBar();
            this.c1CommandHolder1 = new C1.Win.Command.C1CommandHolder();
            this.c1CommandMenu_File = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink2 = new C1.Win.Command.C1CommandLink();
            this.c1Command_New = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink11 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NewMail = new C1.Win.Command.C1Command();
            this.c1CommandLink20 = new C1.Win.Command.C1CommandLink();
            this.c1CommandNewAppointment = new C1.Win.Command.C1Command();
            this.c1CommandLink21 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NewNote = new C1.Win.Command.C1Command();
            this.c1CommandLink22 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NewTask = new C1.Win.Command.C1Command();
            this.c1CommandLink23 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NewContact = new C1.Win.Command.C1Command();
            this.c1CommandLink12 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Open = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink13 = new C1.Win.Command.C1CommandLink();
            this.c1Command_OpenFile = new C1.Win.Command.C1Command();
            this.c1CommandLink29 = new C1.Win.Command.C1CommandLink();
            this.c1Command_OpenDatabase = new C1.Win.Command.C1Command();
            this.c1CommandLink14 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Save = new C1.Win.Command.C1Command();
            this.c1CommandLink30 = new C1.Win.Command.C1CommandLink();
            this.c1Command_SaveAll = new C1.Win.Command.C1Command();
            this.c1CommandLink15 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Print = new C1.Win.Command.C1Command();
            this.c1CommandMenu_Edit = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink4 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Undo = new C1.Win.Command.C1Command();
            this.c1CommandLink16 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Redo = new C1.Win.Command.C1Command();
            this.c1CommandLink17 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Cut = new C1.Win.Command.C1Command();
            this.c1CommandLink18 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Copy = new C1.Win.Command.C1Command();
            this.c1CommandLink19 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Paste = new C1.Win.Command.C1Command();
            this.c1CommandLink63 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Format = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink64 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Bold = new C1.Win.Command.C1Command();
            this.c1CommandLink65 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Italic = new C1.Win.Command.C1Command();
            this.c1CommandLink66 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Underline = new C1.Win.Command.C1Command();
            this.c1CommandLink67 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Strikethrough = new C1.Win.Command.C1Command();
            this.c1CommandLink68 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Subscript = new C1.Win.Command.C1Command();
            this.c1CommandLink69 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Superscript = new C1.Win.Command.C1Command();
            this.c1CommandLink70 = new C1.Win.Command.C1CommandLink();
            this.c1Command_ShrinkFont = new C1.Win.Command.C1Command();
            this.c1CommandLink71 = new C1.Win.Command.C1CommandLink();
            this.c1Command_GrowFont = new C1.Win.Command.C1Command();
            this.c1CommandLink72 = new C1.Win.Command.C1CommandLink();
            this.c1Command_DecIndent = new C1.Win.Command.C1Command();
            this.c1CommandLink73 = new C1.Win.Command.C1CommandLink();
            this.c1Command_IncIndent = new C1.Win.Command.C1Command();
            this.c1CommandLink74 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Bullets = new C1.Win.Command.C1Command();
            this.c1CommandLink75 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Numbering = new C1.Win.Command.C1Command();
            this.c1CommandLink76 = new C1.Win.Command.C1CommandLink();
            this.c1Command_AlignLeft = new C1.Win.Command.C1Command();
            this.c1CommandLink77 = new C1.Win.Command.C1CommandLink();
            this.c1Command_AlignCenter = new C1.Win.Command.C1Command();
            this.c1CommandLink78 = new C1.Win.Command.C1CommandLink();
            this.c1Command_AlignRight = new C1.Win.Command.C1Command();
            this.c1CommandLink79 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Justify = new C1.Win.Command.C1Command();
            this.c1CommandMenu_View = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink6 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NavigationPane = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink24 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NavBarNormal = new C1.Win.Command.C1Command();
            this.c1CommandLink27 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NavBarMinimized = new C1.Win.Command.C1Command();
            this.c1CommandLink28 = new C1.Win.Command.C1CommandLink();
            this.c1Command_NavBarOff = new C1.Win.Command.C1Command();
            this.c1CommandLink25 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Toolbars = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink26 = new C1.Win.Command.C1CommandLink();
            this.c1Command_ToolbarFile = new C1.Win.Command.C1Command();
            this.c1CommandLink46 = new C1.Win.Command.C1CommandLink();
            this.c1Command_ToolbarEdit = new C1.Win.Command.C1Command();
            this.c1CommandLink80 = new C1.Win.Command.C1CommandLink();
            this.c1Command_ToolbarFormat = new C1.Win.Command.C1Command();
            this.c1CommandLink95 = new C1.Win.Command.C1CommandLink();
            this.c1Command_ToolbarTools = new C1.Win.Command.C1Command();
            this.c1CommandLink35 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Statusbar = new C1.Win.Command.C1Command();
            this.c1CommandMenu_Tools = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink8 = new C1.Win.Command.C1CommandLink();
            this.c1Command_AddressBook = new C1.Win.Command.C1Command();
            this.c1CommandLink31 = new C1.Win.Command.C1CommandLink();
            this.c1Command_SpellCheck = new C1.Win.Command.C1Command();
            this.c1CommandLink32 = new C1.Win.Command.C1CommandLink();
            this.c1Command_InstantSearch = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink33 = new C1.Win.Command.C1CommandLink();
            this.c1Command_TextSearchMenu = new C1.Win.Command.C1CommandControl();
            this.c1CommandLink85 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Search = new C1.Win.Command.C1Command();
            this.c1CommandMenu_Help = new C1.Win.Command.C1CommandMenu();
            this.c1CommandLink10 = new C1.Win.Command.C1CommandLink();
            this.c1Command_Help = new C1.Win.Command.C1Command();
            this.c1CommandLink34 = new C1.Win.Command.C1CommandLink();
            this.c1Command_About = new C1.Win.Command.C1Command();
            this.c1Command_TextSearchBox = new C1.Win.Command.C1CommandControl();
            this.c1TextBox1 = new C1.Win.Input.C1TextBox();
            this.c1ContextMenu1 = new C1.Win.Command.C1ContextMenu();
            this.c1CommandLink86 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink87 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink88 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink89 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink90 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink91 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink92 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink93 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink94 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink81 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink82 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink83 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink84 = new C1.Win.Command.C1CommandLink();
            this.c1ToolBar_Format = new C1.Win.Command.C1ToolBar();
            this.c1CommandLink47 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink48 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink49 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink50 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink51 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink52 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink53 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink54 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink55 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink56 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink57 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink58 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink59 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink60 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink61 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink62 = new C1.Win.Command.C1CommandLink();
            this.c1ToolBar_Edit = new C1.Win.Command.C1ToolBar();
            this.c1CommandLink41 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink42 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink43 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink44 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink45 = new C1.Win.Command.C1CommandLink();
            this.c1ToolBar_File = new C1.Win.Command.C1ToolBar();
            this.c1CommandLink36 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink37 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink38 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink39 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink40 = new C1.Win.Command.C1CommandLink();
            this.c1MainMenu1 = new C1.Win.Command.C1MainMenu();
            this.c1CommandLink1 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink3 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink5 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink7 = new C1.Win.Command.C1CommandLink();
            this.c1CommandLink9 = new C1.Win.Command.C1CommandLink();
            ((System.ComponentModel.ISupportInitialize)(this.c1TextBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock1)).BeginInit();
            this.c1CommandDock1.SuspendLayout();
            this.c1ToolBar_Tools.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandHolder1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TextBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // c1TextBox2
            // 
            this.c1TextBox2.Location = new System.Drawing.Point(87, 6);
            this.c1TextBox2.Name = "c1TextBox2";
            this.c1TextBox2.Size = new System.Drawing.Size(100, 18);
            this.c1TextBox2.TabIndex = 9;
            this.c1TextBox2.Tag = null;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.c1CommandHolder1.SetC1ContextMenu(this.label1, this.c1ContextMenu1);
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(10, 81);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(5);
            this.label1.Size = new System.Drawing.Size(572, 355);
            this.label1.TabIndex = 19;
            this.label1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label1_MouseUp);
            // 
            // c1CommandDock4
            // 
            this.c1CommandDock4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.c1CommandDock4.Id = 10;
            this.c1CommandDock4.Location = new System.Drawing.Point(10, 436);
            this.c1CommandDock4.Name = "c1CommandDock4";
            this.c1CommandDock4.Size = new System.Drawing.Size(572, 10);
            // 
            // c1CommandDock3
            // 
            this.c1CommandDock3.Dock = System.Windows.Forms.DockStyle.Right;
            this.c1CommandDock3.Id = 6;
            this.c1CommandDock3.Location = new System.Drawing.Point(582, 81);
            this.c1CommandDock3.Name = "c1CommandDock3";
            this.c1CommandDock3.Size = new System.Drawing.Size(10, 365);
            // 
            // c1CommandDock2
            // 
            this.c1CommandDock2.Dock = System.Windows.Forms.DockStyle.Left;
            this.c1CommandDock2.Id = 3;
            this.c1CommandDock2.Location = new System.Drawing.Point(0, 81);
            this.c1CommandDock2.Name = "c1CommandDock2";
            this.c1CommandDock2.Size = new System.Drawing.Size(10, 365);
            // 
            // c1CommandDock1
            // 
            this.c1CommandDock1.Controls.Add(this.c1ToolBar_Tools);
            this.c1CommandDock1.Controls.Add(this.c1ToolBar_Format);
            this.c1CommandDock1.Controls.Add(this.c1ToolBar_Edit);
            this.c1CommandDock1.Controls.Add(this.c1ToolBar_File);
            this.c1CommandDock1.Id = 1;
            this.c1CommandDock1.Location = new System.Drawing.Point(0, 27);
            this.c1CommandDock1.Name = "c1CommandDock1";
            this.c1CommandDock1.Size = new System.Drawing.Size(592, 54);
            // 
            // c1ToolBar_Tools
            // 
            this.c1ToolBar_Tools.AccessibleName = "Tool Bar";
            this.c1ToolBar_Tools.CommandHolder = this.c1CommandHolder1;
            this.c1ToolBar_Tools.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink81,
            this.c1CommandLink82,
            this.c1CommandLink83,
            this.c1CommandLink84});
            this.c1ToolBar_Tools.Controls.Add(this.c1TextBox1);
            this.c1ToolBar_Tools.Location = new System.Drawing.Point(290, 0);
            this.c1ToolBar_Tools.Name = "c1ToolBar_Tools";
            this.c1ToolBar_Tools.Size = new System.Drawing.Size(234, 24);
            this.c1ToolBar_Tools.Text = "Tools";
            // 
            // c1CommandHolder1
            // 
            this.c1CommandHolder1.AutoSaveLayout = false;
            this.c1CommandHolder1.Commands.Add(this.c1CommandMenu_File);
            this.c1CommandHolder1.Commands.Add(this.c1Command_New);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NewMail);
            this.c1CommandHolder1.Commands.Add(this.c1CommandNewAppointment);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NewNote);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NewTask);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NewContact);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Open);
            this.c1CommandHolder1.Commands.Add(this.c1Command_OpenFile);
            this.c1CommandHolder1.Commands.Add(this.c1Command_OpenDatabase);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Save);
            this.c1CommandHolder1.Commands.Add(this.c1Command_SaveAll);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Print);
            this.c1CommandHolder1.Commands.Add(this.c1CommandMenu_Edit);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Undo);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Redo);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Cut);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Copy);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Paste);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Format);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Bold);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Italic);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Underline);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Strikethrough);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Subscript);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Superscript);
            this.c1CommandHolder1.Commands.Add(this.c1Command_ShrinkFont);
            this.c1CommandHolder1.Commands.Add(this.c1Command_GrowFont);
            this.c1CommandHolder1.Commands.Add(this.c1Command_DecIndent);
            this.c1CommandHolder1.Commands.Add(this.c1Command_IncIndent);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Bullets);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Numbering);
            this.c1CommandHolder1.Commands.Add(this.c1Command_AlignLeft);
            this.c1CommandHolder1.Commands.Add(this.c1Command_AlignCenter);
            this.c1CommandHolder1.Commands.Add(this.c1Command_AlignRight);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Justify);
            this.c1CommandHolder1.Commands.Add(this.c1CommandMenu_View);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NavigationPane);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NavBarNormal);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NavBarMinimized);
            this.c1CommandHolder1.Commands.Add(this.c1Command_NavBarOff);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Toolbars);
            this.c1CommandHolder1.Commands.Add(this.c1Command_ToolbarFile);
            this.c1CommandHolder1.Commands.Add(this.c1Command_ToolbarEdit);
            this.c1CommandHolder1.Commands.Add(this.c1Command_ToolbarFormat);
            this.c1CommandHolder1.Commands.Add(this.c1Command_ToolbarTools);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Statusbar);
            this.c1CommandHolder1.Commands.Add(this.c1CommandMenu_Tools);
            this.c1CommandHolder1.Commands.Add(this.c1Command_AddressBook);
            this.c1CommandHolder1.Commands.Add(this.c1Command_SpellCheck);
            this.c1CommandHolder1.Commands.Add(this.c1Command_InstantSearch);
            this.c1CommandHolder1.Commands.Add(this.c1Command_TextSearchMenu);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Search);
            this.c1CommandHolder1.Commands.Add(this.c1CommandMenu_Help);
            this.c1CommandHolder1.Commands.Add(this.c1Command_Help);
            this.c1CommandHolder1.Commands.Add(this.c1Command_About);
            this.c1CommandHolder1.Commands.Add(this.c1Command_TextSearchBox);
            this.c1CommandHolder1.Commands.Add(this.c1ContextMenu1);
            this.c1CommandHolder1.Owner = this;
            this.c1CommandHolder1.CustomizationStarted += new System.EventHandler(this.c1CommandHolder1_CustomizationStarted);
            this.c1CommandHolder1.CommandClick += new C1.Win.Command.CommandClickEventHandler(this.c1CommandHolder1_CommandClick);
            // 
            // c1CommandMenu_File
            // 
            this.c1CommandMenu_File.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink2,
            this.c1CommandLink12,
            this.c1CommandLink14,
            this.c1CommandLink30,
            this.c1CommandLink15});
            this.c1CommandMenu_File.HideNonRecentLinks = false;
            this.c1CommandMenu_File.Name = "c1CommandMenu_File";
            this.c1CommandMenu_File.Text = "&File";
            // 
            // c1CommandLink2
            // 
            this.c1CommandLink2.Command = this.c1Command_New;
            // 
            // c1Command_New
            // 
            this.c1Command_New.Category = "File";
            this.c1Command_New.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink11,
            this.c1CommandLink20,
            this.c1CommandLink21,
            this.c1CommandLink22,
            this.c1CommandLink23});
            this.c1Command_New.HideNonRecentLinks = false;
            this.c1Command_New.Image = global::CommandExplorer.Properties.Resources.New;
            this.c1Command_New.Name = "c1Command_New";
            this.c1Command_New.ShowToolTips = true;
            this.c1Command_New.Text = "Ne&w";
            // 
            // c1CommandLink11
            // 
            this.c1CommandLink11.Command = this.c1Command_NewMail;
            // 
            // c1Command_NewMail
            // 
            this.c1Command_NewMail.Category = "File";
            this.c1Command_NewMail.Image = global::CommandExplorer.Properties.Resources.NewEmail;
            this.c1Command_NewMail.Name = "c1Command_NewMail";
            this.c1Command_NewMail.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
            this.c1Command_NewMail.Text = "&Mail Message";
            // 
            // c1CommandLink20
            // 
            this.c1CommandLink20.Command = this.c1CommandNewAppointment;
            this.c1CommandLink20.Delimiter = true;
            this.c1CommandLink20.SortOrder = 1;
            // 
            // c1CommandNewAppointment
            // 
            this.c1CommandNewAppointment.Category = "File";
            this.c1CommandNewAppointment.Image = global::CommandExplorer.Properties.Resources.CalendarSchedule;
            this.c1CommandNewAppointment.Name = "c1CommandNewAppointment";
            this.c1CommandNewAppointment.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftA;
            this.c1CommandNewAppointment.Text = "&Appointment";
            // 
            // c1CommandLink21
            // 
            this.c1CommandLink21.Command = this.c1Command_NewNote;
            this.c1CommandLink21.SortOrder = 2;
            // 
            // c1Command_NewNote
            // 
            this.c1Command_NewNote.Category = "File";
            this.c1Command_NewNote.Image = global::CommandExplorer.Properties.Resources.NewNote;
            this.c1Command_NewNote.Name = "c1Command_NewNote";
            this.c1Command_NewNote.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftN;
            this.c1Command_NewNote.Text = "&Note";
            // 
            // c1CommandLink22
            // 
            this.c1CommandLink22.Command = this.c1Command_NewTask;
            this.c1CommandLink22.SortOrder = 3;
            // 
            // c1Command_NewTask
            // 
            this.c1Command_NewTask.Category = "File";
            this.c1Command_NewTask.Image = global::CommandExplorer.Properties.Resources.NewTask;
            this.c1Command_NewTask.Name = "c1Command_NewTask";
            this.c1Command_NewTask.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftK;
            this.c1Command_NewTask.Text = "Tas&k";
            // 
            // c1CommandLink23
            // 
            this.c1CommandLink23.Command = this.c1Command_NewContact;
            this.c1CommandLink23.SortOrder = 4;
            // 
            // c1Command_NewContact
            // 
            this.c1Command_NewContact.Category = "File";
            this.c1Command_NewContact.Image = global::CommandExplorer.Properties.Resources.NewContact;
            this.c1Command_NewContact.Name = "c1Command_NewContact";
            this.c1Command_NewContact.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftC;
            this.c1Command_NewContact.Text = "&Contact";
            // 
            // c1CommandLink12
            // 
            this.c1CommandLink12.Command = this.c1Command_Open;
            this.c1CommandLink12.SortOrder = 1;
            // 
            // c1Command_Open
            // 
            this.c1Command_Open.Category = "File";
            this.c1Command_Open.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink13,
            this.c1CommandLink29});
            this.c1Command_Open.HideNonRecentLinks = false;
            this.c1Command_Open.Image = global::CommandExplorer.Properties.Resources.FolderOpen;
            this.c1Command_Open.Name = "c1Command_Open";
            this.c1Command_Open.ShowToolTips = true;
            this.c1Command_Open.Text = "&Open";
            // 
            // c1CommandLink13
            // 
            this.c1CommandLink13.Command = this.c1Command_OpenFile;
            // 
            // c1Command_OpenFile
            // 
            this.c1Command_OpenFile.Category = "File";
            this.c1Command_OpenFile.Image = global::CommandExplorer.Properties.Resources.Open;
            this.c1Command_OpenFile.Name = "c1Command_OpenFile";
            this.c1Command_OpenFile.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
            this.c1Command_OpenFile.Text = "&File...";
            // 
            // c1CommandLink29
            // 
            this.c1CommandLink29.Command = this.c1Command_OpenDatabase;
            this.c1CommandLink29.SortOrder = 1;
            // 
            // c1Command_OpenDatabase
            // 
            this.c1Command_OpenDatabase.Category = "File";
            this.c1Command_OpenDatabase.Image = global::CommandExplorer.Properties.Resources.Database;
            this.c1Command_OpenDatabase.Name = "c1Command_OpenDatabase";
            this.c1Command_OpenDatabase.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftD;
            this.c1Command_OpenDatabase.Text = "&Database...";
            // 
            // c1CommandLink14
            // 
            this.c1CommandLink14.Command = this.c1Command_Save;
            this.c1CommandLink14.SortOrder = 2;
            // 
            // c1Command_Save
            // 
            this.c1Command_Save.Category = "File";
            this.c1Command_Save.Image = global::CommandExplorer.Properties.Resources.Save;
            this.c1Command_Save.Name = "c1Command_Save";
            this.c1Command_Save.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
            this.c1Command_Save.Text = "&Save";
            // 
            // c1CommandLink30
            // 
            this.c1CommandLink30.Command = this.c1Command_SaveAll;
            this.c1CommandLink30.SortOrder = 3;
            // 
            // c1Command_SaveAll
            // 
            this.c1Command_SaveAll.Category = "File";
            this.c1Command_SaveAll.Image = global::CommandExplorer.Properties.Resources.SaveAll;
            this.c1Command_SaveAll.Name = "c1Command_SaveAll";
            this.c1Command_SaveAll.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftS;
            this.c1Command_SaveAll.Text = "Save &All";
            // 
            // c1CommandLink15
            // 
            this.c1CommandLink15.Command = this.c1Command_Print;
            this.c1CommandLink15.SortOrder = 4;
            // 
            // c1Command_Print
            // 
            this.c1Command_Print.Category = "File";
            this.c1Command_Print.Image = global::CommandExplorer.Properties.Resources.Print;
            this.c1Command_Print.Name = "c1Command_Print";
            this.c1Command_Print.Shortcut = System.Windows.Forms.Shortcut.CtrlP;
            this.c1Command_Print.Text = "&Print";
            // 
            // c1CommandMenu_Edit
            // 
            this.c1CommandMenu_Edit.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink4,
            this.c1CommandLink16,
            this.c1CommandLink17,
            this.c1CommandLink18,
            this.c1CommandLink19,
            this.c1CommandLink63});
            this.c1CommandMenu_Edit.HideNonRecentLinks = false;
            this.c1CommandMenu_Edit.Name = "c1CommandMenu_Edit";
            this.c1CommandMenu_Edit.Text = "&Edit";
            // 
            // c1CommandLink4
            // 
            this.c1CommandLink4.Command = this.c1Command_Undo;
            // 
            // c1Command_Undo
            // 
            this.c1Command_Undo.Category = "Edit";
            this.c1Command_Undo.Image = global::CommandExplorer.Properties.Resources.Undo;
            this.c1Command_Undo.Name = "c1Command_Undo";
            this.c1Command_Undo.Shortcut = System.Windows.Forms.Shortcut.CtrlZ;
            this.c1Command_Undo.Text = "&Undo";
            // 
            // c1CommandLink16
            // 
            this.c1CommandLink16.Command = this.c1Command_Redo;
            this.c1CommandLink16.SortOrder = 1;
            // 
            // c1Command_Redo
            // 
            this.c1Command_Redo.Category = "Edit";
            this.c1Command_Redo.Enabled = false;
            this.c1Command_Redo.Image = global::CommandExplorer.Properties.Resources.Redo;
            this.c1Command_Redo.Name = "c1Command_Redo";
            this.c1Command_Redo.Shortcut = System.Windows.Forms.Shortcut.CtrlY;
            this.c1Command_Redo.Text = "&Redo";
            // 
            // c1CommandLink17
            // 
            this.c1CommandLink17.Command = this.c1Command_Cut;
            this.c1CommandLink17.Delimiter = true;
            this.c1CommandLink17.SortOrder = 2;
            this.c1CommandLink17.Text = "Cu&t";
            // 
            // c1Command_Cut
            // 
            this.c1Command_Cut.Category = "Edit";
            this.c1Command_Cut.Image = global::CommandExplorer.Properties.Resources.Cut;
            this.c1Command_Cut.Name = "c1Command_Cut";
            this.c1Command_Cut.Shortcut = System.Windows.Forms.Shortcut.CtrlX;
            this.c1Command_Cut.Text = "&Cut";
            // 
            // c1CommandLink18
            // 
            this.c1CommandLink18.Command = this.c1Command_Copy;
            this.c1CommandLink18.SortOrder = 3;
            // 
            // c1Command_Copy
            // 
            this.c1Command_Copy.Category = "Edit";
            this.c1Command_Copy.Image = global::CommandExplorer.Properties.Resources.Copy;
            this.c1Command_Copy.Name = "c1Command_Copy";
            this.c1Command_Copy.Shortcut = System.Windows.Forms.Shortcut.CtrlC;
            this.c1Command_Copy.Text = "&Copy";
            // 
            // c1CommandLink19
            // 
            this.c1CommandLink19.Command = this.c1Command_Paste;
            this.c1CommandLink19.SortOrder = 4;
            // 
            // c1Command_Paste
            // 
            this.c1Command_Paste.Category = "Edit";
            this.c1Command_Paste.Image = global::CommandExplorer.Properties.Resources.Paste;
            this.c1Command_Paste.Name = "c1Command_Paste";
            this.c1Command_Paste.Shortcut = System.Windows.Forms.Shortcut.CtrlP;
            this.c1Command_Paste.Text = "&Paste";
            // 
            // c1CommandLink63
            // 
            this.c1CommandLink63.Command = this.c1Command_Format;
            this.c1CommandLink63.SortOrder = 5;
            // 
            // c1Command_Format
            // 
            this.c1Command_Format.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink64,
            this.c1CommandLink65,
            this.c1CommandLink66,
            this.c1CommandLink67,
            this.c1CommandLink68,
            this.c1CommandLink69,
            this.c1CommandLink70,
            this.c1CommandLink71,
            this.c1CommandLink72,
            this.c1CommandLink73,
            this.c1CommandLink74,
            this.c1CommandLink75,
            this.c1CommandLink76,
            this.c1CommandLink77,
            this.c1CommandLink78,
            this.c1CommandLink79});
            this.c1Command_Format.HideNonRecentLinks = false;
            this.c1Command_Format.Name = "c1Command_Format";
            this.c1Command_Format.Text = "&Format";
            // 
            // c1CommandLink64
            // 
            this.c1CommandLink64.Command = this.c1Command_Bold;
            // 
            // c1Command_Bold
            // 
            this.c1Command_Bold.Category = "Format";
            this.c1Command_Bold.CheckAutoToggle = true;
            this.c1Command_Bold.Image = global::CommandExplorer.Properties.Resources.Bold;
            this.c1Command_Bold.Name = "c1Command_Bold";
            this.c1Command_Bold.Shortcut = System.Windows.Forms.Shortcut.CtrlB;
            this.c1Command_Bold.Text = "&Bold";
            // 
            // c1CommandLink65
            // 
            this.c1CommandLink65.Command = this.c1Command_Italic;
            this.c1CommandLink65.SortOrder = 1;
            // 
            // c1Command_Italic
            // 
            this.c1Command_Italic.Category = "Format";
            this.c1Command_Italic.CheckAutoToggle = true;
            this.c1Command_Italic.Image = global::CommandExplorer.Properties.Resources.Italic;
            this.c1Command_Italic.Name = "c1Command_Italic";
            this.c1Command_Italic.Shortcut = System.Windows.Forms.Shortcut.CtrlI;
            this.c1Command_Italic.Text = "&Italic";
            // 
            // c1CommandLink66
            // 
            this.c1CommandLink66.Command = this.c1Command_Underline;
            this.c1CommandLink66.SortOrder = 2;
            // 
            // c1Command_Underline
            // 
            this.c1Command_Underline.Category = "Format";
            this.c1Command_Underline.CheckAutoToggle = true;
            this.c1Command_Underline.Image = global::CommandExplorer.Properties.Resources.Underline;
            this.c1Command_Underline.Name = "c1Command_Underline";
            this.c1Command_Underline.Shortcut = System.Windows.Forms.Shortcut.CtrlU;
            this.c1Command_Underline.Text = "&Underline";
            // 
            // c1CommandLink67
            // 
            this.c1CommandLink67.Command = this.c1Command_Strikethrough;
            this.c1CommandLink67.SortOrder = 3;
            // 
            // c1Command_Strikethrough
            // 
            this.c1Command_Strikethrough.Category = "Format";
            this.c1Command_Strikethrough.CheckAutoToggle = true;
            this.c1Command_Strikethrough.Image = global::CommandExplorer.Properties.Resources.Strikethrough;
            this.c1Command_Strikethrough.Name = "c1Command_Strikethrough";
            this.c1Command_Strikethrough.Text = "&Strikethrough";
            // 
            // c1CommandLink68
            // 
            this.c1CommandLink68.Command = this.c1Command_Subscript;
            this.c1CommandLink68.Delimiter = true;
            this.c1CommandLink68.SortOrder = 4;
            // 
            // c1Command_Subscript
            // 
            this.c1Command_Subscript.Category = "Format";
            this.c1Command_Subscript.Image = global::CommandExplorer.Properties.Resources.Subscript;
            this.c1Command_Subscript.Name = "c1Command_Subscript";
            this.c1Command_Subscript.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftS;
            this.c1Command_Subscript.Text = "Subscript";
            // 
            // c1CommandLink69
            // 
            this.c1CommandLink69.Command = this.c1Command_Superscript;
            this.c1CommandLink69.SortOrder = 5;
            // 
            // c1Command_Superscript
            // 
            this.c1Command_Superscript.Category = "Format";
            this.c1Command_Superscript.Image = global::CommandExplorer.Properties.Resources.Superscript;
            this.c1Command_Superscript.Name = "c1Command_Superscript";
            this.c1Command_Superscript.Shortcut = System.Windows.Forms.Shortcut.CtrlShift6;
            this.c1Command_Superscript.Text = "Superscript";
            // 
            // c1CommandLink70
            // 
            this.c1CommandLink70.Command = this.c1Command_ShrinkFont;
            this.c1CommandLink70.SortOrder = 6;
            // 
            // c1Command_ShrinkFont
            // 
            this.c1Command_ShrinkFont.Category = "Format";
            this.c1Command_ShrinkFont.Image = global::CommandExplorer.Properties.Resources.ShrinkFont;
            this.c1Command_ShrinkFont.Name = "c1Command_ShrinkFont";
            this.c1Command_ShrinkFont.Text = "Shrink Font";
            // 
            // c1CommandLink71
            // 
            this.c1CommandLink71.Command = this.c1Command_GrowFont;
            this.c1CommandLink71.SortOrder = 7;
            // 
            // c1Command_GrowFont
            // 
            this.c1Command_GrowFont.Category = "Format";
            this.c1Command_GrowFont.Image = global::CommandExplorer.Properties.Resources.GrowFont;
            this.c1Command_GrowFont.Name = "c1Command_GrowFont";
            this.c1Command_GrowFont.Text = "Grow Font";
            // 
            // c1CommandLink72
            // 
            this.c1CommandLink72.Command = this.c1Command_DecIndent;
            this.c1CommandLink72.NewColumn = true;
            this.c1CommandLink72.SortOrder = 8;
            // 
            // c1Command_DecIndent
            // 
            this.c1Command_DecIndent.Category = "Format";
            this.c1Command_DecIndent.Image = global::CommandExplorer.Properties.Resources.DecreaseIndent;
            this.c1Command_DecIndent.Name = "c1Command_DecIndent";
            this.c1Command_DecIndent.Text = "Decrease Indent";
            // 
            // c1CommandLink73
            // 
            this.c1CommandLink73.Command = this.c1Command_IncIndent;
            this.c1CommandLink73.SortOrder = 9;
            // 
            // c1Command_IncIndent
            // 
            this.c1Command_IncIndent.Category = "Format";
            this.c1Command_IncIndent.Image = global::CommandExplorer.Properties.Resources.IncreaseIndent;
            this.c1Command_IncIndent.Name = "c1Command_IncIndent";
            this.c1Command_IncIndent.Text = "Increase Indent";
            // 
            // c1CommandLink74
            // 
            this.c1CommandLink74.Command = this.c1Command_Bullets;
            this.c1CommandLink74.Delimiter = true;
            this.c1CommandLink74.SortOrder = 10;
            // 
            // c1Command_Bullets
            // 
            this.c1Command_Bullets.Category = "Format";
            this.c1Command_Bullets.Image = global::CommandExplorer.Properties.Resources.Bullets;
            this.c1Command_Bullets.Name = "c1Command_Bullets";
            this.c1Command_Bullets.Text = "Bullets";
            // 
            // c1CommandLink75
            // 
            this.c1CommandLink75.Command = this.c1Command_Numbering;
            this.c1CommandLink75.SortOrder = 11;
            // 
            // c1Command_Numbering
            // 
            this.c1Command_Numbering.Category = "Format";
            this.c1Command_Numbering.Image = global::CommandExplorer.Properties.Resources.Numbering;
            this.c1Command_Numbering.Name = "c1Command_Numbering";
            this.c1Command_Numbering.Text = "Numbering";
            // 
            // c1CommandLink76
            // 
            this.c1CommandLink76.Command = this.c1Command_AlignLeft;
            this.c1CommandLink76.Delimiter = true;
            this.c1CommandLink76.SortOrder = 12;
            // 
            // c1Command_AlignLeft
            // 
            this.c1Command_AlignLeft.Category = "Format";
            this.c1Command_AlignLeft.CheckAutoToggle = true;
            this.c1Command_AlignLeft.Image = global::CommandExplorer.Properties.Resources.AlignTextLeft;
            this.c1Command_AlignLeft.Name = "c1Command_AlignLeft";
            this.c1Command_AlignLeft.Shortcut = System.Windows.Forms.Shortcut.CtrlL;
            this.c1Command_AlignLeft.Text = "Align Text &Left";
            this.c1Command_AlignLeft.Click += new C1.Win.Command.ClickEventHandler(this.c1Command_AlignCenter_Click);
            // 
            // c1CommandLink77
            // 
            this.c1CommandLink77.Command = this.c1Command_AlignCenter;
            this.c1CommandLink77.SortOrder = 13;
            // 
            // c1Command_AlignCenter
            // 
            this.c1Command_AlignCenter.Category = "Format";
            this.c1Command_AlignCenter.CheckAutoToggle = true;
            this.c1Command_AlignCenter.Checked = true;
            this.c1Command_AlignCenter.Image = global::CommandExplorer.Properties.Resources.AlignTextCenter;
            this.c1Command_AlignCenter.Name = "c1Command_AlignCenter";
            this.c1Command_AlignCenter.Shortcut = System.Windows.Forms.Shortcut.CtrlE;
            this.c1Command_AlignCenter.Text = "Align Text C&enter";
            this.c1Command_AlignCenter.Click += new C1.Win.Command.ClickEventHandler(this.c1Command_AlignCenter_Click);
            // 
            // c1CommandLink78
            // 
            this.c1CommandLink78.Command = this.c1Command_AlignRight;
            this.c1CommandLink78.SortOrder = 14;
            // 
            // c1Command_AlignRight
            // 
            this.c1Command_AlignRight.Category = "Format";
            this.c1Command_AlignRight.CheckAutoToggle = true;
            this.c1Command_AlignRight.Image = global::CommandExplorer.Properties.Resources.AlignTextRight;
            this.c1Command_AlignRight.Name = "c1Command_AlignRight";
            this.c1Command_AlignRight.Shortcut = System.Windows.Forms.Shortcut.CtrlR;
            this.c1Command_AlignRight.Text = "Align Text &Right";
            this.c1Command_AlignRight.Click += new C1.Win.Command.ClickEventHandler(this.c1Command_AlignCenter_Click);
            // 
            // c1CommandLink79
            // 
            this.c1CommandLink79.Command = this.c1Command_Justify;
            this.c1CommandLink79.SortOrder = 15;
            // 
            // c1Command_Justify
            // 
            this.c1Command_Justify.Category = "Format";
            this.c1Command_Justify.CheckAutoToggle = true;
            this.c1Command_Justify.Image = global::CommandExplorer.Properties.Resources.AlignTextJustify;
            this.c1Command_Justify.Name = "c1Command_Justify";
            this.c1Command_Justify.Shortcut = System.Windows.Forms.Shortcut.CtrlJ;
            this.c1Command_Justify.Text = "&Justify";
            this.c1Command_Justify.Click += new C1.Win.Command.ClickEventHandler(this.c1Command_AlignCenter_Click);
            // 
            // c1CommandMenu_View
            // 
            this.c1CommandMenu_View.Category = "View";
            this.c1CommandMenu_View.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink6,
            this.c1CommandLink25,
            this.c1CommandLink35});
            this.c1CommandMenu_View.HideNonRecentLinks = false;
            this.c1CommandMenu_View.Name = "c1CommandMenu_View";
            this.c1CommandMenu_View.Text = "&View";
            // 
            // c1CommandLink6
            // 
            this.c1CommandLink6.Command = this.c1Command_NavigationPane;
            // 
            // c1Command_NavigationPane
            // 
            this.c1Command_NavigationPane.Category = "View";
            this.c1Command_NavigationPane.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink24,
            this.c1CommandLink27,
            this.c1CommandLink28});
            this.c1Command_NavigationPane.HideNonRecentLinks = false;
            this.c1Command_NavigationPane.Name = "c1Command_NavigationPane";
            this.c1Command_NavigationPane.Text = "&Navigation Pane";
            // 
            // c1CommandLink24
            // 
            this.c1CommandLink24.Command = this.c1Command_NavBarNormal;
            // 
            // c1Command_NavBarNormal
            // 
            this.c1Command_NavBarNormal.Category = "View";
            this.c1Command_NavBarNormal.CheckAutoToggle = true;
            this.c1Command_NavBarNormal.Checked = true;
            this.c1Command_NavBarNormal.Name = "c1Command_NavBarNormal";
            this.c1Command_NavBarNormal.Text = "&Normal";
            this.c1Command_NavBarNormal.Click += new C1.Win.Command.ClickEventHandler(this.c1Command_NavBarNormal_Click);
            // 
            // c1CommandLink27
            // 
            this.c1CommandLink27.Command = this.c1Command_NavBarMinimized;
            this.c1CommandLink27.SortOrder = 1;
            // 
            // c1Command_NavBarMinimized
            // 
            this.c1Command_NavBarMinimized.Category = "View";
            this.c1Command_NavBarMinimized.CheckAutoToggle = true;
            this.c1Command_NavBarMinimized.Name = "c1Command_NavBarMinimized";
            this.c1Command_NavBarMinimized.Text = "&Minimized";
            this.c1Command_NavBarMinimized.Click += new C1.Win.Command.ClickEventHandler(this.c1Command_NavBarNormal_Click);
            // 
            // c1CommandLink28
            // 
            this.c1CommandLink28.Command = this.c1Command_NavBarOff;
            this.c1CommandLink28.SortOrder = 2;
            // 
            // c1Command_NavBarOff
            // 
            this.c1Command_NavBarOff.Category = "View";
            this.c1Command_NavBarOff.CheckAutoToggle = true;
            this.c1Command_NavBarOff.Name = "c1Command_NavBarOff";
            this.c1Command_NavBarOff.Shortcut = System.Windows.Forms.Shortcut.AltF1;
            this.c1Command_NavBarOff.Text = "&Closed";
            this.c1Command_NavBarOff.Click += new C1.Win.Command.ClickEventHandler(this.c1Command_NavBarNormal_Click);
            // 
            // c1CommandLink25
            // 
            this.c1CommandLink25.Command = this.c1Command_Toolbars;
            this.c1CommandLink25.SortOrder = 1;
            // 
            // c1Command_Toolbars
            // 
            this.c1Command_Toolbars.Category = "View";
            this.c1Command_Toolbars.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink26,
            this.c1CommandLink46,
            this.c1CommandLink80,
            this.c1CommandLink95});
            this.c1Command_Toolbars.HideNonRecentLinks = false;
            this.c1Command_Toolbars.Name = "c1Command_Toolbars";
            this.c1Command_Toolbars.Text = "&Toolbars";
            // 
            // c1CommandLink26
            // 
            this.c1CommandLink26.Command = this.c1Command_ToolbarFile;
            this.c1CommandLink26.Text = "File";
            // 
            // c1Command_ToolbarFile
            // 
            this.c1Command_ToolbarFile.CheckAutoToggle = true;
            this.c1Command_ToolbarFile.Checked = true;
            this.c1Command_ToolbarFile.Name = "c1Command_ToolbarFile";
            this.c1Command_ToolbarFile.Text = "&File";
            this.c1Command_ToolbarFile.CheckedChanged += new C1.Win.Command.CheckedChangedEventHandler(this.c1Command_ToolbarFile_CheckedChanged);
            // 
            // c1CommandLink46
            // 
            this.c1CommandLink46.Command = this.c1Command_ToolbarEdit;
            this.c1CommandLink46.SortOrder = 1;
            this.c1CommandLink46.Text = "Edit";
            // 
            // c1Command_ToolbarEdit
            // 
            this.c1Command_ToolbarEdit.CheckAutoToggle = true;
            this.c1Command_ToolbarEdit.Checked = true;
            this.c1Command_ToolbarEdit.Name = "c1Command_ToolbarEdit";
            this.c1Command_ToolbarEdit.Text = "&Edit";
            this.c1Command_ToolbarEdit.CheckedChanged += new C1.Win.Command.CheckedChangedEventHandler(this.c1Command_ToolbarFile_CheckedChanged);
            // 
            // c1CommandLink80
            // 
            this.c1CommandLink80.Command = this.c1Command_ToolbarFormat;
            this.c1CommandLink80.SortOrder = 2;
            // 
            // c1Command_ToolbarFormat
            // 
            this.c1Command_ToolbarFormat.CheckAutoToggle = true;
            this.c1Command_ToolbarFormat.Checked = true;
            this.c1Command_ToolbarFormat.Name = "c1Command_ToolbarFormat";
            this.c1Command_ToolbarFormat.Text = "Format";
            this.c1Command_ToolbarFormat.CheckedChanged += new C1.Win.Command.CheckedChangedEventHandler(this.c1Command_ToolbarFile_CheckedChanged);
            // 
            // c1CommandLink95
            // 
            this.c1CommandLink95.Command = this.c1Command_ToolbarTools;
            this.c1CommandLink95.SortOrder = 3;
            // 
            // c1Command_ToolbarTools
            // 
            this.c1Command_ToolbarTools.CheckAutoToggle = true;
            this.c1Command_ToolbarTools.Checked = true;
            this.c1Command_ToolbarTools.Name = "c1Command_ToolbarTools";
            this.c1Command_ToolbarTools.Text = "Tools";
            this.c1Command_ToolbarTools.CheckedChanged += new C1.Win.Command.CheckedChangedEventHandler(this.c1Command_ToolbarFile_CheckedChanged);
            // 
            // c1CommandLink35
            // 
            this.c1CommandLink35.Command = this.c1Command_Statusbar;
            this.c1CommandLink35.SortOrder = 2;
            // 
            // c1Command_Statusbar
            // 
            this.c1Command_Statusbar.Category = "View";
            this.c1Command_Statusbar.CheckAutoToggle = true;
            this.c1Command_Statusbar.Checked = true;
            this.c1Command_Statusbar.Name = "c1Command_Statusbar";
            this.c1Command_Statusbar.Text = "&Statusbar";
            // 
            // c1CommandMenu_Tools
            // 
            this.c1CommandMenu_Tools.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink8,
            this.c1CommandLink31,
            this.c1CommandLink32});
            this.c1CommandMenu_Tools.HideNonRecentLinks = false;
            this.c1CommandMenu_Tools.Name = "c1CommandMenu_Tools";
            this.c1CommandMenu_Tools.Text = "&Tools";
            // 
            // c1CommandLink8
            // 
            this.c1CommandLink8.Command = this.c1Command_AddressBook;
            this.c1CommandLink8.Text = "Address &Book...";
            this.c1CommandLink8.ToolTipText = "Open Address Book";
            // 
            // c1Command_AddressBook
            // 
            this.c1Command_AddressBook.Category = "Tools";
            this.c1Command_AddressBook.Image = global::CommandExplorer.Properties.Resources.AddressBook;
            this.c1Command_AddressBook.Name = "c1Command_AddressBook";
            this.c1Command_AddressBook.Text = "&Address Book";
            // 
            // c1CommandLink31
            // 
            this.c1CommandLink31.Command = this.c1Command_SpellCheck;
            this.c1CommandLink31.Delimiter = true;
            this.c1CommandLink31.SortOrder = 1;
            // 
            // c1Command_SpellCheck
            // 
            this.c1Command_SpellCheck.Category = "Tools";
            this.c1Command_SpellCheck.Image = global::CommandExplorer.Properties.Resources.Spelling;
            this.c1Command_SpellCheck.Name = "c1Command_SpellCheck";
            this.c1Command_SpellCheck.Text = "&Spell Check...";
            // 
            // c1CommandLink32
            // 
            this.c1CommandLink32.Command = this.c1Command_InstantSearch;
            this.c1CommandLink32.SortOrder = 2;
            // 
            // c1Command_InstantSearch
            // 
            this.c1Command_InstantSearch.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink33,
            this.c1CommandLink85});
            this.c1Command_InstantSearch.HideNonRecentLinks = false;
            this.c1Command_InstantSearch.Name = "c1Command_InstantSearch";
            this.c1Command_InstantSearch.Text = "&Instant Search";
            // 
            // c1CommandLink33
            // 
            this.c1CommandLink33.Command = this.c1Command_TextSearchMenu;
            // 
            // c1Command_TextSearchMenu
            // 
            this.c1Command_TextSearchMenu.Control = this.c1TextBox2;
            this.c1Command_TextSearchMenu.Name = "c1Command_TextSearchMenu";
            this.c1Command_TextSearchMenu.Text = "Search:";
            // 
            // c1CommandLink85
            // 
            this.c1CommandLink85.Command = this.c1Command_Search;
            this.c1CommandLink85.SortOrder = 1;
            // 
            // c1Command_Search
            // 
            this.c1Command_Search.Category = "Tools";
            this.c1Command_Search.Image = global::CommandExplorer.Properties.Resources.Zoom;
            this.c1Command_Search.Name = "c1Command_Search";
            this.c1Command_Search.Text = "Perform Search";
            // 
            // c1CommandMenu_Help
            // 
            this.c1CommandMenu_Help.Category = "Help";
            this.c1CommandMenu_Help.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink10,
            this.c1CommandLink34});
            this.c1CommandMenu_Help.HideNonRecentLinks = false;
            this.c1CommandMenu_Help.Name = "c1CommandMenu_Help";
            this.c1CommandMenu_Help.Text = "&Help";
            // 
            // c1CommandLink10
            // 
            this.c1CommandLink10.Command = this.c1Command_Help;
            this.c1CommandLink10.Text = "C1Command &Help";
            // 
            // c1Command_Help
            // 
            this.c1Command_Help.Category = "Help";
            this.c1Command_Help.Image = global::CommandExplorer.Properties.Resources.Help;
            this.c1Command_Help.Name = "c1Command_Help";
            this.c1Command_Help.Text = "C1Command Help";
            // 
            // c1CommandLink34
            // 
            this.c1CommandLink34.Command = this.c1Command_About;
            this.c1CommandLink34.SortOrder = 1;
            // 
            // c1Command_About
            // 
            this.c1Command_About.Category = "Help";
            this.c1Command_About.Name = "c1Command_About";
            this.c1Command_About.Text = "&About C1Command...";
            // 
            // c1Command_TextSearchBox
            // 
            this.c1Command_TextSearchBox.Category = "Tools";
            this.c1Command_TextSearchBox.Control = this.c1TextBox1;
            this.c1Command_TextSearchBox.Name = "c1Command_TextSearchBox";
            this.c1Command_TextSearchBox.Text = "Search:";
            // 
            // c1TextBox1
            // 
            this.c1TextBox1.EmptyAsNull = true;
            this.c1TextBox1.Location = new System.Drawing.Point(109, 3);
            this.c1TextBox1.Name = "c1TextBox1";
            this.c1TextBox1.NullText = "Search";
            this.c1TextBox1.Size = new System.Drawing.Size(100, 18);
            this.c1TextBox1.TabIndex = 4;
            this.c1TextBox1.Tag = null;
            // 
            // c1ContextMenu1
            // 
            this.c1ContextMenu1.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink86,
            this.c1CommandLink87,
            this.c1CommandLink88,
            this.c1CommandLink89,
            this.c1CommandLink90,
            this.c1CommandLink91,
            this.c1CommandLink92,
            this.c1CommandLink93,
            this.c1CommandLink94});
            this.c1ContextMenu1.Name = "c1ContextMenu1";
            // 
            // c1CommandLink86
            // 
            this.c1CommandLink86.Command = this.c1Command_Undo;
            // 
            // c1CommandLink87
            // 
            this.c1CommandLink87.Command = this.c1Command_Redo;
            this.c1CommandLink87.SortOrder = 1;
            // 
            // c1CommandLink88
            // 
            this.c1CommandLink88.Command = this.c1Command_Cut;
            this.c1CommandLink88.Delimiter = true;
            this.c1CommandLink88.SortOrder = 2;
            // 
            // c1CommandLink89
            // 
            this.c1CommandLink89.Command = this.c1Command_Copy;
            this.c1CommandLink89.SortOrder = 3;
            // 
            // c1CommandLink90
            // 
            this.c1CommandLink90.Command = this.c1Command_Paste;
            this.c1CommandLink90.SortOrder = 4;
            // 
            // c1CommandLink91
            // 
            this.c1CommandLink91.Command = this.c1Command_Bold;
            this.c1CommandLink91.NewColumn = true;
            this.c1CommandLink91.SortOrder = 5;
            // 
            // c1CommandLink92
            // 
            this.c1CommandLink92.Command = this.c1Command_Italic;
            this.c1CommandLink92.SortOrder = 6;
            // 
            // c1CommandLink93
            // 
            this.c1CommandLink93.Command = this.c1Command_Underline;
            this.c1CommandLink93.SortOrder = 7;
            // 
            // c1CommandLink94
            // 
            this.c1CommandLink94.Command = this.c1Command_Strikethrough;
            this.c1CommandLink94.SortOrder = 8;
            // 
            // c1CommandLink81
            // 
            this.c1CommandLink81.Command = this.c1Command_AddressBook;
            // 
            // c1CommandLink82
            // 
            this.c1CommandLink82.Command = this.c1Command_SpellCheck;
            this.c1CommandLink82.SortOrder = 1;
            // 
            // c1CommandLink83
            // 
            this.c1CommandLink83.ButtonLook = C1.Win.Command.ButtonLookFlags.Text;
            this.c1CommandLink83.Command = this.c1Command_TextSearchBox;
            this.c1CommandLink83.Delimiter = true;
            this.c1CommandLink83.SortOrder = 2;
            this.c1CommandLink83.Text = "Search:";
            // 
            // c1CommandLink84
            // 
            this.c1CommandLink84.Command = this.c1Command_Search;
            this.c1CommandLink84.SortOrder = 3;
            // 
            // c1ToolBar_Format
            // 
            this.c1ToolBar_Format.AccessibleName = "Tool Bar";
            this.c1ToolBar_Format.CommandHolder = this.c1CommandHolder1;
            this.c1ToolBar_Format.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink47,
            this.c1CommandLink48,
            this.c1CommandLink49,
            this.c1CommandLink50,
            this.c1CommandLink51,
            this.c1CommandLink52,
            this.c1CommandLink53,
            this.c1CommandLink54,
            this.c1CommandLink55,
            this.c1CommandLink56,
            this.c1CommandLink57,
            this.c1CommandLink58,
            this.c1CommandLink59,
            this.c1CommandLink60,
            this.c1CommandLink61,
            this.c1CommandLink62});
            this.c1ToolBar_Format.CustomizeButton = true;
            this.c1ToolBar_Format.Location = new System.Drawing.Point(0, 24);
            this.c1ToolBar_Format.Name = "c1ToolBar_Format";
            this.c1ToolBar_Format.Size = new System.Drawing.Size(413, 24);
            this.c1ToolBar_Format.Text = "Format";
            // 
            // c1CommandLink47
            // 
            this.c1CommandLink47.Command = this.c1Command_Bold;
            // 
            // c1CommandLink48
            // 
            this.c1CommandLink48.Command = this.c1Command_Italic;
            this.c1CommandLink48.SortOrder = 1;
            // 
            // c1CommandLink49
            // 
            this.c1CommandLink49.Command = this.c1Command_Underline;
            this.c1CommandLink49.SortOrder = 2;
            // 
            // c1CommandLink50
            // 
            this.c1CommandLink50.Command = this.c1Command_Strikethrough;
            this.c1CommandLink50.SortOrder = 3;
            // 
            // c1CommandLink51
            // 
            this.c1CommandLink51.Command = this.c1Command_Subscript;
            this.c1CommandLink51.Delimiter = true;
            this.c1CommandLink51.SortOrder = 4;
            // 
            // c1CommandLink52
            // 
            this.c1CommandLink52.Command = this.c1Command_Superscript;
            this.c1CommandLink52.SortOrder = 5;
            // 
            // c1CommandLink53
            // 
            this.c1CommandLink53.Command = this.c1Command_ShrinkFont;
            this.c1CommandLink53.SortOrder = 6;
            // 
            // c1CommandLink54
            // 
            this.c1CommandLink54.Command = this.c1Command_GrowFont;
            this.c1CommandLink54.SortOrder = 7;
            // 
            // c1CommandLink55
            // 
            this.c1CommandLink55.Command = this.c1Command_DecIndent;
            this.c1CommandLink55.Delimiter = true;
            this.c1CommandLink55.SortOrder = 8;
            // 
            // c1CommandLink56
            // 
            this.c1CommandLink56.Command = this.c1Command_IncIndent;
            this.c1CommandLink56.SortOrder = 9;
            // 
            // c1CommandLink57
            // 
            this.c1CommandLink57.Command = this.c1Command_Bullets;
            this.c1CommandLink57.Delimiter = true;
            this.c1CommandLink57.SortOrder = 10;
            // 
            // c1CommandLink58
            // 
            this.c1CommandLink58.Command = this.c1Command_Numbering;
            this.c1CommandLink58.SortOrder = 11;
            // 
            // c1CommandLink59
            // 
            this.c1CommandLink59.Command = this.c1Command_AlignLeft;
            this.c1CommandLink59.Delimiter = true;
            this.c1CommandLink59.SortOrder = 12;
            // 
            // c1CommandLink60
            // 
            this.c1CommandLink60.Command = this.c1Command_AlignCenter;
            this.c1CommandLink60.SortOrder = 13;
            // 
            // c1CommandLink61
            // 
            this.c1CommandLink61.Command = this.c1Command_AlignRight;
            this.c1CommandLink61.SortOrder = 14;
            // 
            // c1CommandLink62
            // 
            this.c1CommandLink62.Command = this.c1Command_Justify;
            this.c1CommandLink62.SortOrder = 15;
            // 
            // c1ToolBar_Edit
            // 
            this.c1ToolBar_Edit.AccessibleName = "Tool Bar";
            this.c1ToolBar_Edit.CommandHolder = this.c1CommandHolder1;
            this.c1ToolBar_Edit.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink41,
            this.c1CommandLink42,
            this.c1CommandLink43,
            this.c1CommandLink44,
            this.c1CommandLink45});
            this.c1ToolBar_Edit.Location = new System.Drawing.Point(154, 0);
            this.c1ToolBar_Edit.Name = "c1ToolBar_Edit";
            this.c1ToolBar_Edit.Size = new System.Drawing.Size(128, 24);
            this.c1ToolBar_Edit.Text = "Edit";
            // 
            // c1CommandLink41
            // 
            this.c1CommandLink41.Command = this.c1Command_Undo;
            // 
            // c1CommandLink42
            // 
            this.c1CommandLink42.Command = this.c1Command_Redo;
            this.c1CommandLink42.SortOrder = 1;
            // 
            // c1CommandLink43
            // 
            this.c1CommandLink43.Command = this.c1Command_Cut;
            this.c1CommandLink43.Delimiter = true;
            this.c1CommandLink43.SortOrder = 2;
            // 
            // c1CommandLink44
            // 
            this.c1CommandLink44.Command = this.c1Command_Copy;
            this.c1CommandLink44.SortOrder = 3;
            // 
            // c1CommandLink45
            // 
            this.c1CommandLink45.Command = this.c1Command_Paste;
            this.c1CommandLink45.SortOrder = 4;
            // 
            // c1ToolBar_File
            // 
            this.c1ToolBar_File.AccessibleName = "Tool Bar";
            this.c1ToolBar_File.CommandHolder = this.c1CommandHolder1;
            this.c1ToolBar_File.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink36,
            this.c1CommandLink37,
            this.c1CommandLink38,
            this.c1CommandLink39,
            this.c1CommandLink40});
            this.c1ToolBar_File.Location = new System.Drawing.Point(1, 0);
            this.c1ToolBar_File.Name = "c1ToolBar_File";
            this.c1ToolBar_File.Size = new System.Drawing.Size(149, 24);
            this.c1ToolBar_File.Text = "File";
            // 
            // c1CommandLink36
            // 
            this.c1CommandLink36.Command = this.c1Command_New;
            // 
            // c1CommandLink37
            // 
            this.c1CommandLink37.Command = this.c1Command_Open;
            this.c1CommandLink37.SortOrder = 1;
            // 
            // c1CommandLink38
            // 
            this.c1CommandLink38.Command = this.c1Command_Save;
            this.c1CommandLink38.SortOrder = 2;
            // 
            // c1CommandLink39
            // 
            this.c1CommandLink39.Command = this.c1Command_SaveAll;
            this.c1CommandLink39.SortOrder = 3;
            // 
            // c1CommandLink40
            // 
            this.c1CommandLink40.Command = this.c1Command_Print;
            this.c1CommandLink40.SortOrder = 4;
            // 
            // c1MainMenu1
            // 
            this.c1MainMenu1.AccessibleName = "Menu Bar";
            this.c1MainMenu1.CommandHolder = this.c1CommandHolder1;
            this.c1MainMenu1.CommandLinks.AddRange(new C1.Win.Command.C1CommandLink[] {
            this.c1CommandLink1,
            this.c1CommandLink3,
            this.c1CommandLink5,
            this.c1CommandLink7,
            this.c1CommandLink9});
            this.c1MainMenu1.Dock = System.Windows.Forms.DockStyle.Top;
            this.c1MainMenu1.Location = new System.Drawing.Point(0, 0);
            this.c1MainMenu1.Name = "c1MainMenu1";
            this.c1MainMenu1.Size = new System.Drawing.Size(592, 27);
            // 
            // c1CommandLink1
            // 
            this.c1CommandLink1.Command = this.c1CommandMenu_File;
            // 
            // c1CommandLink3
            // 
            this.c1CommandLink3.Command = this.c1CommandMenu_Edit;
            this.c1CommandLink3.SortOrder = 1;
            // 
            // c1CommandLink5
            // 
            this.c1CommandLink5.Command = this.c1CommandMenu_View;
            this.c1CommandLink5.SortOrder = 2;
            // 
            // c1CommandLink7
            // 
            this.c1CommandLink7.Command = this.c1CommandMenu_Tools;
            this.c1CommandLink7.SortOrder = 3;
            // 
            // c1CommandLink9
            // 
            this.c1CommandLink9.Command = this.c1CommandMenu_Help;
            this.c1CommandLink9.SortOrder = 4;
            // 
            // Overview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 446);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.c1CommandDock4);
            this.Controls.Add(this.c1CommandDock3);
            this.Controls.Add(this.c1CommandDock2);
            this.Controls.Add(this.c1CommandDock1);
            this.Controls.Add(this.c1MainMenu1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Overview";
            this.Text = "Overview";
            ((System.ComponentModel.ISupportInitialize)(this.c1TextBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandDock1)).EndInit();
            this.c1CommandDock1.ResumeLayout(false);
            this.c1ToolBar_Tools.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.c1CommandHolder1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1TextBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.Command.C1MainMenu c1MainMenu1;
        private C1.Win.Command.C1CommandHolder c1CommandHolder1;
        private C1.Win.Command.C1CommandLink c1CommandLink1;
        private C1.Win.Command.C1CommandDock c1CommandDock1;
        private C1.Win.Command.C1CommandMenu c1CommandMenu_File;
        private C1.Win.Command.C1CommandLink c1CommandLink2;
        private C1.Win.Command.C1CommandMenu c1Command_New;
        private C1.Win.Command.C1CommandLink c1CommandLink11;
        private C1.Win.Command.C1CommandLink c1CommandLink12;
        private C1.Win.Command.C1CommandMenu c1Command_Open;
        private C1.Win.Command.C1CommandLink c1CommandLink13;
        private C1.Win.Command.C1CommandLink c1CommandLink14;
        private C1.Win.Command.C1Command c1Command_Save;
        private C1.Win.Command.C1CommandLink c1CommandLink15;
        private C1.Win.Command.C1Command c1Command_Print;
        private C1.Win.Command.C1CommandMenu c1CommandMenu_Edit;
        private C1.Win.Command.C1CommandLink c1CommandLink4;
        private C1.Win.Command.C1CommandMenu c1CommandMenu_View;
        private C1.Win.Command.C1CommandLink c1CommandLink6;
        private C1.Win.Command.C1CommandMenu c1CommandMenu_Tools;
        private C1.Win.Command.C1CommandLink c1CommandLink8;
        private C1.Win.Command.C1CommandMenu c1CommandMenu_Help;
        private C1.Win.Command.C1CommandLink c1CommandLink10;
        private C1.Win.Command.C1CommandLink c1CommandLink3;
        private C1.Win.Command.C1CommandLink c1CommandLink5;
        private C1.Win.Command.C1CommandLink c1CommandLink7;
        private C1.Win.Command.C1CommandLink c1CommandLink9;
        private C1.Win.Command.C1Command c1Command_Undo;
        private C1.Win.Command.C1CommandLink c1CommandLink16;
        private C1.Win.Command.C1Command c1Command_Redo;
        private C1.Win.Command.C1CommandLink c1CommandLink17;
        private C1.Win.Command.C1Command c1Command_Cut;
        private C1.Win.Command.C1CommandLink c1CommandLink18;
        private C1.Win.Command.C1Command c1Command_Copy;
        private C1.Win.Command.C1CommandLink c1CommandLink19;
        private C1.Win.Command.C1Command c1Command_Paste;
        private C1.Win.Command.C1Command c1Command_NewMail;
        private C1.Win.Command.C1CommandLink c1CommandLink20;
        private C1.Win.Command.C1Command c1CommandNewAppointment;
        private C1.Win.Command.C1CommandLink c1CommandLink21;
        private C1.Win.Command.C1Command c1Command_NewNote;
        private C1.Win.Command.C1CommandLink c1CommandLink22;
        private C1.Win.Command.C1Command c1Command_NewTask;
        private C1.Win.Command.C1CommandLink c1CommandLink23;
        private C1.Win.Command.C1Command c1Command_NewContact;
        private C1.Win.Command.C1CommandMenu c1Command_NavigationPane;
        private C1.Win.Command.C1CommandLink c1CommandLink24;
        private C1.Win.Command.C1Command c1Command_NavBarNormal;
        private C1.Win.Command.C1CommandLink c1CommandLink27;
        private C1.Win.Command.C1Command c1Command_NavBarMinimized;
        private C1.Win.Command.C1CommandLink c1CommandLink28;
        private C1.Win.Command.C1Command c1Command_NavBarOff;
        private C1.Win.Command.C1CommandLink c1CommandLink25;
        private C1.Win.Command.C1CommandMenu c1Command_Toolbars;
        private C1.Win.Command.C1CommandLink c1CommandLink26;
        private C1.Win.Command.C1Command c1Command_OpenFile;
        private C1.Win.Command.C1CommandLink c1CommandLink29;
        private C1.Win.Command.C1Command c1Command_OpenDatabase;
        private C1.Win.Command.C1CommandLink c1CommandLink30;
        private C1.Win.Command.C1Command c1Command_SaveAll;
        private C1.Win.Command.C1Command c1Command_AddressBook;
        private C1.Win.Command.C1CommandLink c1CommandLink31;
        private C1.Win.Command.C1Command c1Command_SpellCheck;
        private C1.Win.Command.C1CommandLink c1CommandLink32;
        private C1.Win.Command.C1CommandMenu c1Command_InstantSearch;
        private C1.Win.Command.C1CommandLink c1CommandLink33;
        private C1.Win.Command.C1Command c1Command_Help;
        private C1.Win.Command.C1CommandLink c1CommandLink34;
        private C1.Win.Command.C1Command c1Command_About;
        private C1.Win.Command.C1CommandLink c1CommandLink35;
        private C1.Win.Command.C1Command c1Command_Statusbar;
        private C1.Win.Command.C1ToolBar c1ToolBar_File;
        private C1.Win.Command.C1CommandLink c1CommandLink36;
        private C1.Win.Command.C1CommandLink c1CommandLink37;
        private C1.Win.Command.C1CommandLink c1CommandLink38;
        private C1.Win.Command.C1CommandLink c1CommandLink39;
        private C1.Win.Command.C1CommandLink c1CommandLink40;
        private C1.Win.Command.C1Command c1Command_ToolbarFile;
        private C1.Win.Command.C1CommandLink c1CommandLink46;
        private C1.Win.Command.C1Command c1Command_ToolbarEdit;
        private C1.Win.Command.C1ToolBar c1ToolBar_Edit;
        private C1.Win.Command.C1CommandLink c1CommandLink41;
        private C1.Win.Command.C1CommandLink c1CommandLink42;
        private C1.Win.Command.C1CommandLink c1CommandLink43;
        private C1.Win.Command.C1CommandLink c1CommandLink44;
        private C1.Win.Command.C1CommandLink c1CommandLink45;
        private C1.Win.Command.C1CommandDock c1CommandDock2;
        private C1.Win.Command.C1CommandDock c1CommandDock4;
        private C1.Win.Command.C1CommandDock c1CommandDock3;
        private C1.Win.Command.C1ToolBar c1ToolBar_Format;
        private C1.Win.Command.C1CommandLink c1CommandLink47;
        private C1.Win.Command.C1Command c1Command_Bold;
        private C1.Win.Command.C1Command c1Command_Italic;
        private C1.Win.Command.C1CommandLink c1CommandLink48;
        private C1.Win.Command.C1Command c1Command_Underline;
        private C1.Win.Command.C1CommandLink c1CommandLink49;
        private C1.Win.Command.C1Command c1Command_Strikethrough;
        private C1.Win.Command.C1CommandLink c1CommandLink50;
        private C1.Win.Command.C1Command c1Command_Subscript;
        private C1.Win.Command.C1CommandLink c1CommandLink51;
        private C1.Win.Command.C1Command c1Command_Superscript;
        private C1.Win.Command.C1CommandLink c1CommandLink52;
        private C1.Win.Command.C1Command c1Command_ShrinkFont;
        private C1.Win.Command.C1CommandLink c1CommandLink53;
        private C1.Win.Command.C1Command c1Command_GrowFont;
        private C1.Win.Command.C1CommandLink c1CommandLink54;
        private C1.Win.Command.C1Command c1Command_DecIndent;
        private C1.Win.Command.C1CommandLink c1CommandLink55;
        private C1.Win.Command.C1Command c1Command_IncIndent;
        private C1.Win.Command.C1CommandLink c1CommandLink56;
        private C1.Win.Command.C1Command c1Command_Bullets;
        private C1.Win.Command.C1CommandLink c1CommandLink57;
        private C1.Win.Command.C1Command c1Command_Numbering;
        private C1.Win.Command.C1CommandLink c1CommandLink58;
        private C1.Win.Command.C1Command c1Command_AlignLeft;
        private C1.Win.Command.C1CommandLink c1CommandLink59;
        private C1.Win.Command.C1Command c1Command_AlignCenter;
        private C1.Win.Command.C1CommandLink c1CommandLink60;
        private C1.Win.Command.C1Command c1Command_AlignRight;
        private C1.Win.Command.C1CommandLink c1CommandLink61;
        private C1.Win.Command.C1Command c1Command_Justify;
        private C1.Win.Command.C1CommandLink c1CommandLink62;
        private C1.Win.Command.C1CommandLink c1CommandLink63;
        private C1.Win.Command.C1CommandMenu c1Command_Format;
        private C1.Win.Command.C1CommandLink c1CommandLink64;
        private C1.Win.Command.C1CommandLink c1CommandLink65;
        private C1.Win.Command.C1CommandLink c1CommandLink66;
        private C1.Win.Command.C1CommandLink c1CommandLink67;
        private C1.Win.Command.C1CommandLink c1CommandLink68;
        private C1.Win.Command.C1CommandLink c1CommandLink69;
        private C1.Win.Command.C1CommandLink c1CommandLink70;
        private C1.Win.Command.C1CommandLink c1CommandLink71;
        private C1.Win.Command.C1CommandLink c1CommandLink72;
        private C1.Win.Command.C1CommandLink c1CommandLink73;
        private C1.Win.Command.C1CommandLink c1CommandLink74;
        private C1.Win.Command.C1CommandLink c1CommandLink75;
        private C1.Win.Command.C1CommandLink c1CommandLink76;
        private C1.Win.Command.C1CommandLink c1CommandLink77;
        private C1.Win.Command.C1CommandLink c1CommandLink78;
        private C1.Win.Command.C1CommandLink c1CommandLink79;
        private C1.Win.Command.C1CommandLink c1CommandLink80;
        private C1.Win.Command.C1Command c1Command_ToolbarFormat;
        private C1.Win.Input.C1TextBox c1TextBox1;
        private C1.Win.Command.C1CommandControl c1Command_TextSearchBox;
        private C1.Win.Command.C1CommandControl c1Command_TextSearchMenu;
        private C1.Win.Input.C1TextBox c1TextBox2;
        private C1.Win.Command.C1CommandLink c1CommandLink85;
        private C1.Win.Command.C1Command c1Command_Search;
        private C1.Win.Command.C1ToolBar c1ToolBar_Tools;
        private C1.Win.Command.C1CommandLink c1CommandLink81;
        private C1.Win.Command.C1CommandLink c1CommandLink82;
        private C1.Win.Command.C1CommandLink c1CommandLink83;
        private C1.Win.Command.C1CommandLink c1CommandLink84;
        private C1.Win.Command.C1ContextMenu c1ContextMenu1;
        private C1.Win.Command.C1CommandLink c1CommandLink86;
        private C1.Win.Command.C1CommandLink c1CommandLink87;
        private C1.Win.Command.C1CommandLink c1CommandLink88;
        private C1.Win.Command.C1CommandLink c1CommandLink89;
        private C1.Win.Command.C1CommandLink c1CommandLink90;
        private C1.Win.Command.C1CommandLink c1CommandLink91;
        private C1.Win.Command.C1CommandLink c1CommandLink92;
        private C1.Win.Command.C1CommandLink c1CommandLink93;
        private C1.Win.Command.C1CommandLink c1CommandLink94;
        private System.Windows.Forms.Label label1;
        private C1.Win.Command.C1CommandLink c1CommandLink95;
        private C1.Win.Command.C1Command c1Command_ToolbarTools;
    }
}