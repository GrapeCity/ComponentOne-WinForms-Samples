﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RulesManagerExplorer.Samples.Dialogs
{
    public partial class GreaterThanForm : SingleValueConditionalFormattingForm
    {
        public GreaterThanForm()
        {
            InitializeComponent();
        }
    }
}
