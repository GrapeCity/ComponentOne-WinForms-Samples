﻿using System;

namespace InputPanelExplorer.Samples
{
    partial class BillOfSale
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;

            C1.Win.InputPanel.ColumnDefinition columnDefinition1 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition2 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition3 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition4 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition5 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition6 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition7 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition8 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.ColumnDefinition columnDefinition9 = new C1.Win.InputPanel.ColumnDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition1 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition2 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition3 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition4 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition5 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition6 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition7 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition8 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition9 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition10 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition11 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition12 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition13 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition14 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition15 = new C1.Win.InputPanel.RowDefinition();
            C1.Win.InputPanel.RowDefinition rowDefinition16 = new C1.Win.InputPanel.RowDefinition();

            this.c1InputPanel1 = new C1.Win.InputPanel.C1InputPanel();
            this.inputGroupHeader1 = new C1.Win.InputPanel.InputGroupHeader();
            this.inputGridPanel1 = new C1.Win.InputPanel.InputGridPanel();
            this.inputLabel19 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel1 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel2 = new C1.Win.InputPanel.InputLabel();
            this.sellerPrintedName = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel3 = new C1.Win.InputPanel.InputLabel();
            this.sellerAddress = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel4 = new C1.Win.InputPanel.InputLabel();
            this.sellerCity = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel5 = new C1.Win.InputPanel.InputLabel();
            this.sellerState = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel6 = new C1.Win.InputPanel.InputLabel();
            this.sellerZip = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel7 = new C1.Win.InputPanel.InputLabel();
            this.sellerHomePhone = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel8 = new C1.Win.InputPanel.InputLabel();
            this.sellerCellPhone = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel9 = new C1.Win.InputPanel.InputLabel();
            this.sellerWork = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel10 = new C1.Win.InputPanel.InputLabel();
            this.buyerPrintedName = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel11 = new C1.Win.InputPanel.InputLabel();
            this.buyerAddress = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel12 = new C1.Win.InputPanel.InputLabel();
            this.buyerCity = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel13 = new C1.Win.InputPanel.InputLabel();
            this.buyerState = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel14 = new C1.Win.InputPanel.InputLabel();
            this.Zip = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel15 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel16 = new C1.Win.InputPanel.InputLabel();
            this.buyerHomePhone = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel17 = new C1.Win.InputPanel.InputLabel();
            this.buyerCellPhone = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel18 = new C1.Win.InputPanel.InputLabel();
            this.buyerWork = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel20 = new C1.Win.InputPanel.InputLabel();
            this.itemsInfo = new RichTextBoxHost();
            this.inputLabel21 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel23 = new C1.Win.InputPanel.InputLabel();
            this.formOfPayment = new C1.Win.InputPanel.InputTextBox();
            this.inputLabel24 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel25 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel26 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel27 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel28 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel22 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel29 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel30 = new C1.Win.InputPanel.InputLabel();
            this.inputLabel31 = new C1.Win.InputPanel.InputLabel();
            this.dateSold = new C1.Win.InputPanel.InputDatePicker();
            this.SellerDateSign = new C1.Win.InputPanel.InputDatePicker();
            this.BuyerDateSign = new C1.Win.InputPanel.InputDatePicker();
            this.inputLabel32 = new C1.Win.InputPanel.InputLabel();
            this.itemsValue = new C1.Win.InputPanel.InputNumericBox();
            this.billOfSaleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.c1InputPanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billOfSaleBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // c1InputPanel1
            // 
            this.c1InputPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1InputPanel1.AutoSizeElement = C1.Framework.AutoSizeElement.Both;
            this.c1InputPanel1.BackColor = System.Drawing.Color.Transparent;
            this.c1InputPanel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.c1InputPanel1.Items.Add(this.inputGroupHeader1);
            this.c1InputPanel1.Items.Add(this.inputGridPanel1);
            this.c1InputPanel1.Location = new System.Drawing.Point(0, 80);
            
            this.c1InputPanel1.Name = "c1InputPanel1";
            this.c1InputPanel1.Size = new System.Drawing.Size(672, 658);
            this.c1InputPanel1.TabIndex = 0;
            
            // 
            // inputGroupHeader1
            // 
            this.inputGroupHeader1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputGroupHeader1.Name = "inputGroupHeader1";
            this.inputGroupHeader1.Text = "BILL OF SALE";
            this.inputGroupHeader1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // inputGridPanel1
            // 
            this.inputGridPanel1.Break = C1.Win.InputPanel.BreakType.None;
            columnDefinition1.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition1.Width = 18;
            columnDefinition2.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition2.Width = 12;
            columnDefinition3.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition3.Width = 5;
            columnDefinition4.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition4.Width = 12;
            columnDefinition5.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition5.Width = 6;
            columnDefinition6.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition6.Width = 18;
            columnDefinition7.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition7.Width = 12;
            columnDefinition8.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition8.Width = 5;
            columnDefinition9.SizeType = System.Windows.Forms.SizeType.Percent;
            columnDefinition9.Width = 12;
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition1);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition2);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition3);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition4);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition5);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition6);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition7);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition8);
            this.inputGridPanel1.ColumnDefinitions.Add(columnDefinition9);
            this.inputGridPanel1.Items.Add(this.inputLabel19);
            this.inputGridPanel1.Items.Add(this.inputLabel1);
            this.inputGridPanel1.Items.Add(this.inputLabel2);
            this.inputGridPanel1.Items.Add(this.sellerPrintedName);
            this.inputGridPanel1.Items.Add(this.inputLabel3);
            this.inputGridPanel1.Items.Add(this.sellerAddress);
            this.inputGridPanel1.Items.Add(this.inputLabel4);
            this.inputGridPanel1.Items.Add(this.sellerCity);
            this.inputGridPanel1.Items.Add(this.inputLabel5);
            this.inputGridPanel1.Items.Add(this.sellerState);
            this.inputGridPanel1.Items.Add(this.inputLabel6);
            this.inputGridPanel1.Items.Add(this.sellerZip);
            this.inputGridPanel1.Items.Add(this.inputLabel7);
            this.inputGridPanel1.Items.Add(this.sellerHomePhone);
            this.inputGridPanel1.Items.Add(this.inputLabel8);
            this.inputGridPanel1.Items.Add(this.sellerCellPhone);
            this.inputGridPanel1.Items.Add(this.inputLabel9);
            this.inputGridPanel1.Items.Add(this.sellerWork);
            this.inputGridPanel1.Items.Add(this.inputLabel10);
            this.inputGridPanel1.Items.Add(this.buyerPrintedName);
            this.inputGridPanel1.Items.Add(this.inputLabel11);
            this.inputGridPanel1.Items.Add(this.buyerAddress);
            this.inputGridPanel1.Items.Add(this.inputLabel12);
            this.inputGridPanel1.Items.Add(this.buyerCity);
            this.inputGridPanel1.Items.Add(this.inputLabel13);
            this.inputGridPanel1.Items.Add(this.buyerState);
            this.inputGridPanel1.Items.Add(this.inputLabel14);
            this.inputGridPanel1.Items.Add(this.Zip);
            this.inputGridPanel1.Items.Add(this.inputLabel15);
            this.inputGridPanel1.Items.Add(this.inputLabel16);
            this.inputGridPanel1.Items.Add(this.buyerHomePhone);
            this.inputGridPanel1.Items.Add(this.inputLabel17);
            this.inputGridPanel1.Items.Add(this.buyerCellPhone);
            this.inputGridPanel1.Items.Add(this.inputLabel18);
            this.inputGridPanel1.Items.Add(this.buyerWork);
            this.inputGridPanel1.Items.Add(this.inputLabel20);
            this.inputGridPanel1.Items.Add(this.inputLabel21);
            this.inputGridPanel1.Items.Add(this.inputLabel23);
            this.inputGridPanel1.Items.Add(this.formOfPayment);
            this.inputGridPanel1.Items.Add(this.itemsInfo);
            this.inputGridPanel1.Items.Add(this.inputLabel24);
            this.inputGridPanel1.Items.Add(this.inputLabel25);
            this.inputGridPanel1.Items.Add(this.inputLabel26);
            this.inputGridPanel1.Items.Add(this.inputLabel27);
            this.inputGridPanel1.Items.Add(this.inputLabel28);
            this.inputGridPanel1.Items.Add(this.inputLabel22);
            this.inputGridPanel1.Items.Add(this.inputLabel29);
            this.inputGridPanel1.Items.Add(this.inputLabel30);
            this.inputGridPanel1.Items.Add(this.inputLabel31);
            this.inputGridPanel1.Items.Add(this.dateSold);
            this.inputGridPanel1.Items.Add(this.SellerDateSign);
            this.inputGridPanel1.Items.Add(this.BuyerDateSign);
            this.inputGridPanel1.Items.Add(this.inputLabel32);
            this.inputGridPanel1.Items.Add(this.itemsValue);
            this.inputGridPanel1.Name = "inputGridPanel1";
            this.inputGridPanel1.Padding = new System.Windows.Forms.Padding(2);
            rowDefinition1.Height = 30;
            rowDefinition2.Height = 30;
            rowDefinition3.Height = 30;
            rowDefinition4.Height = 30;
            rowDefinition5.Height = 30;
            rowDefinition6.Height = 30;
            rowDefinition7.Height = 30;
            rowDefinition8.Height = 30;
            rowDefinition9.Height = 30;
            rowDefinition10.Height = 35;
            rowDefinition11.Height = 70;
            rowDefinition12.Height = 30;
            rowDefinition13.Height = 30;
            rowDefinition14.Height = 70;
            rowDefinition15.Height = 30;
            rowDefinition16.Height = 30;
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition1);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition2);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition3);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition4);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition5);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition6);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition7);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition8);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition9);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition10);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition11);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition12);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition13);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition14);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition15);
            this.inputGridPanel1.RowDefinitions.Add(rowDefinition16);
            // 
            // inputLabel19
            // 
            this.inputLabel19.ColumnIndex = 6;
            this.inputLabel19.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Far;
            this.inputLabel19.Name = "inputLabel19";
            this.inputLabel19.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel19.Text = "Date Sold:";
            this.inputLabel19.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel1
            // 
            this.inputLabel1.ElementWidth = 10;
            this.inputLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputLabel1.Name = "inputLabel1";
            this.inputLabel1.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel1.RowIndex = 1;
            this.inputLabel1.Text = "SELLER\'S";
            this.inputLabel1.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel2
            // 
            this.inputLabel2.Name = "inputLabel2";
            this.inputLabel2.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel2.RowIndex = 2;
            this.inputLabel2.Text = "Printed Name:";
            this.inputLabel2.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerPrintedName
            // 
            this.sellerPrintedName.ColumnIndex = 1;
            this.sellerPrintedName.ColumnSpan = 3;
            this.sellerPrintedName.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.PrintedName", true));
            this.sellerPrintedName.ForeColor = System.Drawing.Color.Black;
            this.sellerPrintedName.Name = "sellerPrintedName";
            this.sellerPrintedName.Padding = new System.Windows.Forms.Padding(2);
            this.sellerPrintedName.RowIndex = 2;
            this.sellerPrintedName.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel3
            // 
            this.inputLabel3.Name = "inputLabel3";
            this.inputLabel3.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel3.RowIndex = 3;
            this.inputLabel3.Text = "Address:";
            this.inputLabel3.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerAddress
            // 
            this.sellerAddress.ColumnIndex = 1;
            this.sellerAddress.ColumnSpan = 3;
            this.sellerAddress.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.Address", true));
            this.sellerAddress.ForeColor = System.Drawing.Color.Black;
            this.sellerAddress.Name = "sellerAddress";
            this.sellerAddress.Padding = new System.Windows.Forms.Padding(2);
            this.sellerAddress.RowIndex = 3;
            this.sellerAddress.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel4
            // 
            this.inputLabel4.Name = "inputLabel4";
            this.inputLabel4.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel4.RowIndex = 4;
            this.inputLabel4.Text = "City:";
            this.inputLabel4.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerCity
            // 
            this.sellerCity.ColumnIndex = 1;
            this.sellerCity.ColumnSpan = 3;
            this.sellerCity.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.City", true));
            this.sellerCity.ForeColor = System.Drawing.Color.Black;
            this.sellerCity.Name = "sellerCity";
            this.sellerCity.Padding = new System.Windows.Forms.Padding(2);
            this.sellerCity.RowIndex = 4;
            this.sellerCity.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel5
            // 
            this.inputLabel5.Name = "inputLabel5";
            this.inputLabel5.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel5.RowIndex = 5;
            this.inputLabel5.Text = "State:";
            this.inputLabel5.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerState
            // 
            this.sellerState.ColumnIndex = 1;
            this.sellerState.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.State", true));
            this.sellerState.Name = "sellerState";
            this.sellerState.Padding = new System.Windows.Forms.Padding(2);
            this.sellerState.RowIndex = 5;
            this.sellerState.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel6
            // 
            this.inputLabel6.ColumnIndex = 2;
            this.inputLabel6.Name = "inputLabel6";
            this.inputLabel6.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel6.RowIndex = 5;
            this.inputLabel6.Text = "Zip:";
            this.inputLabel6.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerZip
            // 
            this.sellerZip.ColumnIndex = 3;
            this.sellerZip.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.Zip", true));
            this.sellerZip.MaxLength = 6;
            this.sellerZip.Name = "sellerZip";
            this.sellerZip.Padding = new System.Windows.Forms.Padding(2);
            this.sellerZip.RowIndex = 5;
            this.sellerZip.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel7
            // 
            this.inputLabel7.Name = "inputLabel7";
            this.inputLabel7.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel7.RowIndex = 6;
            this.inputLabel7.Text = "Home Phone:";
            this.inputLabel7.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerHomePhone
            // 
            this.sellerHomePhone.ColumnIndex = 1;
            this.sellerHomePhone.ColumnSpan = 3;
            this.sellerHomePhone.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.HomePhone", true));
            this.sellerHomePhone.ForeColor = System.Drawing.Color.Black;
            this.sellerHomePhone.Name = "sellerHomePhone";
            this.sellerHomePhone.Padding = new System.Windows.Forms.Padding(2);
            this.sellerHomePhone.RowIndex = 6;
            this.sellerHomePhone.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel8
            // 
            this.inputLabel8.Name = "inputLabel8";
            this.inputLabel8.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel8.RowIndex = 7;
            this.inputLabel8.Text = "Cell Phone:";
            this.inputLabel8.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerCellPhone
            // 
            this.sellerCellPhone.ColumnIndex = 1;
            this.sellerCellPhone.ColumnSpan = 3;
            this.sellerCellPhone.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.CellPhone", true));
            this.sellerCellPhone.ForeColor = System.Drawing.Color.Black;
            this.sellerCellPhone.Name = "sellerCellPhone";
            this.sellerCellPhone.Padding = new System.Windows.Forms.Padding(2);
            this.sellerCellPhone.RowIndex = 7;
            this.sellerCellPhone.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel9
            // 
            this.inputLabel9.Name = "inputLabel9";
            this.inputLabel9.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel9.RowIndex = 8;
            this.inputLabel9.Text = "Work:";
            this.inputLabel9.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // sellerWork
            // 
            this.sellerWork.ColumnIndex = 1;
            this.sellerWork.ColumnSpan = 3;
            this.sellerWork.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.Work", true));
            this.sellerWork.ForeColor = System.Drawing.Color.Black;
            this.sellerWork.Name = "sellerWork";
            this.sellerWork.Padding = new System.Windows.Forms.Padding(2);
            this.sellerWork.RowIndex = 8;
            this.sellerWork.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel10
            // 
            this.inputLabel10.ColumnIndex = 5;
            this.inputLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputLabel10.Name = "inputLabel10";
            this.inputLabel10.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel10.RowIndex = 1;
            this.inputLabel10.Text = "BUYER\'S";
            this.inputLabel10.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // buyerPrintedName
            // 
            this.buyerPrintedName.ColumnIndex = 6;
            this.buyerPrintedName.ColumnSpan = 3;
            this.buyerPrintedName.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.PrintedName", true));
            this.buyerPrintedName.ForeColor = System.Drawing.Color.Black;
            this.buyerPrintedName.Name = "buyerPrintedName";
            this.buyerPrintedName.Padding = new System.Windows.Forms.Padding(2);
            this.buyerPrintedName.RowIndex = 2;
            this.buyerPrintedName.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel11
            // 
            this.inputLabel11.ColumnIndex = 5;
            this.inputLabel11.Name = "inputLabel11";
            this.inputLabel11.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel11.RowIndex = 2;
            this.inputLabel11.Text = "Printed Name:";
            this.inputLabel11.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // buyerAddress
            // 
            this.buyerAddress.ColumnIndex = 6;
            this.buyerAddress.ColumnSpan = 3;
            this.buyerAddress.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.Address", true));
            this.buyerAddress.ForeColor = System.Drawing.Color.Black;
            this.buyerAddress.Name = "buyerAddress";
            this.buyerAddress.Padding = new System.Windows.Forms.Padding(2);
            this.buyerAddress.RowIndex = 3;
            this.buyerAddress.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel12
            // 
            this.inputLabel12.ColumnIndex = 5;
            this.inputLabel12.Name = "inputLabel12";
            this.inputLabel12.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel12.RowIndex = 3;
            this.inputLabel12.Text = "Address:";
            this.inputLabel12.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // buyerCity
            // 
            this.buyerCity.ColumnIndex = 6;
            this.buyerCity.ColumnSpan = 3;
            this.buyerCity.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.City", true));
            this.buyerCity.ForeColor = System.Drawing.Color.Black;
            this.buyerCity.Name = "buyerCity";
            this.buyerCity.Padding = new System.Windows.Forms.Padding(2);
            this.buyerCity.RowIndex = 4;
            this.buyerCity.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel13
            // 
            this.inputLabel13.ColumnIndex = 5;
            this.inputLabel13.Name = "inputLabel13";
            this.inputLabel13.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel13.RowIndex = 4;
            this.inputLabel13.Text = "City:";
            this.inputLabel13.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // buyerState
            // 
            this.buyerState.ColumnIndex = 6;
            this.buyerState.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.State", true));
            this.buyerState.ForeColor = System.Drawing.Color.Black;
            this.buyerState.Name = "buyerState";
            this.buyerState.Padding = new System.Windows.Forms.Padding(2);
            this.buyerState.RowIndex = 5;
            this.buyerState.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel14
            // 
            this.inputLabel14.ColumnIndex = 5;
            this.inputLabel14.Name = "inputLabel14";
            this.inputLabel14.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel14.RowIndex = 5;
            this.inputLabel14.Text = "State:";
            this.inputLabel14.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // Zip
            // 
            this.Zip.ColumnIndex = 8;
            this.Zip.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.Zip", true));
            this.Zip.ForeColor = System.Drawing.Color.Black;
            this.Zip.MaxLength = 6;
            this.Zip.Name = "Zip";
            this.Zip.Padding = new System.Windows.Forms.Padding(2);
            this.Zip.RowIndex = 5;
            this.Zip.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel15
            // 
            this.inputLabel15.ColumnIndex = 7;
            this.inputLabel15.Name = "inputLabel15";
            this.inputLabel15.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel15.RowIndex = 5;
            this.inputLabel15.Text = "Zip:";
            this.inputLabel15.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel16
            // 
            this.inputLabel16.ColumnIndex = 5;
            this.inputLabel16.Name = "inputLabel16";
            this.inputLabel16.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel16.RowIndex = 6;
            this.inputLabel16.Text = "Home Phone:";
            this.inputLabel16.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // buyerHomePhone
            // 
            this.buyerHomePhone.ColumnIndex = 6;
            this.buyerHomePhone.ColumnSpan = 3;
            this.buyerHomePhone.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.HomePhone", true));
            this.buyerHomePhone.ForeColor = System.Drawing.Color.Black;
            this.buyerHomePhone.Name = "buyerHomePhone";
            this.buyerHomePhone.Padding = new System.Windows.Forms.Padding(2);
            this.buyerHomePhone.RowIndex = 6;
            this.buyerHomePhone.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel17
            // 
            this.inputLabel17.ColumnIndex = 5;
            this.inputLabel17.Name = "inputLabel17";
            this.inputLabel17.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel17.RowIndex = 7;
            this.inputLabel17.Text = "Cell Phone:";
            this.inputLabel17.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // buyerCellPhone
            // 
            this.buyerCellPhone.ColumnIndex = 6;
            this.buyerCellPhone.ColumnSpan = 3;
            this.buyerCellPhone.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.CellPhone", true));
            this.buyerCellPhone.ForeColor = System.Drawing.Color.Black;
            this.buyerCellPhone.Name = "buyerCellPhone";
            this.buyerCellPhone.Padding = new System.Windows.Forms.Padding(2);
            this.buyerCellPhone.RowIndex = 7;
            this.buyerCellPhone.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel18
            // 
            this.inputLabel18.ColumnIndex = 5;
            this.inputLabel18.Name = "inputLabel18";
            this.inputLabel18.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel18.RowIndex = 8;
            this.inputLabel18.Text = "Work:";
            this.inputLabel18.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // buyerWork
            // 
            this.buyerWork.ColumnIndex = 6;
            this.buyerWork.ColumnSpan = 3;
            this.buyerWork.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.Work", true));
            this.buyerWork.ForeColor = System.Drawing.Color.Black;
            this.buyerWork.Name = "buyerWork";
            this.buyerWork.Padding = new System.Windows.Forms.Padding(2);
            this.buyerWork.RowIndex = 8;
            this.buyerWork.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel20
            // 
            this.inputLabel20.ColumnSpan = 9;
            this.inputLabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputLabel20.Height = 30;
            this.inputLabel20.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            this.inputLabel20.Name = "inputLabel20";
            this.inputLabel20.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel20.RowIndex = 9;
            this.inputLabel20.Text = "INFORMATION ON ITEM THAT WAS SOLD";
            this.inputLabel20.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // itemsInfo
            // 
            this.itemsInfo.BackColor = System.Drawing.SystemColors.Window;
            this.itemsInfo.ColumnSpan = 9;
            this.itemsInfo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.billOfSaleBindingSource, "ItemsInfo", true));
            this.itemsInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.itemsInfo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.itemsInfo.Name = "itemsInfo";
            this.itemsInfo.RowIndex = 10;
            // 
            // inputLabel21 
            // 
            this.inputLabel21.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Far;
            this.inputLabel21.Name = "inputLabel21";
            this.inputLabel21.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel21.RowIndex = 11;
            this.inputLabel21.Text = "For the sum of";
            this.inputLabel21.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel23
            // 
            this.inputLabel23.ColumnIndex = 3;
            this.inputLabel23.ColumnSpan = 2;
            this.inputLabel23.Name = "inputLabel23";
            this.inputLabel23.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel23.RowIndex = 11;
            this.inputLabel23.Text = ", Payment in form of";
            this.inputLabel23.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // formOfPayment
            // 
            this.formOfPayment.ColumnIndex = 5;
            this.formOfPayment.ColumnSpan = 4;
            this.formOfPayment.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "FormOfPayment", true));
            this.formOfPayment.ForeColor = System.Drawing.Color.Black;
            this.formOfPayment.Name = "formOfPayment";
            this.formOfPayment.Padding = new System.Windows.Forms.Padding(2);
            this.formOfPayment.RowIndex = 11;
            this.formOfPayment.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel24
            // 
            this.inputLabel24.ColumnSpan = 9;
            this.inputLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputLabel24.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            this.inputLabel24.Name = "inputLabel24";
            this.inputLabel24.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel24.RowIndex = 13;
            this.inputLabel24.Text = "I,THE UNDERSIGNED, HEREBY SWEAROF AFFIRM THAT I THE SELLER OF THE ITEM \r\nDESCRIBE" +
    "D HEREIN AND THAT THE INFORMATION PROVIDED IN THIS BILL OF SALE\r\nIS TRUE AND COR" +
    "RECT TO THE BEST OF MY BELIEF.";
            this.inputLabel24.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel25
            // 
            this.inputLabel25.Name = "inputLabel25";
            this.inputLabel25.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel25.RowIndex = 14;
            this.inputLabel25.Text = "Signature of Seller:";
            this.inputLabel25.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel26
            // 
            this.inputLabel26.ColumnIndex = 6;
            this.inputLabel26.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Far;
            this.inputLabel26.Name = "inputLabel26";
            this.inputLabel26.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel26.RowIndex = 14;
            this.inputLabel26.Text = "Date:";
            this.inputLabel26.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel27
            // 
            this.inputLabel27.Name = "inputLabel27";
            this.inputLabel27.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel27.RowIndex = 15;
            this.inputLabel27.Text = "Signature of Buyer:";
            this.inputLabel27.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel28
            // 
            this.inputLabel28.ColumnIndex = 6;
            this.inputLabel28.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Far;
            this.inputLabel28.Name = "inputLabel28";
            this.inputLabel28.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel28.RowIndex = 15;
            this.inputLabel28.Text = "Date:";
            this.inputLabel28.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel22
            // 
            this.inputLabel22.ColumnIndex = 1;
            this.inputLabel22.ColumnSpan = 2;
            this.inputLabel22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputLabel22.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            this.inputLabel22.Name = "inputLabel22";
            this.inputLabel22.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel22.RowIndex = 12;
            this.inputLabel22.Text = "(Item\'s value)";
            this.inputLabel22.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Near;
            this.inputLabel22.FontPadding = true;
            // 
            // inputLabel29
            // 
            this.inputLabel29.ColumnIndex = 5;
            this.inputLabel29.ColumnSpan = 4;
            this.inputLabel29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.inputLabel29.HorizontalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            this.inputLabel29.Name = "inputLabel29";
            this.inputLabel29.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel29.RowIndex = 12;
            this.inputLabel29.Text = "(form of payment)";
            this.inputLabel29.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Near;
            this.inputLabel29.FontPadding = true;
            // 
            // inputLabel30
            // 
            this.inputLabel30.ColumnIndex = 1;
            this.inputLabel30.ColumnSpan = 3;
            this.inputLabel30.Name = "inputLabel30";
            this.inputLabel30.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel30.RowIndex = 14;
            this.inputLabel30.Text = "_____________________________________";
            this.inputLabel30.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Far;
            // 
            // inputLabel31
            // 
            this.inputLabel31.ColumnIndex = 1;
            this.inputLabel31.ColumnSpan = 3;
            this.inputLabel31.Name = "inputLabel31";
            this.inputLabel31.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel31.RowIndex = 15;
            this.inputLabel31.Text = "_____________________________________";
            this.inputLabel31.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Far;
            // 
            // dateSold
            // 
            this.dateSold.ColumnIndex = 7;
            this.dateSold.ColumnSpan = 2;
            this.dateSold.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "DateSold", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "d"));
            this.dateSold.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.billOfSaleBindingSource, "DateSold", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "d"));
            this.dateSold.Name = "dateSold";
            this.dateSold.Padding = new System.Windows.Forms.Padding(2);
            this.dateSold.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // SellerDateSign
            // 
            this.SellerDateSign.ColumnIndex = 7;
            this.SellerDateSign.ColumnSpan = 2;
            this.SellerDateSign.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Seller.DateSign", true));
            this.SellerDateSign.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.billOfSaleBindingSource, "Seller.DateSign", true));
            this.SellerDateSign.Name = "SellerDateSign";
            this.SellerDateSign.Padding = new System.Windows.Forms.Padding(2);
            this.SellerDateSign.RowIndex = 14;
            this.SellerDateSign.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // BuyerDateSign
            // 
            this.BuyerDateSign.ColumnIndex = 7;
            this.BuyerDateSign.ColumnSpan = 2;
            this.BuyerDateSign.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "Buyer.DateSign", true));
            this.BuyerDateSign.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.billOfSaleBindingSource, "Buyer.DateSign", true));
            this.BuyerDateSign.Name = "BuyerDateSign";
			this.BuyerDateSign.Padding = new System.Windows.Forms.Padding(2);
            this.BuyerDateSign.RowIndex = 15;
            this.BuyerDateSign.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // inputLabel32
            // 
            this.inputLabel32.Break = C1.Win.InputPanel.BreakType.Group;
            this.inputLabel32.ColumnIndex = 1;
            this.inputLabel32.Name = "inputLabel32";
            this.inputLabel32.Padding = new System.Windows.Forms.Padding(2);
            this.inputLabel32.RowIndex = 12;
            this.inputLabel32.Text = "Label";
            this.inputLabel32.VerticalAlign = C1.Win.InputPanel.InputContentAlignment.Center;
            // 
            // itemsValue
            // 
            this.itemsValue.ColumnIndex = 1;
            this.itemsValue.ColumnSpan = 2;
            this.itemsValue.CurrencySymbol = "$";
            this.itemsValue.DataBindings.Add(new System.Windows.Forms.Binding("BoundValue", this.billOfSaleBindingSource, "ItemsValue", true));
            this.itemsValue.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.billOfSaleBindingSource, "ItemsValue", true));
            this.itemsValue.DecimalPlaces = 2;
            this.itemsValue.Format = "c";
            this.itemsValue.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.itemsValue.Name = "itemsValue";
            this.itemsValue.Padding = new System.Windows.Forms.Padding(2);
            this.itemsValue.RowIndex = 11;
            this.itemsValue.Width = 102;
            // 
            // billOfSaleBindingSource
            // 
            this.billOfSaleBindingSource.DataSource = typeof(SaleInfo);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 749);
            this.Controls.Add(this.c1InputPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.c1InputPanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billOfSaleBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.InputPanel.C1InputPanel c1InputPanel1;
        private C1.Win.InputPanel.InputGroupHeader inputGroupHeader1;
        private C1.Win.InputPanel.InputGridPanel inputGridPanel1;
        private C1.Win.InputPanel.InputLabel inputLabel1;
        private C1.Win.InputPanel.InputLabel inputLabel2;
        private C1.Win.InputPanel.InputTextBox sellerPrintedName;
        private C1.Win.InputPanel.InputLabel inputLabel3;
        private C1.Win.InputPanel.InputTextBox sellerAddress;
        private C1.Win.InputPanel.InputLabel inputLabel4;
        private C1.Win.InputPanel.InputTextBox sellerCity;
        private C1.Win.InputPanel.InputLabel inputLabel5;
        private C1.Win.InputPanel.InputTextBox sellerState;
        private C1.Win.InputPanel.InputLabel inputLabel6;
        private C1.Win.InputPanel.InputTextBox sellerZip;
        private C1.Win.InputPanel.InputLabel inputLabel7;
        private C1.Win.InputPanel.InputTextBox sellerHomePhone;
        private C1.Win.InputPanel.InputLabel inputLabel8;
        private C1.Win.InputPanel.InputTextBox sellerCellPhone;
        private C1.Win.InputPanel.InputLabel inputLabel9;
        private C1.Win.InputPanel.InputTextBox sellerWork;
        private C1.Win.InputPanel.InputLabel inputLabel10;
        private C1.Win.InputPanel.InputTextBox buyerPrintedName;
        private C1.Win.InputPanel.InputLabel inputLabel11;
        private C1.Win.InputPanel.InputTextBox buyerAddress;
        private C1.Win.InputPanel.InputLabel inputLabel12;
        private C1.Win.InputPanel.InputTextBox buyerCity;
        private C1.Win.InputPanel.InputLabel inputLabel13;
        private C1.Win.InputPanel.InputTextBox buyerState;
        private C1.Win.InputPanel.InputLabel inputLabel14;
        private C1.Win.InputPanel.InputTextBox Zip;
        private C1.Win.InputPanel.InputLabel inputLabel15;
        private C1.Win.InputPanel.InputLabel inputLabel16;
        private C1.Win.InputPanel.InputTextBox buyerHomePhone;
        private C1.Win.InputPanel.InputLabel inputLabel17;
        private C1.Win.InputPanel.InputTextBox buyerCellPhone;
        private C1.Win.InputPanel.InputLabel inputLabel18;
        private C1.Win.InputPanel.InputTextBox buyerWork;
        private C1.Win.InputPanel.InputLabel inputLabel19;
        private C1.Win.InputPanel.InputLabel inputLabel20;
        private C1.Win.InputPanel.InputLabel inputLabel21;
        private C1.Win.InputPanel.InputLabel inputLabel23;
        private C1.Win.InputPanel.InputTextBox formOfPayment;
        private C1.Win.InputPanel.InputLabel inputLabel24;
        private C1.Win.InputPanel.InputLabel inputLabel25;
        private C1.Win.InputPanel.InputLabel inputLabel26;
        private C1.Win.InputPanel.InputLabel inputLabel27;
        private C1.Win.InputPanel.InputLabel inputLabel28;
        private C1.Win.InputPanel.InputLabel inputLabel22;
        private C1.Win.InputPanel.InputLabel inputLabel29;
        private C1.Win.InputPanel.InputLabel inputLabel30;
        private C1.Win.InputPanel.InputLabel inputLabel31;
        private C1.Win.InputPanel.InputDatePicker dateSold;
        private C1.Win.InputPanel.InputDatePicker SellerDateSign;
        private C1.Win.InputPanel.InputDatePicker BuyerDateSign;
        private C1.Win.InputPanel.InputLabel inputLabel32;
        private C1.Win.InputPanel.InputNumericBox itemsValue;
        private System.Windows.Forms.BindingSource billOfSaleBindingSource;
		private RichTextBoxHost itemsInfo;

    }
    class SaleInfo
    {
        public DateTime DateSold { get; set; }
        public Transactor Seller { get; set; }
        public Transactor Buyer { get; set; }
        public string ItemsInfo { get; set; }
        public int ItemsValue { get; set; }
        public string FormOfPayment { get; set; }
        public SaleInfo(DateTime dateS, Transactor s, Transactor b, string itemsInfo, int itemsValue, string formPayment)
        {
            DateSold = dateS;
            Seller = s;
            Buyer = b;
            ItemsInfo = itemsInfo;
            ItemsValue = itemsValue;
            FormOfPayment = formPayment;
        }

    }
    struct Transactor
    {
        public string PrintedName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string HomePhone { get; set; }
        public string CellPhone { get; set; }
        public string Work { get; set; }
        public DateTime DateSign { get; set; }

        public Transactor(string printName, string adress, string city, string state, string zip,
            string homePhone, string cellPhone, string work, DateTime dateSign)
        {

            PrintedName = printName;
            Address = adress;
            City = city;
            State = state;
            Zip = zip;
            HomePhone = homePhone;
            CellPhone = cellPhone;
            Work = work;
            DateSign = dateSign;
        }

    }

    public class RichTextBoxHost : C1.Win.InputPanel.InputControlHost
    {
        public RichTextBoxHost()
            : base(new System.Windows.Forms.RichTextBox())
        {
        }
    }

}
