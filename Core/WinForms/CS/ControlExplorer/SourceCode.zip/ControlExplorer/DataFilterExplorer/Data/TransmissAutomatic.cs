﻿namespace DataFilterExplorer.Data
{
    public class TransmissAutomatic
    {
        public string DisplayValue { get; set; }
        public object Value { get; set; }
    }
}
