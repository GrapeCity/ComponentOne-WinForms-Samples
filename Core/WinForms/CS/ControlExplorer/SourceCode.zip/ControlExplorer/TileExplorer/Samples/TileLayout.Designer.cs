﻿namespace TileExplorer.Samples
{
    partial class TileLayout
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TileLayout));
            C1.Win.Tile.PanelElement panelElement1 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement2 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement3 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement4 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement5 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement6 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement1 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.TextElement textElement1 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement7 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement8 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement9 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement2 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement10 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement3 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement11 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement12 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement4 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement13 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement5 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement14 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement6 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.TextElement textElement2 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement15 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement16 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement7 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.TextElement textElement3 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement4 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement17 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement8 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.ImageElement imageElement9 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.ImageElement imageElement10 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.ImageElement imageElement11 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.TextElement textElement5 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement6 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement7 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement8 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement18 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement9 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement19 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement10 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.ImageElement imageElement12 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement20 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement13 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement21 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement11 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement22 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.PanelElement panelElement23 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement12 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement13 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement24 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement14 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement15 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement25 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement16 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement17 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement26 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement18 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement19 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement27 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement20 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement21 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement28 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement22 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement23 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement29 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement24 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement25 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement30 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement26 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement27 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement31 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement14 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.TextElement textElement28 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement32 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement15 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement33 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement16 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.TextElement textElement29 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.PanelElement panelElement34 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement30 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement31 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.TextElement textElement32 = new C1.Win.Tile.TextElement();
            this.c1TileControl1 = new C1.Win.Tile.C1TileControl();
            this.group1 = new C1.Win.Tile.Group();
            this.tile1 = new C1.Win.Tile.Tile();
            this.template1 = new C1.Win.Tile.Template();
            this.tile2 = new C1.Win.Tile.Tile();
            this.template2 = new C1.Win.Tile.Template();
            this.tile3 = new C1.Win.Tile.Tile();
            this.template3 = new C1.Win.Tile.Template();
            this.tile4 = new C1.Win.Tile.Tile();
            this.template41 = new C1.Win.Tile.Template();
            this.tile5 = new C1.Win.Tile.Tile();
            this.template5 = new C1.Win.Tile.Template();
            this.tile6 = new C1.Win.Tile.Tile();
            this.template6 = new C1.Win.Tile.Template();
            this.tile7 = new C1.Win.Tile.Tile();
            this.template7 = new C1.Win.Tile.Template();
            this.tile8 = new C1.Win.Tile.Tile();
            this.template89 = new C1.Win.Tile.Template();
            this.tile9 = new C1.Win.Tile.Tile();
            this.template42 = new C1.Win.Tile.Template();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // c1TileControl1
            // 
            this.c1TileControl1.AllowChecking = true;
            this.c1TileControl1.AllowRearranging = true;
            this.c1TileControl1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("c1TileControl1.BackgroundImage")));
            this.c1TileControl1.CellSpacing = 20;
            this.c1TileControl1.CheckBorderColor = System.Drawing.Color.RoyalBlue;
            this.c1TileControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1TileControl1.GroupPadding = new System.Windows.Forms.Padding(0);
            this.c1TileControl1.Groups.Add(this.group1);
            this.c1TileControl1.GroupTextSize = 12F;
            this.c1TileControl1.HotBorderColor = System.Drawing.Color.LightSkyBlue;
            this.c1TileControl1.Location = new System.Drawing.Point(0, 0);
            this.c1TileControl1.MaximumRowsOrColumns = 3;
            this.c1TileControl1.MovingBackground = true;
            this.c1TileControl1.Name = "c1TileControl1";
            this.c1TileControl1.Padding = new System.Windows.Forms.Padding(0, 52, 0, 0);
            this.c1TileControl1.Size = new System.Drawing.Size(632, 434);
            this.c1TileControl1.SurfaceContentAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.c1TileControl1.SurfacePadding = new System.Windows.Forms.Padding(30, 10, 30, 30);
            this.c1TileControl1.TabIndex = 0;
            this.c1TileControl1.Templates.Add(this.template1);
            this.c1TileControl1.Templates.Add(this.template2);
            this.c1TileControl1.Templates.Add(this.template3);
            this.c1TileControl1.Templates.Add(this.template41);
            this.c1TileControl1.Templates.Add(this.template42);
            this.c1TileControl1.Templates.Add(this.template5);
            this.c1TileControl1.Templates.Add(this.template6);
            this.c1TileControl1.Templates.Add(this.template7);
            this.c1TileControl1.Templates.Add(this.template89);
            this.c1TileControl1.Text = "Template Elements And Layout Options";
            this.c1TileControl1.TextSize = 18F;
            this.c1TileControl1.TextX = 32;
            this.c1TileControl1.TextY = 12;
            // 
            // group1
            // 
            this.group1.Name = "group1";
            this.group1.Tiles.Add(this.tile1);
            this.group1.Tiles.Add(this.tile2);
            this.group1.Tiles.Add(this.tile3);
            this.group1.Tiles.Add(this.tile4);
            this.group1.Tiles.Add(this.tile5);
            this.group1.Tiles.Add(this.tile6);
            this.group1.Tiles.Add(this.tile7);
            this.group1.Tiles.Add(this.tile8);
            this.group1.Tiles.Add(this.tile9);
            // 
            // tile1
            // 
            this.tile1.BackColor = System.Drawing.Color.LightCoral;
            this.tile1.HorizontalSize = 2;
            this.tile1.Name = "tile1";
            this.tile1.Template = this.template1;
            this.tile1.Text = "Two docked panels with nested panels";
            this.tile1.VerticalSize = 2;
            // 
            // template1
            // 
            this.template1.Description = "Template 1";
            panelElement1.AlignmentOfContents = System.Drawing.ContentAlignment.MiddleCenter;
            panelElement1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            panelElement2.BackColor = System.Drawing.Color.Silver;
            panelElement2.FixedHeight = 20;
            panelElement2.FixedWidth = 20;
            panelElement3.BackColor = System.Drawing.Color.Gray;
            panelElement3.FixedHeight = 20;
            panelElement3.FixedWidth = 20;
            panelElement4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            panelElement4.FixedHeight = 20;
            panelElement4.FixedWidth = 20;
            panelElement1.Children.Add(panelElement2);
            panelElement1.Children.Add(panelElement3);
            panelElement1.Children.Add(panelElement4);
            panelElement1.Dock = System.Windows.Forms.DockStyle.Bottom;
            panelElement1.FixedHeight = 50;
            panelElement5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            panelElement6.AlignmentOfContents = System.Drawing.ContentAlignment.MiddleCenter;
            panelElement6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            imageElement1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            imageElement1.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            imageElement1.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement1.Symbol = C1.Win.Tile.TileSymbol.ViewAllAlbums;
            panelElement6.Children.Add(imageElement1);
            panelElement6.Dock = System.Windows.Forms.DockStyle.Fill;
            panelElement5.Children.Add(panelElement6);
            panelElement5.Dock = System.Windows.Forms.DockStyle.Left;
            panelElement5.FixedWidth = 80;
            panelElement5.Padding = new System.Windows.Forms.Padding(10);
            textElement1.Margin = new System.Windows.Forms.Padding(90, 0, 10, 50);
            this.template1.Elements.Add(panelElement1);
            this.template1.Elements.Add(panelElement5);
            this.template1.Elements.Add(textElement1);
            this.template1.Name = "template1";
            // 
            // tile2
            // 
            this.tile2.BackColor = System.Drawing.Color.Khaki;
            this.tile2.ForeColor = System.Drawing.Color.Black;
            this.tile2.Name = "tile2";
            this.tile2.Template = this.template2;
            this.tile2.Text = "Tile 2";
            // 
            // template2
            // 
            this.template2.Description = "Template 2";
            panelElement9.BackColor = System.Drawing.Color.LightSteelBlue;
            imageElement2.ImageLayout = C1.Win.Tile.ForeImageLayout.Stretch;
            imageElement2.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement2.Symbol = C1.Win.Tile.TileSymbol.Cut;
            panelElement9.Children.Add(imageElement2);
            panelElement9.Description = "left top";
            panelElement9.FixedHeight = 32;
            panelElement9.FixedWidth = 32;
            panelElement10.BackColor = System.Drawing.Color.LightSteelBlue;
            imageElement3.ImageLayout = C1.Win.Tile.ForeImageLayout.Stretch;
            imageElement3.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement3.Symbol = C1.Win.Tile.TileSymbol.Paste;
            panelElement10.Children.Add(imageElement3);
            panelElement10.Description = "left bottom";
            panelElement10.FixedHeight = 32;
            panelElement10.FixedWidth = 32;
            panelElement8.Children.Add(panelElement9);
            panelElement8.Children.Add(panelElement10);
            panelElement8.ChildSpacing = 10;
            panelElement8.Description = "left panel";
            panelElement8.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            panelElement12.BackColor = System.Drawing.Color.LightSteelBlue;
            imageElement4.ImageLayout = C1.Win.Tile.ForeImageLayout.Stretch;
            imageElement4.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement4.Symbol = C1.Win.Tile.TileSymbol.Copy;
            panelElement12.Children.Add(imageElement4);
            panelElement12.Description = "right top";
            panelElement12.FixedHeight = 32;
            panelElement12.FixedWidth = 32;
            panelElement13.BackColor = System.Drawing.Color.LightSteelBlue;
            imageElement5.ImageLayout = C1.Win.Tile.ForeImageLayout.Stretch;
            imageElement5.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement5.Symbol = C1.Win.Tile.TileSymbol.Delete;
            panelElement13.Children.Add(imageElement5);
            panelElement13.Description = "right bottom";
            panelElement13.FixedHeight = 32;
            panelElement13.FixedWidth = 32;
            panelElement11.Children.Add(panelElement12);
            panelElement11.Children.Add(panelElement13);
            panelElement11.ChildSpacing = 10;
            panelElement11.Description = "right panel";
            panelElement11.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            panelElement7.Children.Add(panelElement8);
            panelElement7.Children.Add(panelElement11);
            panelElement7.ChildSpacing = 10;
            panelElement7.Description = "outer panel";
            this.template2.Elements.Add(panelElement7);
            this.template2.Name = "template2";
            // 
            // tile3
            // 
            this.tile3.BackColor = System.Drawing.Color.SteelBlue;
            this.tile3.HorizontalSize = 2;
            this.tile3.Name = "tile3";
            this.tile3.Template = this.template3;
            this.tile3.Text = "Text and image overlapped with a semi-transparent docked panel";
            // 
            // template3
            // 
            this.template3.Description = "Template 3";
            imageElement6.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement6.Symbol = C1.Win.Tile.TileSymbol.Shop;
            imageElement6.SymbolSize = C1.Win.Tile.SymbolSize.Image48x48;
            textElement2.FixedWidth = 110;
            panelElement14.Children.Add(imageElement6);
            panelElement14.Children.Add(textElement2);
            panelElement14.ChildSpacing = 10;
            panelElement15.Alignment = System.Drawing.ContentAlignment.TopLeft;
            panelElement15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            panelElement15.Dock = System.Windows.Forms.DockStyle.Top;
            panelElement15.FixedHeight = 51;
            this.template3.Elements.Add(panelElement14);
            this.template3.Elements.Add(panelElement15);
            this.template3.Name = "template3";
            this.template3.Padding = new System.Windows.Forms.Padding(8);
            // 
            // tile4
            // 
            this.tile4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.tile4.ForeColor = System.Drawing.Color.White;
            this.tile4.Name = "tile4";
            this.tile4.Symbol = C1.Win.Tile.TileSymbol.Street;
            this.tile4.Template = this.template41;
            this.tile4.Text = "Tile Header";
            this.tile4.Text1 = "Detailed description of the tile.";
            this.tile4.Text2 = "More information and details of the tile behavior.";
            this.tile4.VerticalSize = 2;
            // 
            // template41
            // 
            this.template41.Description = "Template 4a";
            panelElement16.Alignment = System.Drawing.ContentAlignment.TopLeft;
            imageElement7.ImageSelector = C1.Win.Tile.ImageSelector.Symbol;
            imageElement7.SymbolSize = C1.Win.Tile.SymbolSize.Image80x80;
            textElement3.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement3.FontSize = 14F;
            textElement3.Margin = new System.Windows.Forms.Padding(4, 0, 0, 8);
            textElement4.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            textElement4.TextSelector = C1.Win.Tile.TextSelector.Text1;
            panelElement16.Children.Add(imageElement7);
            panelElement16.Children.Add(textElement3);
            panelElement16.Children.Add(textElement4);
            panelElement16.ChildSpacing = 0;
            panelElement16.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            this.template41.Elements.Add(panelElement16);
            this.template41.Name = "template41";
            this.template41.Padding = new System.Windows.Forms.Padding(10, 8, 10, 8);
            // 
            // tile5
            // 
            this.tile5.BackColor = System.Drawing.Color.DimGray;
            this.tile5.HorizontalSize = 3;
            this.tile5.Name = "tile5";
            this.tile5.Template = this.template5;
            this.tile5.Text = "A panel with elements using various Alignment";
            // 
            // template5
            // 
            this.template5.Description = "Template 5";
            imageElement8.FixedHeight = 70;
            imageElement8.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement8.Symbol = C1.Win.Tile.TileSymbol.LeftToRight;
            imageElement8.SymbolSize = C1.Win.Tile.SymbolSize.Image64x64;
            imageElement9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            imageElement9.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            imageElement9.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement9.Symbol = C1.Win.Tile.TileSymbol.CircleWithPlus;
            imageElement10.Alignment = System.Drawing.ContentAlignment.TopCenter;
            imageElement10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            imageElement10.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            imageElement10.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement10.Symbol = C1.Win.Tile.TileSymbol.CircleWithMinus;
            imageElement11.Alignment = System.Drawing.ContentAlignment.BottomCenter;
            imageElement11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            imageElement11.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            imageElement11.ImageSelector = C1.Win.Tile.ImageSelector.UnboundSymbol;
            imageElement11.Symbol = C1.Win.Tile.TileSymbol.CircleWithMultiply;
            textElement5.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            textElement5.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            textElement5.Text = "Middle";
            textElement5.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement6.Alignment = System.Drawing.ContentAlignment.TopCenter;
            textElement6.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            textElement6.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            textElement6.Text = "Top";
            textElement6.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement7.Alignment = System.Drawing.ContentAlignment.BottomCenter;
            textElement7.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement7.DirectionVertical = true;
            textElement7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            textElement7.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            textElement7.Text = "Bottom";
            textElement7.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            panelElement17.Children.Add(imageElement8);
            panelElement17.Children.Add(imageElement9);
            panelElement17.Children.Add(imageElement10);
            panelElement17.Children.Add(imageElement11);
            panelElement17.Children.Add(textElement5);
            panelElement17.Children.Add(textElement6);
            panelElement17.Children.Add(textElement7);
            panelElement17.ChildSpacing = 9;
            panelElement17.Margin = new System.Windows.Forms.Padding(0, 0, 0, 18);
            textElement8.Alignment = System.Drawing.ContentAlignment.BottomCenter;
            textElement8.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.template5.Elements.Add(panelElement17);
            this.template5.Elements.Add(textElement8);
            this.template5.Name = "template5";
            // 
            // tile6
            // 
            this.tile6.ForeColor = System.Drawing.Color.Black;
            this.tile6.HorizontalSize = 3;
            this.tile6.Image = ((System.Drawing.Image)(resources.GetObject("tile6.Image")));
            this.tile6.IntValue = 7;
            this.tile6.Name = "tile6";
            this.tile6.Template = this.template6;
            this.tile6.Text = "Internet Explorer";
            this.tile6.Text1 = "Free";
            this.tile6.VerticalSize = 2;
            // 
            // template6
            // 
            this.template6.Description = "Template 6";
            panelElement18.BackColor = System.Drawing.Color.Snow;
            textElement9.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement9.BackColor = System.Drawing.Color.Snow;
            textElement9.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement9.FontBold = C1.Win.Tile.ThreeStateBoolean.True;
            textElement9.FontSize = 11F;
            panelElement19.Alignment = System.Drawing.ContentAlignment.MiddleLeft;
            textElement10.BackColor = System.Drawing.Color.Snow;
            textElement10.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement10.FontSize = 11F;
            textElement10.TextSelector = C1.Win.Tile.TextSelector.Text1;
            imageElement12.ForeColor = System.Drawing.Color.IndianRed;
            imageElement12.ForeColorSelector = C1.Win.Tile.ForeColorSelector.Unbound;
            imageElement12.ImageSelector = C1.Win.Tile.ImageSelector.Stars;
            imageElement12.Margin = new System.Windows.Forms.Padding(0, 2, 0, 0);
            panelElement19.Children.Add(textElement10);
            panelElement19.Children.Add(imageElement12);
            panelElement18.Children.Add(textElement9);
            panelElement18.Children.Add(panelElement19);
            panelElement18.ChildSpacing = 3;
            panelElement18.Dock = System.Windows.Forms.DockStyle.Bottom;
            panelElement18.FixedHeight = 60;
            panelElement18.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            panelElement18.Padding = new System.Windows.Forms.Padding(10, 4, 10, 10);
            imageElement13.ImageLayout = C1.Win.Tile.ForeImageLayout.ScaleOuter;
            panelElement20.Children.Add(imageElement13);
            panelElement20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.template6.Elements.Add(panelElement18);
            this.template6.Elements.Add(panelElement20);
            this.template6.Name = "template6";
            // 
            // tile7
            // 
            this.tile7.BackColor = System.Drawing.Color.RosyBrown;
            this.tile7.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tile7.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tile7.ForeColor = System.Drawing.Color.White;
            this.tile7.ForeColor1 = System.Drawing.Color.Black;
            this.tile7.ForeColor2 = System.Drawing.Color.IndianRed;
            this.tile7.HorizontalSize = 2;
            this.tile7.IntValue = 100;
            this.tile7.Name = "tile7";
            this.tile7.Symbol = C1.Win.Tile.TileSymbol.Mail;
            this.tile7.Template = this.template7;
            this.tile7.Text = "This tile shows a few text elements and a badge if IntValue > 0";
            this.tile7.Text1 = "First text message";
            this.tile7.Text2 = "Second text message";
            this.tile7.Text3 = "Third text message";
            this.tile7.Text4 = "Fourth text message";
            this.tile7.Text5 = "Fifth text message";
            this.tile7.Text6 = "Sixth text message";
            this.tile7.Text7 = "Seventh text message";
            this.tile7.Text8 = "Eighth text message";
            this.tile7.Text9 = "*notes";
            this.tile7.VerticalSize = 3;
            // 
            // template7
            // 
            this.template7.Description = "Template 7";
            textElement11.AlignmentOfContents = System.Drawing.ContentAlignment.TopCenter;
            textElement11.FontSize = 14F;
            textElement11.Margin = new System.Windows.Forms.Padding(0, 3, 0, 6);
            panelElement22.BackColor = System.Drawing.Color.CadetBlue;
            panelElement23.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement12.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement12.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement12.FixedWidth = 16;
            textElement12.Text = "1.";
            textElement12.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement13.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement13.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement13.TextSelector = C1.Win.Tile.TextSelector.Text1;
            panelElement23.Children.Add(textElement12);
            panelElement23.Children.Add(textElement13);
            panelElement23.ChildSpacing = 0;
            panelElement24.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement14.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement14.FixedWidth = 16;
            textElement14.Text = "2.";
            textElement14.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement15.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement15.TextSelector = C1.Win.Tile.TextSelector.Text2;
            panelElement24.Children.Add(textElement14);
            panelElement24.Children.Add(textElement15);
            panelElement24.ChildSpacing = 0;
            panelElement25.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement16.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement16.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor1;
            textElement16.FixedWidth = 16;
            textElement16.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor1;
            textElement16.Text = "3.";
            textElement16.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement17.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement17.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor1;
            textElement17.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor1;
            textElement17.TextSelector = C1.Win.Tile.TextSelector.Text3;
            panelElement25.Children.Add(textElement16);
            panelElement25.Children.Add(textElement17);
            panelElement25.ChildSpacing = 0;
            panelElement26.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement18.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement18.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor2;
            textElement18.FixedWidth = 16;
            textElement18.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor2;
            textElement18.Text = "4.";
            textElement18.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement19.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement19.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor2;
            textElement19.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor2;
            textElement19.TextSelector = C1.Win.Tile.TextSelector.Text4;
            panelElement26.Children.Add(textElement18);
            panelElement26.Children.Add(textElement19);
            panelElement26.ChildSpacing = 0;
            panelElement27.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement20.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement20.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement20.FixedWidth = 16;
            textElement20.Text = "5.";
            textElement20.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement21.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement21.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            textElement21.TextSelector = C1.Win.Tile.TextSelector.Text5;
            panelElement27.Children.Add(textElement20);
            panelElement27.Children.Add(textElement21);
            panelElement27.ChildSpacing = 0;
            panelElement28.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement22.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement22.FixedWidth = 16;
            textElement22.Text = "6.";
            textElement22.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement23.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement23.TextSelector = C1.Win.Tile.TextSelector.Text6;
            panelElement28.Children.Add(textElement22);
            panelElement28.Children.Add(textElement23);
            panelElement28.ChildSpacing = 0;
            panelElement29.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement24.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement24.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor1;
            textElement24.FixedWidth = 16;
            textElement24.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor1;
            textElement24.Text = "7.";
            textElement24.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement25.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement25.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor1;
            textElement25.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor1;
            textElement25.TextSelector = C1.Win.Tile.TextSelector.Text7;
            panelElement29.Children.Add(textElement24);
            panelElement29.Children.Add(textElement25);
            panelElement29.ChildSpacing = 0;
            panelElement30.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement26.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement26.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor2;
            textElement26.FixedWidth = 16;
            textElement26.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor2;
            textElement26.Text = "8.";
            textElement26.TextSelector = C1.Win.Tile.TextSelector.Unbound;
            textElement27.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement27.BackColorSelector = C1.Win.Tile.BackColorSelector.BackColor2;
            textElement27.ForeColorSelector = C1.Win.Tile.ForeColorSelector.ForeColor2;
            textElement27.TextSelector = C1.Win.Tile.TextSelector.Text8;
            panelElement30.Children.Add(textElement26);
            panelElement30.Children.Add(textElement27);
            panelElement30.ChildSpacing = 0;
            panelElement22.Children.Add(panelElement23);
            panelElement22.Children.Add(panelElement24);
            panelElement22.Children.Add(panelElement25);
            panelElement22.Children.Add(panelElement26);
            panelElement22.Children.Add(panelElement27);
            panelElement22.Children.Add(panelElement28);
            panelElement22.Children.Add(panelElement29);
            panelElement22.Children.Add(panelElement30);
            panelElement22.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            panelElement22.Padding = new System.Windows.Forms.Padding(4);
            panelElement21.Children.Add(textElement11);
            panelElement21.Children.Add(panelElement22);
            panelElement21.ChildSpacing = 8;
            panelElement21.Dock = System.Windows.Forms.DockStyle.Fill;
            panelElement21.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            panelElement21.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            panelElement31.Alignment = System.Drawing.ContentAlignment.BottomLeft;
            imageElement14.AlignmentOfContents = System.Drawing.ContentAlignment.MiddleLeft;
            imageElement14.FixedHeight = 24;
            imageElement14.ImageSelector = C1.Win.Tile.ImageSelector.Symbol;
            textElement28.TextSelector = C1.Win.Tile.TextSelector.Text9;
            panelElement31.Children.Add(imageElement14);
            panelElement31.Children.Add(textElement28);
            panelElement32.Alignment = System.Drawing.ContentAlignment.BottomRight;
            panelElement32.BackColor = System.Drawing.Color.SteelBlue;
            imageElement15.ImageSelector = C1.Win.Tile.ImageSelector.Number;
            panelElement32.Children.Add(imageElement15);
            panelElement32.Margin = new System.Windows.Forms.Padding(0, 0, 0, 2);
            panelElement32.Padding = new System.Windows.Forms.Padding(4);
            panelElement32.VisibleSelector = C1.Win.Tile.IntValueSelector.Default;
            this.template7.Elements.Add(panelElement21);
            this.template7.Elements.Add(panelElement31);
            this.template7.Elements.Add(panelElement32);
            this.template7.Name = "template7";
            this.template7.Padding = new System.Windows.Forms.Padding(10, 10, 10, 8);
            // 
            // tile8
            // 
            this.tile8.BackColor = System.Drawing.Color.CadetBlue;
            this.tile8.Name = "tile8";
            this.tile8.Symbol = C1.Win.Tile.TileSymbol.Settings;
            this.tile8.Template = this.template89;
            this.tile8.Text = "Options";
            // 
            // template89
            // 
            this.template89.Description = "Template 8";
            imageElement16.AlignmentOfContents = System.Drawing.ContentAlignment.MiddleCenter;
            imageElement16.FixedHeight = 46;
            imageElement16.ImageSelector = C1.Win.Tile.ImageSelector.Symbol;
            imageElement16.SymbolSize = C1.Win.Tile.SymbolSize.Image48x48;
            textElement29.FontSize = 14F;
            panelElement33.Children.Add(imageElement16);
            panelElement33.Children.Add(textElement29);
            panelElement33.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            this.template89.Elements.Add(panelElement33);
            this.template89.Name = "template89";
            // 
            // tile9
            // 
            this.tile9.BackColor = System.Drawing.Color.Moccasin;
            this.tile9.ForeColor = System.Drawing.Color.DimGray;
            this.tile9.Name = "tile9";
            this.tile9.Symbol = C1.Win.Tile.TileSymbol.Sync;
            this.tile9.Template = this.template89;
            this.tile9.Text = "Updates";
            // 
            // template42
            // 
            this.template42.Description = "Template 4b";
            panelElement34.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement30.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement30.FontSize = 14F;
            textElement30.Margin = new System.Windows.Forms.Padding(4, 0, 0, 8);
            textElement31.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            textElement31.TextSelector = C1.Win.Tile.TextSelector.Text1;
            textElement32.Alignment = System.Drawing.ContentAlignment.TopLeft;
            textElement32.Margin = new System.Windows.Forms.Padding(4, 8, 4, 0);
            textElement32.TextSelector = C1.Win.Tile.TextSelector.Text2;
            panelElement34.Children.Add(textElement30);
            panelElement34.Children.Add(textElement31);
            panelElement34.Children.Add(textElement32);
            panelElement34.ChildSpacing = 0;
            panelElement34.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            this.template42.Elements.Add(panelElement34);
            this.template42.Name = "template42";
            this.template42.Padding = new System.Windows.Forms.Padding(10, 8, 10, 8);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 3000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(632, 434);
            this.Controls.Add(this.c1TileControl1);
            this.ForeColor = System.Drawing.Color.White;            
            this.ResumeLayout(false);
        }

        #endregion

        private C1.Win.Tile.C1TileControl c1TileControl1;
        private System.Windows.Forms.Timer timer1;
        private C1.Win.Tile.Group group1;
        private C1.Win.Tile.Tile tile1;
        private C1.Win.Tile.Template template1;
        private C1.Win.Tile.Tile tile2;
        private C1.Win.Tile.Template template2;
        private C1.Win.Tile.Tile tile3;
        private C1.Win.Tile.Template template3;
        private C1.Win.Tile.Tile tile4;
        private C1.Win.Tile.Template template41;
        private C1.Win.Tile.Tile tile5;
        private C1.Win.Tile.Template template5;
        private C1.Win.Tile.Tile tile6;
        private C1.Win.Tile.Template template6;
        private C1.Win.Tile.Tile tile7;
        private C1.Win.Tile.Template template7;
        private C1.Win.Tile.Tile tile8;
        private C1.Win.Tile.Template template89;
        private C1.Win.Tile.Tile tile9;
        private C1.Win.Tile.Template template42;
    }
}
