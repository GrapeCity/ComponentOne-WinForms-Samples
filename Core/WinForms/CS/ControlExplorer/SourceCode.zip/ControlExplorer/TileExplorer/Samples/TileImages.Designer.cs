﻿namespace TileExplorer.Samples
{
    partial class TileImages
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            C1.Win.Tile.ImageElement imageElement1 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.ImageElement imageElement2 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement1 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.TextElement textElement1 = new C1.Win.Tile.TextElement();
            C1.Win.Tile.ImageElement imageElement3 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.ImageElement imageElement4 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.ImageElement imageElement5 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement2 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement6 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.PanelElement panelElement3 = new C1.Win.Tile.PanelElement();
            C1.Win.Tile.ImageElement imageElement7 = new C1.Win.Tile.ImageElement();
            C1.Win.Tile.ImageElement imageElement8 = new C1.Win.Tile.ImageElement();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TileImages));
            this.c1TileControl1 = new C1.Win.Tile.C1TileControl();
            this.group1 = new C1.Win.Tile.Group();
            this.tile1 = new C1.Win.Tile.Tile();
            this.template1 = new C1.Win.Tile.Template();
            this.tile2 = new C1.Win.Tile.Tile();
            this.tile3 = new C1.Win.Tile.Tile();
            this.group2 = new C1.Win.Tile.Group();
            this.tile4 = new C1.Win.Tile.Tile();
            this.template2 = new C1.Win.Tile.Template();
            this.tile5 = new C1.Win.Tile.Tile();
            this.tile6 = new C1.Win.Tile.Tile();
            this.group3 = new C1.Win.Tile.Group();
            this.tile7 = new C1.Win.Tile.Tile();
            this.template3 = new C1.Win.Tile.Template();
            this.tile8 = new C1.Win.Tile.Tile();
            this.tile9 = new C1.Win.Tile.Tile();
            this.group4 = new C1.Win.Tile.Group();
            this.tile10 = new C1.Win.Tile.Tile();
            this.template4 = new C1.Win.Tile.Template();
            this.tile11 = new C1.Win.Tile.Tile();
            this.tile12 = new C1.Win.Tile.Tile();
            this.group5 = new C1.Win.Tile.Group();
            this.tile13 = new C1.Win.Tile.Tile();
            this.template5 = new C1.Win.Tile.Template();
            this.tile14 = new C1.Win.Tile.Tile();
            this.tile15 = new C1.Win.Tile.Tile();
            this.group6 = new C1.Win.Tile.Group();
            this.tile16 = new C1.Win.Tile.Tile();
            this.template6 = new C1.Win.Tile.Template();
            this.tile17 = new C1.Win.Tile.Tile();
            this.tile18 = new C1.Win.Tile.Tile();
            this.group7 = new C1.Win.Tile.Group();
            this.tile19 = new C1.Win.Tile.Tile();
            this.template7 = new C1.Win.Tile.Template();
            this.tile20 = new C1.Win.Tile.Tile();
            this.tile21 = new C1.Win.Tile.Tile();
            this.group8 = new C1.Win.Tile.Group();
            this.tile22 = new C1.Win.Tile.Tile();
            this.template8 = new C1.Win.Tile.Template();
            this.tile23 = new C1.Win.Tile.Tile();
            this.tile24 = new C1.Win.Tile.Tile();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // c1TileControl1
            // 
            this.c1TileControl1.AutomaticLayout = false;
            this.c1TileControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(96)))));
            this.c1TileControl1.CellHeight = 50;
            this.c1TileControl1.CellWidth = 50;
            this.c1TileControl1.CommonImage1.Image = global::TileExplorer.Properties.Resources.Images;
            this.c1TileControl1.CommonImage1.ImageColumns = 3;
            this.c1TileControl1.CommonImage1.ImageRows = 2;
            // 
            // 
            // 
            this.c1TileControl1.DefaultTemplate.Elements.Add(imageElement1);
            this.c1TileControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1TileControl1.ForeColor = System.Drawing.Color.LightSalmon;
            this.c1TileControl1.GroupForeColor = System.Drawing.Color.White;
            this.c1TileControl1.Groups.Add(this.group1);
            this.c1TileControl1.Groups.Add(this.group2);
            this.c1TileControl1.Groups.Add(this.group3);
            this.c1TileControl1.Groups.Add(this.group4);
            this.c1TileControl1.Groups.Add(this.group5);
            this.c1TileControl1.Groups.Add(this.group6);
            this.c1TileControl1.Groups.Add(this.group7);
            this.c1TileControl1.Groups.Add(this.group8);
            this.c1TileControl1.GroupTextSize = 12F;
            this.c1TileControl1.ImageList = this.imageList1;
            this.c1TileControl1.Location = new System.Drawing.Point(0, 0);
            this.c1TileControl1.Name = "c1TileControl1";
            this.c1TileControl1.Orientation = C1.Win.Tile.LayoutOrientation.Vertical;
            this.c1TileControl1.PassthroughNavigation = true;
            this.c1TileControl1.Size = new System.Drawing.Size(632, 428);
            this.c1TileControl1.TabIndex = 0;
            this.c1TileControl1.Templates.Add(this.template1);
            this.c1TileControl1.Templates.Add(this.template2);
            this.c1TileControl1.Templates.Add(this.template3);
            this.c1TileControl1.Templates.Add(this.template4);
            this.c1TileControl1.Templates.Add(this.template5);
            this.c1TileControl1.Templates.Add(this.template6);
            this.c1TileControl1.Templates.Add(this.template7);
            this.c1TileControl1.Templates.Add(this.template8);
            this.c1TileControl1.Text = "How to display an image on the Tile";
            this.c1TileControl1.TextSize = 18F;
            this.c1TileControl1.TileBackColor = System.Drawing.Color.IndianRed;
            // 
            // group1
            // 
            this.group1.Name = "group1";
            this.group1.Text = "1. Use the Tile.Image property";
            this.group1.Tiles.Add(this.tile1);
            this.group1.Tiles.Add(this.tile2);
            this.group1.Tiles.Add(this.tile3);
            // 
            // tile1
            // 
            this.tile1.HorizontalSize = 3;
            this.tile1.Image = global::TileExplorer.Properties.Resources.Brush;
            this.tile1.Name = "tile1";
            this.tile1.Template = this.template1;
            // 
            // template1
            // 
            this.template1.BackColor = System.Drawing.Color.SteelBlue;
            this.template1.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template1.Description = "Template 1";
            this.template1.Elements.Add(imageElement2);
            this.template1.Elements.Add(panelElement1);
            this.template1.Elements.Add(textElement1);
            this.template1.Name = "template1";
            // 
            // tile2
            // 
            this.tile2.HorizontalSize = 3;
            this.tile2.Image = global::TileExplorer.Properties.Resources.Book;
            this.tile2.LeftCell = 4;
            this.tile2.Name = "tile2";
            this.tile2.Template = this.template1;
            // 
            // tile3
            // 
            this.tile3.HorizontalSize = 3;
            this.tile3.Image = global::TileExplorer.Properties.Resources.Bitmap;
            this.tile3.LeftCell = 7;
            this.tile3.Name = "tile3";
            this.tile3.Template = this.template1;
            // 
            // group2
            // 
            this.group2.Name = "group2";
            this.group2.Text = "2. Use the Tile.ImageKey property and the ImageList component";
            this.group2.Tiles.Add(this.tile4);
            this.group2.Tiles.Add(this.tile5);
            this.group2.Tiles.Add(this.tile6);
            // 
            // tile4
            // 
            this.tile4.HorizontalSize = 3;
            this.tile4.ImageKey = "Setup.png";
            this.tile4.Name = "tile4";
            this.tile4.Template = this.template2;
            // 
            // template2
            // 
            this.template2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.template2.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template2.Description = "Template 2";
            this.template2.Elements.Add(imageElement3);
            this.template2.Name = "template2";
            // 
            // tile5
            // 
            this.tile5.HorizontalSize = 3;
            this.tile5.ImageKey = "History.png";
            this.tile5.LeftCell = 4;
            this.tile5.Name = "tile5";
            this.tile5.Template = this.template2;
            // 
            // tile6
            // 
            this.tile6.HorizontalSize = 3;
            this.tile6.ImageKey = "ColorGallery1.png";
            this.tile6.LeftCell = 7;
            this.tile6.Name = "tile6";
            this.tile6.Template = this.template2;
            // 
            // group3
            // 
            this.group3.Name = "group3";
            this.group3.Text = "3. Use the Tile.Symbol property";
            this.group3.Tiles.Add(this.tile7);
            this.group3.Tiles.Add(this.tile8);
            this.group3.Tiles.Add(this.tile9);
            // 
            // tile7
            // 
            this.tile7.HorizontalSize = 3;
            this.tile7.Name = "tile7";
            this.tile7.Symbol = C1.Win.Tile.TileSymbol.RunAsOtherUser;
            this.tile7.Template = this.template3;
            // 
            // template3
            // 
            this.template3.BackColor = System.Drawing.Color.MediumOrchid;
            this.template3.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template3.Description = "Template 3";
            imageElement4.ImageSelector = C1.Win.Tile.ImageSelector.Symbol;
            imageElement4.SymbolSize = C1.Win.Tile.SymbolSize.Image40x40;
            this.template3.Elements.Add(imageElement4);
            this.template3.Name = "template3";
            // 
            // tile8
            // 
            this.tile8.HorizontalSize = 3;
            this.tile8.LeftCell = 4;
            this.tile8.Name = "tile8";
            this.tile8.Symbol = C1.Win.Tile.TileSymbol.RunAsAdmin;
            this.tile8.Template = this.template3;
            // 
            // tile9
            // 
            this.tile9.HorizontalSize = 3;
            this.tile9.LeftCell = 7;
            this.tile9.Name = "tile9";
            this.tile9.Symbol = C1.Win.Tile.TileSymbol.RunAsService;
            this.tile9.Template = this.template3;
            // 
            // group4
            // 
            this.group4.Name = "group4";
            this.group4.Text = "4. Assign a compound image to the ImageElement.Image property";
            this.group4.Tiles.Add(this.tile10);
            this.group4.Tiles.Add(this.tile11);
            this.group4.Tiles.Add(this.tile12);
            // 
            // tile10
            // 
            this.tile10.HorizontalSize = 3;
            this.tile10.Name = "tile10";
            this.tile10.Template = this.template4;
            // 
            // template4
            // 
            this.template4.BackColor = System.Drawing.Color.LightGray;
            this.template4.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template4.Description = "Template 4";
            imageElement5.Image = global::TileExplorer.Properties.Resources.Images;
            imageElement5.ImageColumns = 3;
            imageElement5.ImageRows = 2;
            imageElement5.ImageSelector = C1.Win.Tile.ImageSelector.Unbound;
            this.template4.Elements.Add(imageElement5);
            this.template4.Name = "template4";
            // 
            // tile11
            // 
            this.tile11.HorizontalSize = 3;
            this.tile11.IntValue1 = 1;
            this.tile11.LeftCell = 4;
            this.tile11.Name = "tile11";
            this.tile11.Template = this.template4;
            // 
            // tile12
            // 
            this.tile12.HorizontalSize = 3;
            this.tile12.IntValue = 1;
            this.tile12.IntValue1 = 2;
            this.tile12.LeftCell = 7;
            this.tile12.Name = "tile12";
            this.tile12.Template = this.template4;
            // 
            // group5
            // 
            this.group5.Name = "group5";
            this.group5.Text = "5. Set the ImageElement.ImageSelector property to \'Numbers\'";
            this.group5.Tiles.Add(this.tile13);
            this.group5.Tiles.Add(this.tile14);
            this.group5.Tiles.Add(this.tile15);
            // 
            // tile13
            // 
            this.tile13.HorizontalSize = 3;
            this.tile13.IntValue = 1;
            this.tile13.Name = "tile13";
            this.tile13.Template = this.template5;
            // 
            // template5
            // 
            this.template5.BackColor = System.Drawing.Color.DimGray;
            this.template5.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template5.Description = "Template 5";
            panelElement2.BackColor = System.Drawing.Color.SeaGreen;
            imageElement6.ImageSelector = C1.Win.Tile.ImageSelector.Number;
            panelElement2.Children.Add(imageElement6);
            panelElement2.Padding = new System.Windows.Forms.Padding(4);
            this.template5.Elements.Add(panelElement2);
            this.template5.Name = "template5";
            // 
            // tile14
            // 
            this.tile14.HorizontalSize = 3;
            this.tile14.IntValue = 55;
            this.tile14.LeftCell = 4;
            this.tile14.Name = "tile14";
            this.tile14.Template = this.template5;
            // 
            // tile15
            // 
            this.tile15.HorizontalSize = 3;
            this.tile15.IntValue = 100;
            this.tile15.LeftCell = 7;
            this.tile15.Name = "tile15";
            this.tile15.Template = this.template5;
            // 
            // group6
            // 
            this.group6.Name = "group6";
            this.group6.Text = "6. Set the ImageElement.ImageSelector property to \'Stars\'";
            this.group6.Tiles.Add(this.tile16);
            this.group6.Tiles.Add(this.tile17);
            this.group6.Tiles.Add(this.tile18);
            // 
            // tile16
            // 
            this.tile16.HorizontalSize = 3;
            this.tile16.Name = "tile16";
            this.tile16.Template = this.template6;
            // 
            // template6
            // 
            this.template6.BackColor = System.Drawing.Color.SlateBlue;
            this.template6.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template6.Description = "Template 6";
            imageElement7.ImageSelector = C1.Win.Tile.ImageSelector.Stars;
            panelElement3.Children.Add(imageElement7);
            this.template6.Elements.Add(panelElement3);
            this.template6.Name = "template6";
            // 
            // tile17
            // 
            this.tile17.HorizontalSize = 3;
            this.tile17.IntValue = 3;
            this.tile17.LeftCell = 4;
            this.tile17.Name = "tile17";
            this.tile17.Template = this.template6;
            // 
            // tile18
            // 
            this.tile18.HorizontalSize = 3;
            this.tile18.IntValue = 10;
            this.tile18.LeftCell = 7;
            this.tile18.Name = "tile18";
            this.tile18.Template = this.template6;
            // 
            // group7
            // 
            this.group7.Name = "group7";
            this.group7.Text = "7. Adjust a CommonImage and select it in ImageElement.ImageSelector";
            this.group7.Tiles.Add(this.tile19);
            this.group7.Tiles.Add(this.tile20);
            this.group7.Tiles.Add(this.tile21);
            // 
            // tile19
            // 
            this.tile19.HorizontalSize = 3;
            this.tile19.IntValue = 1;
            this.tile19.Name = "tile19";
            this.tile19.Template = this.template7;
            // 
            // template7
            // 
            this.template7.BackColor = System.Drawing.Color.LightCoral;
            this.template7.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template7.Description = "Template 7";
            imageElement8.ImageSelector = C1.Win.Tile.ImageSelector.CommonImage1;
            this.template7.Elements.Add(imageElement8);
            this.template7.Name = "template7";
            // 
            // tile20
            // 
            this.tile20.HorizontalSize = 3;
            this.tile20.IntValue1 = 2;
            this.tile20.LeftCell = 4;
            this.tile20.Name = "tile20";
            this.tile20.Template = this.template7;
            // 
            // tile21
            // 
            this.tile21.HorizontalSize = 3;
            this.tile21.IntValue = 1;
            this.tile21.IntValue1 = 1;
            this.tile21.LeftCell = 7;
            this.tile21.Name = "tile21";
            this.tile21.Template = this.template7;
            // 
            // group8
            // 
            this.group8.Name = "group8";
            this.group8.Text = "8. Draw an image at runtime from the Template.Paint event";
            this.group8.Tiles.Add(this.tile22);
            this.group8.Tiles.Add(this.tile23);
            this.group8.Tiles.Add(this.tile24);
            // 
            // tile22
            // 
            this.tile22.HorizontalSize = 3;
            this.tile22.Name = "tile22";
            this.tile22.Template = this.template8;
            // 
            // template8
            // 
            this.template8.BackColor = System.Drawing.Color.SeaGreen;
            this.template8.BackColorSelector = C1.Win.Tile.BackColorSelector.Unbound;
            this.template8.Description = "Template 8";
            this.template8.Name = "template8";
            this.template8.Paint += new System.EventHandler<C1.Win.Tile.TemplatePaintEventArgs>(this.template8_Paint);
            // 
            // tile23
            // 
            this.tile23.HorizontalSize = 3;
            this.tile23.IntValue = 1;
            this.tile23.LeftCell = 4;
            this.tile23.Name = "tile23";
            this.tile23.Template = this.template8;
            // 
            // tile24
            // 
            this.tile24.HorizontalSize = 3;
            this.tile24.IntValue = 2;
            this.tile24.LeftCell = 7;
            this.tile24.Name = "tile24";
            this.tile24.Template = this.template8;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "ColorGallery1.png");
            this.imageList1.Images.SetKeyName(1, "History.png");
            this.imageList1.Images.SetKeyName(2, "Setup.png");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(632, 428);
            this.Controls.Add(this.c1TileControl1);
            this.ForeColor = System.Drawing.Color.White;            
            this.ResumeLayout(false);
        }

        #endregion

        private C1.Win.Tile.C1TileControl c1TileControl1;
        private C1.Win.Tile.Group group1;
        private C1.Win.Tile.Tile tile1;
        private C1.Win.Tile.Tile tile2;
        private C1.Win.Tile.Tile tile3;
        private C1.Win.Tile.Group group2;
        private C1.Win.Tile.Tile tile4;
        private System.Windows.Forms.ImageList imageList1;
        private C1.Win.Tile.Tile tile5;
        private C1.Win.Tile.Tile tile6;
        private C1.Win.Tile.Template template1;
        private C1.Win.Tile.Group group3;
        private C1.Win.Tile.Tile tile7;
        private C1.Win.Tile.Tile tile8;
        private C1.Win.Tile.Tile tile9;
        private C1.Win.Tile.Template template2;
        private C1.Win.Tile.Template template3;
        private C1.Win.Tile.Group group4;
        private C1.Win.Tile.Tile tile10;
        private C1.Win.Tile.Tile tile11;
        private C1.Win.Tile.Tile tile12;
        private C1.Win.Tile.Template template4;
        private C1.Win.Tile.Group group5;
        private C1.Win.Tile.Tile tile13;
        private C1.Win.Tile.Template template5;
        private C1.Win.Tile.Tile tile14;
        private C1.Win.Tile.Tile tile15;
        private C1.Win.Tile.Group group6;
        private C1.Win.Tile.Tile tile16;
        private C1.Win.Tile.Template template6;
        private C1.Win.Tile.Tile tile17;
        private C1.Win.Tile.Tile tile18;
        private C1.Win.Tile.Group group7;
        private C1.Win.Tile.Tile tile19;
        private C1.Win.Tile.Template template7;
        private C1.Win.Tile.Tile tile20;
        private C1.Win.Tile.Tile tile21;
        private C1.Win.Tile.Group group8;
        private C1.Win.Tile.Tile tile22;
        private C1.Win.Tile.Tile tile23;
        private C1.Win.Tile.Tile tile24;
        private C1.Win.Tile.Template template8;
    }
}
